using BetaJsonIntegrator.Core;
using BetaJsonIntegrator.Data;
using BetaJsonIntegrator.Orm;

namespace BetaJsonIntegrator.App;

/// <summary>Fonte escolhida na tela de dados; cada execução abre uma conexão nova e a descarta no fim.</summary>
internal sealed class SourceSelection
{
    public string Description { get; init; } = "";
    public Func<SourceHandle> Open { get; init; } = () => throw new InvalidOperationException();
    public List<SourceFilter> Filters { get; } = new();
}

internal sealed class SourceHandle : IDisposable
{
    private readonly IDisposable? _owner;
    public IRecordSource Source { get; }

    public SourceHandle(IRecordSource source, IDisposable? owner = null)
    {
        Source = source;
        _owner = owner;
    }

    public void Dispose() => _owner?.Dispose();
}

/// <summary>Estado e serviços compartilhados entre as telas.</summary>
internal static class AppEnv
{
    public static string BaseDir => AppContext.BaseDirectory;
    public static string ConfigDir => Path.Combine(BaseDir, "Configurations");
    public static string LayoutsRoot => Path.Combine(ConfigDir, "Layouts");
    public static string OutputRoot => Path.Combine(BaseDir, "Output");
    public static string LogsRoot => Path.Combine(BaseDir, "Logs");

    /// <summary>Arquivo de conexões criptografado (gerado com bji-tools encrypt).</summary>
    public static string ConnectionsFile => Path.Combine(ConfigDir, "connections.json");

    public static SecretSource Secret => SecretSource.Default(ConfigDir);

    public static IIntegratorLogger Logger { get; private set; } = NullLogger.Instance;
    public static LayoutCatalog Catalog { get; private set; } = new(Path.Combine(AppContext.BaseDirectory, "Configurations", "Layouts"));
    public static IntegratorService Integrator { get; private set; } = new();
    public static ExportService Exporter { get; private set; } = new();

    public static LayoutPackage? Layout { get; set; }
    public static SourceSelection? Source { get; set; }
    public static RunResult? LastRun { get; set; }

    public static void Init()
    {
        Logger = new FileLogger(LogsRoot);
        Catalog = new LayoutCatalog(LayoutsRoot);
        Integrator = new IntegratorService(Logger);
        Exporter = new ExportService(Logger);
    }

    /// <summary>Relê o layout do disco (pega XML e personalizações alteradas).</summary>
    public static void ReloadLayout()
    {
        if (Layout is not null) Layout = Catalog.Load(Layout.FolderName);
    }

    public static SourceHandle OpenDatabase(string profileName)
    {
        var factory = DbContextFactory.FromFile(ConnectionsFile, Secret);
        var ctx = factory.Create(profileName);
        ctx.CommandExecuted += LogSql;
        return new SourceHandle(new DatabaseProvider(ctx), ctx);
    }

    private static void LogSql(SqlLogEntry e) =>
        Logger.Info($"SQL [{e.Kind}] {e.Duration.TotalMilliseconds:0} ms: {e.Sql}");
}
