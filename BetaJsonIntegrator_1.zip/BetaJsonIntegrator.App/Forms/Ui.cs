namespace BetaJsonIntegrator.App.Forms;

/// <summary>Atalhos para montar controles em código (sem designer).</summary>
internal static class Ui
{
    public static readonly Font Mono = new("Consolas", 10F);

    public static Button Btn(string text, EventHandler onClick, int width = 140)
    {
        var b = new Button { Text = text, Width = width, Height = 32, FlatStyle = FlatStyle.System };
        b.Click += onClick;
        return b;
    }

    public static Label Lbl(string text, bool bold = false) => new()
    {
        Text = text,
        AutoSize = true,
        Font = bold ? new Font("Segoe UI", 10F, FontStyle.Bold) : new Font("Segoe UI", 9F)
    };

    public static TextBox Viewer(bool wrap = false) => new()
    {
        Multiline = true,
        ReadOnly = true,
        Dock = DockStyle.Fill,
        Font = Mono,
        ScrollBars = ScrollBars.Both,
        WordWrap = wrap,
        BackColor = SystemColors.Window
    };

    public static FlowLayoutPanel ButtonBar() => new()
    {
        Dock = DockStyle.Bottom,
        Height = 46,
        FlowDirection = FlowDirection.RightToLeft,
        Padding = new Padding(8, 7, 8, 5)
    };

    public static Color SeverityColor(Core.IssueSeverity s) => s switch
    {
        Core.IssueSeverity.Error => Color.FromArgb(255, 225, 225),
        Core.IssueSeverity.Warning => Color.FromArgb(255, 245, 205),
        _ => Color.White
    };
}
