using BetaJsonIntegrator.Core;

namespace BetaJsonIntegrator.App.Forms;

/// <summary>
/// Campos sem valor/coluna/regra. O usuário escolhe valor fixo, coluna da origem ou padrão;
/// o resultado é salvo em customizations.xml, separado do layout.
/// </summary>
public sealed class frmPersonalizacao : Form
{
    private readonly DataGridView _grid = new()
    {
        Dock = DockStyle.Fill,
        AllowUserToAddRows = false,
        AllowUserToDeleteRows = false,
        RowHeadersVisible = false,
        SelectionMode = DataGridViewSelectionMode.FullRowSelect,
        AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
    };

    private readonly IReadOnlyList<PendingField> _pending;

    public frmPersonalizacao(IReadOnlyList<PendingField> pending)
    {
        _pending = pending;
        Text = "Personalização de campos";
        Width = 1000;
        Height = 520;
        StartPosition = FormStartPosition.CenterParent;

        var help = Ui.Lbl("Defina como cada campo deve ser preenchido. Campos em branco continuam pendentes (obrigatórios bloqueiam a geração). " +
                            "Colunas disponíveis: " + AvailableColumns());
        help.MaximumSize = new Size(960, 0);
        help.Padding = new Padding(8);
        help.Dock = DockStyle.Top;

        _grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "colCampo", HeaderText = "Campo (caminho)", ReadOnly = true, FillWeight = 160 });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "colDescricao", HeaderText = "Descrição", ReadOnly = true, FillWeight = 130 });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "colTipo", HeaderText = "Tipo", ReadOnly = true, FillWeight = 50 });
        _grid.Columns.Add(new DataGridViewCheckBoxColumn { Name = "colObrig", HeaderText = "Obrig.", ReadOnly = true, FillWeight = 40 });

        var modo = new DataGridViewComboBoxColumn { Name = "colModo", HeaderText = "Modo", FillWeight = 60, FlatStyle = FlatStyle.Flat };
        modo.Items.AddRange("Valor fixo", "Coluna", "Valor padrão");
        _grid.Columns.Add(modo);
        _grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "colValor", HeaderText = "Valor ou coluna", FillWeight = 120 });

        foreach (var p in pending)
        {
            var idx = _grid.Rows.Add(p.Path, p.Description, p.TypeName, p.Required, "Valor fixo", "");
            _grid.Rows[idx].Tag = p;
        }

        var bar = Ui.ButtonBar();
        bar.Controls.Add(Ui.Btn("Cancelar", btnCancelar_Click, 90));
        bar.Controls.Add(Ui.Btn("Salvar", btnSalvar_Click, 90));

        Controls.Add(_grid);
        Controls.Add(help);
        Controls.Add(bar);
    }

    private static string AvailableColumns()
    {
        var layout = AppEnv.Layout?.Layout;
        if (layout is null) return "-";
        var names = layout.Generates.SelectMany(g => g.Tables).SelectMany(t => t.Columns.Select(c => c.Name)).Distinct();
        return string.Join(", ", names);
    }

    private void btnSalvar_Click(object? sender, EventArgs e)
    {
        var package = AppEnv.Layout;
        if (package is null) return;

        foreach (DataGridViewRow row in _grid.Rows)
        {
            var value = Convert.ToString(row.Cells["colValor"].Value)?.Trim() ?? "";
            if (value.Length == 0) continue;

            var p = (PendingField)row.Tag!;
            var modeText = Convert.ToString(row.Cells["colModo"].Value);
            var mode = modeText == "Coluna" ? CustomizationMode.Column
                     : modeText == "Valor padrão" ? CustomizationMode.Default
                     : CustomizationMode.Fixed;

            package.Customizations.Set(new CustomizationEntry
            {
                Name = p.Name,
                Path = p.Path,
                TypeName = p.TypeName,
                Mode = mode,
                Value = mode == CustomizationMode.Column ? null : value,
                Source = mode == CustomizationMode.Column ? value : null
            });
        }

        AppEnv.Catalog.SaveCustomizations(package);
        DialogResult = DialogResult.OK;
        Close();
    }

    private void btnCancelar_Click(object? sender, EventArgs e)
    {
        DialogResult = DialogResult.Cancel;
        Close();
    }
}
