namespace BetaJsonIntegrator.App.Forms;

/// <summary>JSON formatado, com copiar.</summary>
public sealed class frmVisualizadorJSON : Form
{
    private readonly TextBox _txt = Ui.Viewer();

    public frmVisualizadorJSON(string title, string json)
    {
        Text = title;
        Width = 900;
        Height = 650;
        StartPosition = FormStartPosition.CenterParent;
        _txt.Text = json;

        var bar = Ui.ButtonBar();
        bar.Controls.Add(Ui.Btn("Fechar", btnFechar_Click, 90));
        bar.Controls.Add(Ui.Btn("Copiar JSON", btnCopiar_Click, 120));

        Controls.Add(_txt);
        Controls.Add(bar);
    }

    private void btnCopiar_Click(object? sender, EventArgs e)
    {
        if (_txt.Text.Length > 0) Clipboard.SetText(_txt.Text);
    }

    private void btnFechar_Click(object? sender, EventArgs e) => Close();
}
