using BetaJsonIntegrator.Core;

namespace BetaJsonIntegrator.App.Forms;

/// <summary>Visualiza/edita o XML, valida a configuração e abre as personalizações.</summary>
public sealed class frmConfiguracaoXML : Form
{
    private readonly TextBox _txt = new()
    {
        Multiline = true,
        Dock = DockStyle.Fill,
        Font = Ui.Mono,
        ScrollBars = ScrollBars.Both,
        WordWrap = false,
        AcceptsTab = true
    };

    public frmConfiguracaoXML()
    {
        var pkg = AppEnv.Layout ?? throw new InvalidOperationException("Nenhum layout selecionado.");
        Text = $"Configuração XML - {pkg.Layout.Name} (v{pkg.Metadata.LayoutVersion})";
        Width = 1000;
        Height = 700;
        StartPosition = FormStartPosition.CenterParent;
        _txt.Text = pkg.LayoutXml.Replace("\r\n", "\n").Replace("\n", Environment.NewLine);

        var bar = Ui.ButtonBar();
        bar.Controls.Add(Ui.Btn("Fechar", btnFechar_Click, 90));
        bar.Controls.Add(Ui.Btn("Salvar nova versão", btnSalvar_Click, 150));
        bar.Controls.Add(Ui.Btn("Personalizações...", btnPersonalizar_Click, 150));
        bar.Controls.Add(Ui.Btn("Validar configuração", btnValidar_Click, 160));

        Controls.Add(_txt);
        Controls.Add(bar);
    }

    private bool TryParse(out ParseResult? parsed, out List<ValidationIssue> issues)
    {
        issues = new List<ValidationIssue>();
        parsed = null;
        try
        {
            parsed = XmlLayoutParser.Parse(XmlLayoutReader.LoadText(_txt.Text));
            issues.AddRange(parsed.Issues);
            issues.AddRange(LayoutValidator.Validate(parsed.Layout));
            return true;
        }
        catch (LayoutException ex)
        {
            issues.Add(new ValidationIssue(IssueSeverity.Error, "XML_INVALIDO", ex.Message));
            return false;
        }
    }

    private void btnValidar_Click(object? sender, EventArgs e)
    {
        TryParse(out var parsed, out var issues);

        if (parsed is not null)
        {
            // referências de campo → coluna, sem precisar de dados
            foreach (var generate in parsed.Layout.Generates)
                foreach (var json in parsed.Layout.JsonDefinitions)
                    issues.AddRange(new MappingResolver().Resolve(json, generate, AppEnv.Layout?.Customizations).Issues);
        }

        var errors = issues.Count(i => i.Severity == IssueSeverity.Error);
        var summary = errors == 0 ? "Configuração sem erros." : $"{errors} erro(s) na configuração.";
        using var f = new frmValidacao("Validação da configuração", summary, issues);
        f.ShowDialog(this);
    }

    private void btnPersonalizar_Click(object? sender, EventArgs e)
    {
        if (!TryParse(out var parsed, out _) || parsed is null)
        {
            MessageBox.Show("Corrija o XML antes de personalizar.", Text);
            return;
        }

        var pending = new List<PendingField>();
        foreach (var generate in parsed.Layout.Generates)
            foreach (var json in parsed.Layout.JsonDefinitions)
                pending.AddRange(new MappingResolver().Resolve(json, generate, AppEnv.Layout?.Customizations).Pending);

        if (pending.Count == 0)
        {
            MessageBox.Show("Nenhum campo pendente de personalização.", Text);
            return;
        }

        using var f = new frmPersonalizacao(pending);
        f.ShowDialog(this);
    }

    private void btnSalvar_Click(object? sender, EventArgs e)
    {
        var pkg = AppEnv.Layout;
        if (pkg is null) return;

        if (!TryParse(out _, out var issues))
        {
            MessageBox.Show(issues[0].Message, "XML inválido", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        var version = AppEnv.Catalog.SaveLayoutXml(pkg.FolderName, _txt.Text);
        AppEnv.ReloadLayout();
        MessageBox.Show($"Layout salvo (versão {version}).", Text);
    }

    private void btnFechar_Click(object? sender, EventArgs e) => Close();
}
