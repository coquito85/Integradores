using System.Diagnostics;
using BetaJsonIntegrator.Core;

namespace BetaJsonIntegrator.App.Forms;

/// <summary>Navegação lateral, resumo do layout ativo e painel de mensagens.</summary>
public sealed class frmPrincipal : Form
{
    private readonly Label _lblLayout = Ui.Lbl("", true);
    private readonly Label _lblFonte = Ui.Lbl("");
    private readonly Label _lblUltima = Ui.Lbl("");
    private readonly Label _lblResumo = Ui.Lbl("");
    private readonly TextBox _txtMensagens = new()
    {
        Multiline = true,
        ReadOnly = true,
        Dock = DockStyle.Bottom,
        Height = 170,
        ScrollBars = ScrollBars.Vertical,
        Font = Ui.Mono
    };

    private readonly Button _btnGerar;
    private readonly List<Button> _nav = new();

    public frmPrincipal()
    {
        Text = "Beta JSON Integrator";
        Width = 1100;
        Height = 700;
        StartPosition = FormStartPosition.CenterScreen;
        Font = new Font("Segoe UI", 9F);

        var menu = new Panel { Dock = DockStyle.Left, Width = 220, BackColor = Color.FromArgb(34, 44, 66), Padding = new Padding(10) };
        var title = new Label
        {
            Text = "BETA ANALYTICS\nJSON Integrator",
            ForeColor = Color.White,
            Dock = DockStyle.Top,
            Height = 64,
            Font = new Font("Segoe UI", 11F, FontStyle.Bold)
        };

        _btnGerar = NavButton("▶  Gerar JSON", btnGerar_Click);
        var buttons = new[]
        {
            NavButton("Layouts", btnLayouts_Click),
            NavButton("Configuração XML", btnXml_Click),
            NavButton("Fonte de dados", btnFonte_Click),
            _btnGerar,
            NavButton("Visualizar JSON", btnJson_Click),
            NavButton("Validação", btnValidacao_Click),
            NavButton("Exportar", btnExportar_Click)
        };

        // Dock.Top empilha ao contrário: adiciona na ordem inversa
        foreach (var b in buttons.Reverse()) menu.Controls.Add(b);
        menu.Controls.Add(title);

        var center = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            Padding = new Padding(24),
            ColumnCount = 1,
            RowCount = 5
        };
        center.Controls.Add(Ui.Lbl("Layout ativo", true), 0, 0);
        center.Controls.Add(_lblLayout, 0, 1);
        center.Controls.Add(_lblFonte, 0, 2);
        center.Controls.Add(_lblUltima, 0, 3);
        center.Controls.Add(_lblResumo, 0, 4);

        Controls.Add(center);
        Controls.Add(_txtMensagens);
        Controls.Add(menu);

        Shown += frmPrincipal_Shown;
        RefreshStatus();
    }

    private Button NavButton(string text, EventHandler click)
    {
        var b = new Button
        {
            Text = text,
            Dock = DockStyle.Top,
            Height = 42,
            FlatStyle = FlatStyle.Flat,
            ForeColor = Color.White,
            BackColor = Color.FromArgb(48, 62, 92),
            TextAlign = ContentAlignment.MiddleLeft,
            Padding = new Padding(10, 0, 0, 0),
            Margin = new Padding(0, 0, 0, 4)
        };
        b.FlatAppearance.BorderSize = 0;
        b.Click += click;
        _nav.Add(b);
        return b;
    }

    // ---------- estado ----------

    private void frmPrincipal_Shown(object? sender, EventArgs e)
    {
        if (AppEnv.Layout is null)
        {
            var first = AppEnv.Catalog.List().FirstOrDefault();
            if (first is not null)
            {
                try { AppEnv.Layout = AppEnv.Catalog.Load(first.FolderName); }
                catch (LayoutException ex) { Log("Falha ao carregar layout: " + ex.Message); }
            }
        }
        RefreshStatus();
    }

    private void RefreshStatus()
    {
        var l = AppEnv.Layout;
        _lblLayout.Text = l is null ? "(nenhum - abra 'Layouts')" : $"{l.Layout.Name}  |  {l.Layout.Identifier}  |  v{l.Metadata.LayoutVersion}";
        _lblFonte.Text = "Fonte: " + (AppEnv.Source?.Description ?? "(não definida)");

        var r = AppEnv.LastRun;
        if (r is null)
        {
            _lblUltima.Text = "Última execução: -";
            _lblResumo.Text = "";
            return;
        }

        _lblUltima.Text = $"Última execução: {r.Report.ExecutedAt:dd/MM/yyyy HH:mm:ss} ({r.Report.DurationSeconds:0.##}s)";
        _lblResumo.Text = $"Registros: {r.Report.RecordCounts.Values.Sum()}   Erros: {r.Report.ErrorCount}   " +
                          $"Avisos: {r.Report.WarningCount}   Pendentes: {r.Pending.Count}   JSON: {(r.Generated ? "gerado" : "não gerado")}";
    }

    private void Log(string message)
    {
        _txtMensagens.AppendText($"{DateTime.Now:HH:mm:ss}  {message}{Environment.NewLine}");
        AppEnv.Logger.Info(message);
    }

    private void SetBusy(bool busy)
    {
        foreach (var b in _nav) b.Enabled = !busy;
        UseWaitCursor = busy;
    }

    private bool RequireLayout()
    {
        if (AppEnv.Layout is not null) return true;
        MessageBox.Show("Selecione um layout primeiro.", Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
        return false;
    }

    // ---------- ações ----------

    private void btnLayouts_Click(object? sender, EventArgs e)
    {
        using var f = new frmLayouts();
        f.ShowDialog(this);
        RefreshStatus();
    }

    private void btnXml_Click(object? sender, EventArgs e)
    {
        if (!RequireLayout()) return;
        using var f = new frmConfiguracaoXML();
        f.ShowDialog(this);
        RefreshStatus();
    }

    private void btnFonte_Click(object? sender, EventArgs e)
    {
        using var f = new frmFonteDados();
        f.ShowDialog(this);
        RefreshStatus();
    }

    private async void btnGerar_Click(object? sender, EventArgs e)
    {
        if (!RequireLayout()) return;
        if (AppEnv.Source is null)
        {
            MessageBox.Show("Defina a fonte de dados primeiro.", Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        SetBusy(true);
        try
        {
            AppEnv.ReloadLayout();
            Log($"Gerando {AppEnv.Layout!.Layout.Identifier} a partir de {AppEnv.Source.Description}...");

            using var handle = AppEnv.Source.Open();
            var options = new RunOptions();
            options.Filters.AddRange(AppEnv.Source.Filters);

            var run = await AppEnv.Integrator.RunAsync(AppEnv.Layout, handle.Source, options);
            AppEnv.LastRun = run;

            Log($"Concluído: {run.Report.ErrorCount} erro(s), {run.Report.WarningCount} aviso(s), {run.Pending.Count} pendente(s).");
            RefreshStatus();

            if (run.Pending.Count > 0) OfferCustomization(run);
            else if (run.HasErrors) ShowValidation();
        }
        catch (Exception ex)
        {
            Log("Falha: " + ex.Message);
            AppEnv.Logger.Error("Falha ao gerar JSON", ex);
            MessageBox.Show(ex.Message, "Falha ao gerar", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        finally
        {
            SetBusy(false);
        }
    }

    private void OfferCustomization(RunResult run)
    {
        var answer = MessageBox.Show(
            $"{run.Pending.Count} campo(s) sem configuração. Deseja personalizá-los agora?",
            Text, MessageBoxButtons.YesNo, MessageBoxIcon.Question);

        if (answer != DialogResult.Yes) { ShowValidation(); return; }

        using var f = new frmPersonalizacao(run.Pending);
        if (f.ShowDialog(this) == DialogResult.OK)
            Log("Personalizações salvas. Execute 'Gerar JSON' novamente para revalidar.");
    }

    private void btnJson_Click(object? sender, EventArgs e)
    {
        var run = AppEnv.LastRun;
        if (run?.JsonText is null)
        {
            MessageBox.Show("Ainda não há JSON gerado.", Text);
            return;
        }
        using var f = new frmVisualizadorJSON($"JSON - {run.Report.Identifier}", run.JsonText);
        f.ShowDialog(this);
    }

    private void btnValidacao_Click(object? sender, EventArgs e) => ShowValidation();

    private void ShowValidation()
    {
        var run = AppEnv.LastRun;
        if (run is null)
        {
            MessageBox.Show("Nenhuma execução ainda.", Text);
            return;
        }

        var summary = run.HasErrors
            ? $"{run.Report.ErrorCount} erro(s), {run.Report.WarningCount} aviso(s). Exportação do JSON bloqueada."
            : $"Sem erros ({run.Report.WarningCount} aviso(s)).";
        using var f = new frmValidacao("Validação", summary, run.Report.Issues);
        f.ShowDialog(this);
    }

    private void btnExportar_Click(object? sender, EventArgs e)
    {
        var run = AppEnv.LastRun;
        if (run is null || AppEnv.Layout is null)
        {
            MessageBox.Show("Gere o JSON antes de exportar.", Text);
            return;
        }

        var period = frmPrompt.Ask(this, "Exportar", "Subpasta de saída (período/competência):", DateTime.Now.Year.ToString());
        if (period is null) return;

        var options = new ExportOptions { OutputRoot = AppEnv.OutputRoot, LayoutFolder = AppEnv.Layout.FolderName, Subfolder = period };

        try
        {
            ExportResult result;
            try
            {
                result = AppEnv.Exporter.Export(run, options);
            }
            catch (IOException)
            {
                var answer = MessageBox.Show(
                    "Os arquivos já existem. Sim = sobrescrever, Não = gravar com data/hora no nome.",
                    "Arquivo existente", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
                if (answer == DialogResult.Cancel) return;
                options.Overwrite = answer == DialogResult.Yes ? OverwritePolicy.Overwrite : OverwritePolicy.AddTimestamp;
                result = AppEnv.Exporter.Export(run, options);
            }

            Log(result.JsonPath is null
                ? $"JSON NÃO exportado (há erros). Relatório: {result.ReportPath}"
                : $"Exportado: {result.JsonPath}");

            var folder = Path.GetDirectoryName(result.ReportPath)!;
            if (MessageBox.Show("Exportação concluída. Abrir a pasta?", Text, MessageBoxButtons.YesNo) == DialogResult.Yes)
                Process.Start(new ProcessStartInfo { FileName = folder, UseShellExecute = true });
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Falha ao exportar", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}
