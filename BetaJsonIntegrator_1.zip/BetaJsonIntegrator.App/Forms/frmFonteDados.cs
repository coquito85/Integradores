using BetaJsonIntegrator.Core;
using BetaJsonIntegrator.Data;
using BetaJsonIntegrator.Orm;

namespace BetaJsonIntegrator.App.Forms;

/// <summary>Escolha da fonte: banco (perfil do JSON criptografado) ou CSV, com filtro opcional de período.</summary>
public sealed class frmFonteDados : Form
{
    private readonly RadioButton _rbBanco = new() { Text = "Banco de dados (conexões criptografadas)", AutoSize = true, Checked = true };
    private readonly RadioButton _rbCsv = new() { Text = "Arquivo CSV", AutoSize = true };

    private readonly ComboBox _cboPerfil = new() { DropDownStyle = ComboBoxStyle.DropDownList, Width = 330 };
    private readonly Label _lblConexoes = Ui.Lbl("");

    private readonly TextBox _txtArquivo = new() { Width = 330 };
    private readonly TextBox _txtDelimitador = new() { Width = 40, Text = ";", MaxLength = 2 };
    private readonly ComboBox _cboEncoding = new() { DropDownStyle = ComboBoxStyle.DropDownList, Width = 140 };
    private readonly CheckBox _chkCabecalho = new() { Text = "Primeira linha é cabeçalho", Checked = true, AutoSize = true };

    private readonly TextBox _txtColuna = new() { Width = 160 };
    private readonly DateTimePicker _dtDe = new() { ShowCheckBox = true, Checked = false, Format = DateTimePickerFormat.Short, Width = 130 };
    private readonly DateTimePicker _dtAte = new() { ShowCheckBox = true, Checked = false, Format = DateTimePickerFormat.Short, Width = 130 };

    private readonly Panel _pnlBanco = new() { Height = 90, Dock = DockStyle.Top };
    private readonly Panel _pnlCsv = new() { Height = 120, Dock = DockStyle.Top, Visible = false };

    public frmFonteDados()
    {
        Text = "Fonte de dados";
        ClientSize = new Size(560, 440);
        FormBorderStyle = FormBorderStyle.FixedDialog;
        StartPosition = FormStartPosition.CenterParent;
        MaximizeBox = false;

        _cboEncoding.Items.AddRange(new object[] { "utf-8", "windows-1252", "iso-8859-1" });
        _cboEncoding.SelectedIndex = 0;

        _rbBanco.CheckedChanged += rbTipo_CheckedChanged;
        _rbCsv.CheckedChanged += rbTipo_CheckedChanged;

        // painel banco
        _lblConexoes.Location = new Point(0, 0);
        _cboPerfil.Location = new Point(0, 22);
        var btnTestar = Ui.Btn("Testar", btnTestar_Click, 80);
        btnTestar.Location = new Point(340, 20);
        _pnlBanco.Controls.AddRange(new Control[] { _lblConexoes, _cboPerfil, btnTestar });

        // painel CSV
        _txtArquivo.Location = new Point(0, 4);
        var btnArq = Ui.Btn("Arquivo...", btnArquivo_Click, 80);
        btnArq.Location = new Point(338, 2);
        var btnPasta = Ui.Btn("Pasta...", btnPasta_Click, 70);
        btnPasta.Location = new Point(424, 2);
        var lblDelim = Ui.Lbl("Delimitador:"); lblDelim.Location = new Point(0, 46);
        _txtDelimitador.Location = new Point(80, 43);
        var lblEnc = Ui.Lbl("Encoding:"); lblEnc.Location = new Point(140, 46);
        _cboEncoding.Location = new Point(205, 43);
        _chkCabecalho.Location = new Point(0, 78);
        var dica = Ui.Lbl("Em pasta: um arquivo <alias>.csv por tabela do layout.");
        dica.Location = new Point(0, 100);
        _pnlCsv.Controls.AddRange(new Control[] { _txtArquivo, btnArq, btnPasta, lblDelim, _txtDelimitador, lblEnc, _cboEncoding, _chkCabecalho, dica });

        // filtro
        var grpFiltro = new GroupBox { Text = "Filtro de período (opcional)", Dock = DockStyle.Top, Height = 90 };
        var l1 = Ui.Lbl("Coluna de data:"); l1.Location = new Point(12, 26);
        _txtColuna.Location = new Point(110, 23);
        var l2 = Ui.Lbl("De:"); l2.Location = new Point(12, 58);
        _dtDe.Location = new Point(40, 54);
        var l3 = Ui.Lbl("Até:"); l3.Location = new Point(190, 58);
        _dtAte.Location = new Point(225, 54);
        grpFiltro.Controls.AddRange(new Control[] { l1, _txtColuna, l2, _dtDe, l3, _dtAte });

        var tipos = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 56, FlowDirection = FlowDirection.TopDown };
        tipos.Controls.Add(_rbBanco);
        tipos.Controls.Add(_rbCsv);

        var body = new Panel { Dock = DockStyle.Fill, Padding = new Padding(14) };
        body.Controls.Add(grpFiltro);
        body.Controls.Add(_pnlCsv);
        body.Controls.Add(_pnlBanco);
        body.Controls.Add(tipos);

        var bar = Ui.ButtonBar();
        bar.Controls.Add(Ui.Btn("Cancelar", btnCancelar_Click, 90));
        bar.Controls.Add(Ui.Btn("Usar esta fonte", btnOk_Click, 130));

        Controls.Add(body);
        Controls.Add(bar);

        Load += frmFonteDados_Load;
    }

    private void frmFonteDados_Load(object? sender, EventArgs e) => LoadProfiles();

    private void LoadProfiles()
    {
        _cboPerfil.Items.Clear();
        try
        {
            if (!File.Exists(AppEnv.ConnectionsFile))
            {
                _lblConexoes.Text = "Arquivo de conexões não encontrado: Configurations\\connections.json";
                return;
            }

            var settings = ConnectionStore.Load(AppEnv.ConnectionsFile, AppEnv.Secret);
            foreach (var p in settings.Profiles) _cboPerfil.Items.Add(p.Name);
            _lblConexoes.Text = $"{settings.Profiles.Count} perfil(is) disponível(is):";

            var idx = settings.DefaultProfile is null ? 0 : _cboPerfil.Items.IndexOf(settings.DefaultProfile);
            if (_cboPerfil.Items.Count > 0) _cboPerfil.SelectedIndex = Math.Max(idx, 0);
        }
        catch (ConnectionStoreException ex)
        {
            _lblConexoes.Text = ex.Message;
        }
    }

    private void rbTipo_CheckedChanged(object? sender, EventArgs e)
    {
        _pnlBanco.Visible = _rbBanco.Checked;
        _pnlCsv.Visible = _rbCsv.Checked;
    }

    private void btnTestar_Click(object? sender, EventArgs e)
    {
        if (_cboPerfil.SelectedItem is not string name) return;
        try
        {
            var factory = DbContextFactory.FromFile(AppEnv.ConnectionsFile, AppEnv.Secret);
            using var ctx = factory.Create(name);
            ctx.TestConnection();
            MessageBox.Show("Conexão realizada com sucesso.", Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Falha na conexão", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    private void btnArquivo_Click(object? sender, EventArgs e)
    {
        using var dlg = new OpenFileDialog { Filter = "CSV (*.csv;*.txt)|*.csv;*.txt|Todos|*.*" };
        if (dlg.ShowDialog(this) == DialogResult.OK) _txtArquivo.Text = dlg.FileName;
    }

    private void btnPasta_Click(object? sender, EventArgs e)
    {
        using var dlg = new FolderBrowserDialog();
        if (dlg.ShowDialog(this) == DialogResult.OK) _txtArquivo.Text = dlg.SelectedPath;
    }

    private void btnCancelar_Click(object? sender, EventArgs e)
    {
        DialogResult = DialogResult.Cancel;
        Close();
    }

    private void btnOk_Click(object? sender, EventArgs e)
    {
        SourceSelection selection;

        if (_rbBanco.Checked)
        {
            if (_cboPerfil.SelectedItem is not string name)
            {
                MessageBox.Show("Escolha um perfil de conexão.", Text);
                return;
            }
            selection = new SourceSelection
            {
                Description = $"Banco: {name}",
                Open = new DatabaseSourceFactory(name).Open
            };
        }
        else
        {
            var path = _txtArquivo.Text.Trim();
            if (!File.Exists(path) && !Directory.Exists(path))
            {
                MessageBox.Show("Informe um arquivo ou pasta CSV existente.", Text);
                return;
            }

            var delimiter = _txtDelimitador.Text == "\\t" ? '\t' : (_txtDelimitador.Text.Length > 0 ? _txtDelimitador.Text[0] : ';');
            selection = new SourceSelection
            {
                Description = $"CSV: {Path.GetFileName(path.TrimEnd(Path.DirectorySeparatorChar))}",
                Open = new CsvSourceFactory(path, delimiter, _cboEncoding.Text, _chkCabecalho.Checked).Open
            };
        }

        var column = _txtColuna.Text.Trim();
        if (column.Length > 0)
        {
            if (_dtDe.Checked) selection.Filters.Add(new SourceFilter(column, FilterOperator.GreaterOrEqual, _dtDe.Value.Date));
            if (_dtAte.Checked) selection.Filters.Add(new SourceFilter(column, FilterOperator.LessOrEqual, _dtAte.Value.Date));
        }

        AppEnv.Source = selection;
        DialogResult = DialogResult.OK;
        Close();
    }

    private sealed class DatabaseSourceFactory
    {
        private readonly string _profile;
        public DatabaseSourceFactory(string profile) => _profile = profile;
        public SourceHandle Open() => AppEnv.OpenDatabase(_profile);
    }

    private sealed class CsvSourceFactory
    {
        private readonly string _path;
        private readonly CsvOptions _options;

        public CsvSourceFactory(string path, char delimiter, string encoding, bool header)
        {
            _path = path;
            _options = new CsvOptions { Delimiter = delimiter, EncodingName = encoding, HasHeader = header };
        }

        public SourceHandle Open()
        {
            if (Directory.Exists(_path))
            {
                var tables = AppEnv.Layout?.Layout.Generates.FirstOrDefault()?.Tables ?? new List<TableDefinition>();
                foreach (var t in tables) _options.Files[t.Alias] = Path.Combine(_path, t.Alias + ".csv");
            }
            else
            {
                _options.DefaultFile = _path;
            }
            return new SourceHandle(new CsvProvider(_options));
        }
    }
}
