namespace BetaJsonIntegrator.App.Forms;

/// <summary>Pergunta simples de uma linha.</summary>
internal sealed class frmPrompt : Form
{
    private readonly TextBox _txt = new() { Dock = DockStyle.Top };

    private frmPrompt(string title, string label, string initial)
    {
        Text = title;
        FormBorderStyle = FormBorderStyle.FixedDialog;
        StartPosition = FormStartPosition.CenterParent;
        MaximizeBox = false;
        MinimizeBox = false;
        ClientSize = new Size(360, 120);

        _txt.Text = initial;
        var lbl = Ui.Lbl(label);
        lbl.Dock = DockStyle.Top;
        lbl.Padding = new Padding(0, 0, 0, 6);

        var body = new Panel { Dock = DockStyle.Fill, Padding = new Padding(12) };
        body.Controls.Add(_txt);
        body.Controls.Add(lbl);

        var ok = new Button { Text = "OK", DialogResult = DialogResult.OK, Width = 90 };
        var cancel = new Button { Text = "Cancelar", DialogResult = DialogResult.Cancel, Width = 90 };
        var bar = Ui.ButtonBar();
        bar.Controls.Add(cancel);
        bar.Controls.Add(ok);

        Controls.Add(body);
        Controls.Add(bar);
        AcceptButton = ok;
        CancelButton = cancel;
    }

    public static string? Ask(IWin32Window owner, string title, string label, string initial = "")
    {
        using var f = new frmPrompt(title, label, initial);
        return f.ShowDialog(owner) == DialogResult.OK ? f._txt.Text.Trim() : null;
    }
}
