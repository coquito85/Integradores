using BetaJsonIntegrator.Core;

namespace BetaJsonIntegrator.App.Forms;

/// <summary>Erros, avisos, campos ausentes e o caminho da propriedade.</summary>
public sealed class frmValidacao : Form
{
    private readonly ListView _list = new()
    {
        Dock = DockStyle.Fill,
        View = View.Details,
        FullRowSelect = true,
        GridLines = true,
        HideSelection = false
    };

    private readonly ComboBox _filter = new() { DropDownStyle = ComboBoxStyle.DropDownList, Width = 160 };
    private readonly Label _summary = Ui.Lbl("", true);
    private readonly IReadOnlyList<ValidationIssue> _issues;

    public frmValidacao(string title, string summary, IReadOnlyList<ValidationIssue> issues)
    {
        _issues = issues;
        Text = title;
        Width = 1000;
        Height = 560;
        StartPosition = FormStartPosition.CenterParent;

        _summary.Text = summary;
        _summary.Padding = new Padding(8, 8, 8, 4);

        _list.Columns.Add("Severidade", 90);
        _list.Columns.Add("Código", 200);
        _list.Columns.Add("Caminho", 280);
        _list.Columns.Add("Mensagem", 700);

        _filter.Items.AddRange(new object[] { "Todas", "Somente erros", "Erros e avisos" });
        _filter.SelectedIndex = 0;
        _filter.SelectedIndexChanged += cboFiltro_SelectedIndexChanged;

        var top = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 40, Padding = new Padding(8, 4, 8, 0) };
        top.Controls.Add(_summary);

        var bar = Ui.ButtonBar();
        bar.Controls.Add(Ui.Btn("Fechar", btnFechar_Click, 90));
        bar.Controls.Add(Ui.Btn("Copiar tudo", btnCopiar_Click, 110));
        bar.Controls.Add(_filter);

        Controls.Add(_list);
        Controls.Add(top);
        Controls.Add(bar);

        Fill();
    }

    private void Fill()
    {
        _list.BeginUpdate();
        _list.Items.Clear();

        IEnumerable<ValidationIssue> q = _issues;
        if (_filter.SelectedIndex == 1) q = q.Where(i => i.Severity == IssueSeverity.Error);
        else if (_filter.SelectedIndex == 2) q = q.Where(i => i.Severity != IssueSeverity.Info);

        foreach (var i in q.OrderByDescending(i => i.Severity))
        {
            var item = new ListViewItem(i.Severity.ToString()) { BackColor = Ui.SeverityColor(i.Severity) };
            item.SubItems.Add(i.Code);
            item.SubItems.Add(i.Path ?? "");
            item.SubItems.Add(i.Message);
            _list.Items.Add(item);
        }
        _list.EndUpdate();
    }

    private void cboFiltro_SelectedIndexChanged(object? sender, EventArgs e) => Fill();

    private void btnCopiar_Click(object? sender, EventArgs e)
    {
        var text = string.Join(Environment.NewLine, _issues.Select(i => i.ToString()));
        if (text.Length > 0) Clipboard.SetText(text);
    }

    private void btnFechar_Click(object? sender, EventArgs e) => Close();
}
