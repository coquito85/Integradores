using BetaJsonIntegrator.Core;

namespace BetaJsonIntegrator.App.Forms;

/// <summary>Pesquisar, selecionar e versionar layouts.</summary>
public sealed class frmLayouts : Form
{
    private readonly ListView _list = new()
    {
        Dock = DockStyle.Fill,
        View = View.Details,
        FullRowSelect = true,
        GridLines = true,
        MultiSelect = false,
        HideSelection = false
    };

    private readonly TextBox _search = new() { Dock = DockStyle.Top };
    private IReadOnlyList<LayoutSummary> _all = Array.Empty<LayoutSummary>();

    public frmLayouts()
    {
        Text = "Layouts";
        Width = 900;
        Height = 500;
        StartPosition = FormStartPosition.CenterParent;

        _list.Columns.Add("Pasta", 120);
        _list.Columns.Add("Nome", 220);
        _list.Columns.Add("Identificador", 130);
        _list.Columns.Add("Versão", 60);
        _list.Columns.Add("Schema", 150);
        _list.Columns.Add("Atualizado", 150);
        _list.DoubleClick += lstLayouts_DoubleClick;

        _search.PlaceholderText = "Pesquisar por nome, pasta ou identificador...";
        _search.TextChanged += txtPesquisa_TextChanged;

        var bar = Ui.ButtonBar();
        bar.Controls.Add(Ui.Btn("Fechar", btnFechar_Click, 90));
        bar.Controls.Add(Ui.Btn("Atualizar schema...", btnSchema_Click, 140));
        bar.Controls.Add(Ui.Btn("Nova versão do XML...", btnNovaVersao_Click, 160));
        bar.Controls.Add(Ui.Btn("Selecionar", btnSelecionar_Click, 110));

        Controls.Add(_list);
        Controls.Add(_search);
        Controls.Add(bar);

        Reload();
    }

    private void Reload()
    {
        _all = AppEnv.Catalog.List();
        Fill();
    }

    private void Fill()
    {
        var term = _search.Text.Trim();
        _list.Items.Clear();

        foreach (var l in _all.Where(l => term.Length == 0
                     || l.FolderName.Contains(term, StringComparison.OrdinalIgnoreCase)
                     || l.FriendlyName.Contains(term, StringComparison.OrdinalIgnoreCase)
                     || l.Identifier.Contains(term, StringComparison.OrdinalIgnoreCase)))
        {
            var item = new ListViewItem(l.FolderName) { Tag = l };
            item.SubItems.Add(l.FriendlyName);
            item.SubItems.Add(l.Identifier);
            item.SubItems.Add(l.LayoutVersion);
            item.SubItems.Add(l.HasSchema ? (l.SchemaVersion ?? "sim") : "sem schema");
            item.SubItems.Add(l.UpdatedAt?.ToString("dd/MM/yyyy HH:mm") ?? "");
            if (AppEnv.Layout?.FolderName == l.FolderName) item.Font = new Font(Font, FontStyle.Bold);
            _list.Items.Add(item);
        }
    }

    private LayoutSummary? Selected() =>
        _list.SelectedItems.Count == 0 ? null : (LayoutSummary)_list.SelectedItems[0].Tag!;

    private void SelectCurrent()
    {
        var sel = Selected();
        if (sel is null) { MessageBox.Show("Selecione um layout.", Text); return; }

        try
        {
            AppEnv.Layout = AppEnv.Catalog.Load(sel.FolderName);
            AppEnv.LastRun = null;
            AppEnv.Logger.Info($"Layout selecionado: {sel.Identifier} v{sel.LayoutVersion}");
            DialogResult = DialogResult.OK;
            Close();
        }
        catch (LayoutException ex)
        {
            MessageBox.Show(ex.Message, "Layout inválido", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    private void btnSelecionar_Click(object? sender, EventArgs e) => SelectCurrent();
    private void lstLayouts_DoubleClick(object? sender, EventArgs e) => SelectCurrent();
    private void txtPesquisa_TextChanged(object? sender, EventArgs e) => Fill();
    private void btnFechar_Click(object? sender, EventArgs e) => Close();

    private void btnNovaVersao_Click(object? sender, EventArgs e)
    {
        var sel = Selected();
        if (sel is null) { MessageBox.Show("Selecione o layout que receberá a nova versão.", Text); return; }

        using var dlg = new OpenFileDialog { Filter = "XML (*.xml)|*.xml", Title = "Novo layout.xml" };
        if (dlg.ShowDialog(this) != DialogResult.OK) return;

        try
        {
            var version = AppEnv.Catalog.SaveLayoutXml(sel.FolderName, File.ReadAllText(dlg.FileName));
            MessageBox.Show($"Layout atualizado para a versão {version}. A anterior ficou em versions\\.", Text);
            if (AppEnv.Layout?.FolderName == sel.FolderName) AppEnv.ReloadLayout();
            Reload();
        }
        catch (LayoutException ex)
        {
            MessageBox.Show(ex.Message, "XML inválido", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    private void btnSchema_Click(object? sender, EventArgs e)
    {
        var sel = Selected();
        if (sel is null) { MessageBox.Show("Selecione um layout.", Text); return; }

        using var dlg = new OpenFileDialog { Filter = "JSON Schema (*.json)|*.json", Title = "schema.json" };
        if (dlg.ShowDialog(this) != DialogResult.OK) return;

        var version = frmPrompt.Ask(this, "Versão do schema", "Versão/identificação do schema (ex.: DOI 2026.1):", sel.SchemaVersion ?? "");
        if (version is null) return;

        try
        {
            AppEnv.Catalog.SaveSchema(sel.FolderName, File.ReadAllText(dlg.FileName), version);
            if (AppEnv.Layout?.FolderName == sel.FolderName) AppEnv.ReloadLayout();
            Reload();
        }
        catch (System.Text.Json.JsonException ex)
        {
            MessageBox.Show("O arquivo não é um JSON válido: " + ex.Message, "Schema inválido", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }
}
