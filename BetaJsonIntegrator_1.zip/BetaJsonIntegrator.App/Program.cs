using BetaJsonIntegrator.App.Forms;

namespace BetaJsonIntegrator.App;

internal static class Program
{
    [STAThread]
    private static void Main()
    {
        ApplicationConfiguration.Initialize();
        Application.ThreadException += Application_ThreadException;
        AppEnv.Init();
        Application.Run(new frmPrincipal());
    }

    private static void Application_ThreadException(object sender, ThreadExceptionEventArgs e)
    {
        AppEnv.Logger.Error("Exceção não tratada na interface", e.Exception);
        MessageBox.Show(e.Exception.Message, "Erro inesperado", MessageBoxButtons.OK, MessageBoxIcon.Error);
    }
}
