using System.Text.RegularExpressions;

namespace BetaJsonIntegrator.Core;

/// <summary>
/// Resolve cada campo folha do JSON em valor fixo, coluna, padrão ou pendência, seguindo a precedência:
/// 1) value literal, 2) coluna (source/Columnrefe), 3) default, 4) sem configuração = pendente.
/// Personalizações preenchem campos sem configuração (ou marcados configurable="true"); nunca inventa valores.
/// </summary>
public sealed class MappingResolver
{
    private static readonly Regex IdentifierLike = new(@"^[A-Za-z_][A-Za-z0-9_]*$", RegexOptions.Compiled);
    private readonly MappingOptions _options;

    public MappingResolver(MappingOptions? options = null) => _options = options ?? new MappingOptions();

    /// <param name="availableColumns">
    /// Colunas realmente presentes na origem por alias (após carregar os dados). Se nulo, vale o declarado no XML.
    /// </param>
    public MappingPlan Resolve(
        JsonFieldsDefinition json,
        GenerateDefinition generate,
        CustomizationSet? customizations,
        IReadOnlyDictionary<string, IReadOnlyCollection<string>>? availableColumns = null)
    {
        var plan = new MappingPlan();
        var usedCustomizations = new HashSet<CustomizationEntry>();
        var usage = new Dictionary<(string Alias, string Column), int>();

        foreach (var alias in json.Aliases)
        {
            var table = generate.Tables.FirstOrDefault(t => t.Alias.Equals(alias.Name, StringComparison.OrdinalIgnoreCase));
            if (table is null)
            {
                plan.Issues.Add(new(IssueSeverity.Error, "ALIAS_SEM_TABELA",
                    $"O alias '{alias.Name}' da estrutura JSON não corresponde a nenhuma tabela da configuração '{generate.Name}'."));
                continue;
            }

            var known = BuildKnown(table, availableColumns);
            foreach (var f in alias.Fields)
                ResolveField(f, table, known, customizations, plan, usedCustomizations, usage);
        }

        foreach (var table in generate.Tables)
        {
            availableColumns ??= null;
            IReadOnlyCollection<string>? present = null;
            var hasPresent = availableColumns is not null && availableColumns.TryGetValue(table.Alias, out present);

            foreach (var c in table.Columns)
            {
                plan.Columns.Add(new ColumnMapping
                {
                    TableAlias = table.Alias,
                    ColumnName = c.Name,
                    Description = c.Description,
                    DeclaredInXml = true,
                    PresentInSource = !hasPresent || present!.Contains(c.Name, StringComparer.OrdinalIgnoreCase),
                    UsedByFields = usage.TryGetValue((table.Alias, c.Name.ToLowerInvariant()), out var n) ? n : 0
                });
            }
        }

        if (customizations is not null)
            foreach (var e in customizations.Entries.Where(e => !usedCustomizations.Contains(e)))
                plan.Issues.Add(new(IssueSeverity.Warning, "PERSONALIZACAO_NAO_APLICADA",
                    $"A personalização do campo '{e.Path ?? e.Name}' não foi aplicada (campo inexistente, ou já configurado no XML sem configurable=\"true\")."));

        return plan;
    }

    private static HashSet<string> BuildKnown(TableDefinition table, IReadOnlyDictionary<string, IReadOnlyCollection<string>>? available)
    {
        var set = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        if (available is not null && available.TryGetValue(table.Alias, out var cols))
            foreach (var c in cols) set.Add(c);
        else
            foreach (var c in table.Columns) set.Add(c.Name);
        return set;
    }

    private void ResolveField(FieldDefinition f, TableDefinition table, HashSet<string> known, CustomizationSet? customizations,
        MappingPlan plan, HashSet<CustomizationEntry> used, Dictionary<(string, string), int> usage)
    {
        var m = new FieldMapping(f);
        plan.Set(m);

        if (f.IsContainer)
        {
            m.Kind = MappingKind.Container;
            if (f.Value is not null || f.ExplicitColumn is not null || f.Default is not null)
                plan.Issues.Add(new(IssueSeverity.Warning, "VALOR_EM_CONTAINER",
                    $"O campo '{f.Path}' é {f.TypeName} e não aceita value/source/default; eles foram ignorados."));

            foreach (var c in f.Children) ResolveField(c, table, known, customizations, plan, used, usage);
            return;
        }

        if (f.Children.Count > 0)
            plan.Issues.Add(new(IssueSeverity.Warning, "FILHOS_EM_FOLHA", $"O campo '{f.Path}' é {f.TypeName} mas tem campos filhos; eles foram ignorados."));

        ApplyXmlConfiguration(f, m, known, plan);

        var hasXmlConfig = m.Kind is MappingKind.Literal or MappingKind.Column or MappingKind.Default or MappingKind.Invalid;
        var custom = customizations?.Find(f);

        if (custom is not null && (!hasXmlConfig || f.Configurable))
        {
            // Personalização substitui o que estiver (ou o que faltar) neste campo.
            used.Add(custom);
            m.Origin = MappingOrigin.Customization;
            m.Literal = null; m.Column = null; m.Default = null; m.Message = null;

            switch (custom.Mode)
            {
                case CustomizationMode.Fixed:
                    m.Kind = MappingKind.Literal; m.Literal = custom.Value ?? "";
                    break;
                case CustomizationMode.Default:
                    m.Kind = MappingKind.Default; m.Default = custom.Value ?? "";
                    break;
                case CustomizationMode.Column:
                    m.Kind = MappingKind.Column; m.Column = custom.Source;
                    break;
            }
        }
        else if (custom is not null)
        {
            plan.Issues.Add(new(IssueSeverity.Info, "PERSONALIZACAO_IGNORADA",
                $"O campo '{f.Path}' já está configurado no XML e não é configurable; a personalização foi ignorada."));
            used.Add(custom);
        }

        ValidateResolved(f, m, known, plan, usage, table);
    }

    private void ApplyXmlConfiguration(FieldDefinition f, FieldMapping m, HashSet<string> known, MappingPlan plan)
    {
        var column = f.ExplicitColumn;

        if (f.Value is not null)
        {
            if (column is not null)
                plan.Issues.Add(new(IssueSeverity.Warning, "VALUE_E_COLUNA",
                    $"O campo '{f.Path}' declara value e uma coluna ({column}); o valor literal prevalece (precedência 1)."));

            // Formato novo (source/Columnrefe presentes) ou value sem ambiguidade: literal.
            if (column is null && known.Contains(f.Value) && f.Type is not JsonFieldType.Bool)
            {
                // XML legado: value="NomeDeColuna" aponta para uma coluna.
                m.Kind = MappingKind.Column; m.Column = f.Value; m.Default = f.Default; m.Origin = MappingOrigin.XmlLegacyValue;
                plan.Issues.Add(new(IssueSeverity.Info, "VALUE_LEGADO_COMO_COLUNA",
                    $"O campo '{f.Path}' usa value=\"{f.Value}\" como referência a coluna (formato legado). Prefira source=\"{f.Value}\"."));
                return;
            }

            if (column is null && f.Type is JsonFieldType.String or JsonFieldType.DateTime && IdentifierLike.IsMatch(f.Value)
                && !_options.TreatUnknownIdentifierValueAsLiteral && LooksLikeColumnName(f.Value))
            {
                m.Kind = MappingKind.Pending; m.Origin = MappingOrigin.XmlLegacyValue;
                m.Message = $"value=\"{f.Value}\" parece uma coluna, mas ela não existe na origem. Informe a coluna correta (source) ou confirme o valor fixo.";
                return;
            }

            m.Kind = MappingKind.Literal; m.Literal = f.Value;
            return;
        }

        if (column is not null)
        {
            m.Kind = MappingKind.Column; m.Column = column; m.Default = f.Default;
            return;
        }

        if (f.Default is not null)
        {
            m.Kind = MappingKind.Default; m.Default = f.Default;
            return;
        }

        m.Kind = MappingKind.Pending;
    }

    /// <summary>
    /// Heurística do XML legado: texto "estilo identificador" com letra maiúscula interna ou termo longo
    /// (cpfcnpjAdquirente, NrMatricula) tende a ser coluna; palavras curtas (SP, BR, SIM) tendem a ser literais.
    /// </summary>
    private static bool LooksLikeColumnName(string v) =>
        v.Length >= 6 && (v.Skip(1).Any(char.IsUpper) || v.Contains('_'));

    private void ValidateResolved(FieldDefinition f, FieldMapping m, HashSet<string> known, MappingPlan plan,
        Dictionary<(string, string), int> usage, TableDefinition table)
    {
        switch (m.Kind)
        {
            case MappingKind.Column:
                if (string.IsNullOrWhiteSpace(m.Column))
                {
                    m.Kind = MappingKind.Invalid;
                    plan.Issues.Add(new(IssueSeverity.Error, "COLUNA_VAZIA", $"O campo '{f.Path}' referencia uma coluna sem nome.", f.Path));
                    break;
                }

                var key = (table.Alias, m.Column!.ToLowerInvariant());
                usage[key] = usage.TryGetValue(key, out var n) ? n + 1 : 1;

                if (!known.Contains(m.Column))
                {
                    var declared = table.FindColumn(m.Column) is not null;
                    m.Kind = MappingKind.Invalid;
                    m.Message = declared ? "coluna declarada no XML, mas ausente na origem" : "coluna não declarada na seleção da tabela";
                    plan.Issues.Add(new(IssueSeverity.Error, declared ? "COLUNA_AUSENTE_NA_ORIGEM" : "COLUNA_INEXISTENTE",
                        $"O campo '{f.Path}' referencia a coluna '{m.Column}' ({m.Message}) da tabela '{table.Alias}'.", f.Path));
                }
                else if (m.Default is not null)
                {
                    CheckLiteral(f, m.Default, "default", plan, m);
                }
                break;

            case MappingKind.Literal:
                CheckLiteral(f, m.Literal ?? "", "value", plan, m);
                break;

            case MappingKind.Default:
                CheckLiteral(f, m.Default ?? "", "default", plan, m);
                break;

            case MappingKind.Pending:
                var description = f.Description ?? table.FindColumn(f.Name)?.Description ?? f.Name;
                plan.Pending.Add(new PendingField(f.Path, f.Name, description, f.TypeName, f.Required, f.Configurable));
                plan.Issues.Add(new(f.Required ? IssueSeverity.Error : IssueSeverity.Warning, "CAMPO_NAO_CONFIGURADO",
                    $"O campo '{f.Path}' ({f.TypeName}) não tem valor, coluna ou regra{(f.Required ? " e é obrigatório" : "; será omitido do JSON")}." +
                    (m.Message is null ? "" : " " + m.Message), f.Path));
                break;
        }
    }

    private static void CheckLiteral(FieldDefinition f, string literal, string attribute, MappingPlan plan, FieldMapping m)
    {
        var probe = JsonValueConverter.Convert(literal, f);
        if (!probe.IsError) return;

        m.Kind = MappingKind.Invalid;
        m.Message = probe.Error;
        plan.Issues.Add(new(IssueSeverity.Error, "LITERAL_INVALIDO",
            $"O {attribute} configurado no campo '{f.Path}' não é um {f.TypeName} válido: {probe.Error}", f.Path));
    }
}
