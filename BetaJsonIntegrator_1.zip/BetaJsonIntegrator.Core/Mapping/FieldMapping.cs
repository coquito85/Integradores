namespace BetaJsonIntegrator.Core;

public enum MappingKind
{
    /// <summary>array/object: sua estrutura vem dos filhos.</summary>
    Container,
    /// <summary>Valor fixo.</summary>
    Literal,
    /// <summary>Valor vem de uma coluna da origem (com default opcional como reserva).</summary>
    Column,
    /// <summary>Somente valor padrão.</summary>
    Default,
    /// <summary>Sem valor, referência nem regra: precisa de personalização.</summary>
    Pending,
    /// <summary>Referência inválida (coluna inexistente, literal inconvertível).</summary>
    Invalid
}

public enum MappingOrigin { Xml, XmlLegacyValue, Customization }

public sealed class FieldMapping
{
    public FieldDefinition Field { get; }
    public MappingKind Kind { get; set; }
    public MappingOrigin Origin { get; set; } = MappingOrigin.Xml;
    public string? Literal { get; set; }
    public string? Column { get; set; }
    public string? Default { get; set; }
    public string? Message { get; set; }

    public FieldMapping(FieldDefinition field) => Field = field;

    public override string ToString() => $"{Field.Path}: {Kind}" + (Column is not null ? $" <- {Column}" : "");
}

/// <summary>Situação de uma coluna declarada: está sendo usada? existe na origem?</summary>
public sealed class ColumnMapping
{
    public string TableAlias { get; init; } = "";
    public string ColumnName { get; init; } = "";
    public string? Description { get; init; }
    public bool DeclaredInXml { get; init; }
    public bool PresentInSource { get; init; }
    public int UsedByFields { get; set; }
}

public sealed record PendingField(string Path, string Name, string Description, string TypeName, bool Required, bool Configurable);

public sealed class MappingOptions
{
    /// <summary>
    /// No XML legado, value="algo" pode ser literal ou nome de coluna. Se não bate com nenhuma coluna e parece um
    /// identificador, o padrão é marcar como ambíguo (pendente) em vez de adivinhar. true = tratar como literal.
    /// </summary>
    public bool TreatUnknownIdentifierValueAsLiteral { get; set; }
}

public sealed class MappingPlan
{
    private readonly Dictionary<FieldDefinition, FieldMapping> _byField = new(ReferenceEqualityComparer.Instance);

    public List<PendingField> Pending { get; } = new();
    public List<ValidationIssue> Issues { get; } = new();
    public List<ColumnMapping> Columns { get; } = new();
    public IEnumerable<FieldMapping> Mappings => _byField.Values;

    public FieldMapping? Get(FieldDefinition field) => _byField.TryGetValue(field, out var m) ? m : null;
    internal void Set(FieldMapping m) => _byField[m.Field] = m;

    public bool CanGenerate => Issues.All(i => i.Severity != IssueSeverity.Error);
}
