using System.Globalization;
using System.Text.Json.Nodes;

namespace BetaJsonIntegrator.Core;

public sealed class GeneratorOptions
{
    /// <summary>Cultura para ler números/datas em texto vindos da origem (CSV). Padrão pt-BR, após tentar a invariável.</summary>
    public CultureInfo SourceCulture { get; set; } = CultureInfo.GetCultureInfo("pt-BR");
}

public sealed class GenerationResult
{
    public JsonObject Root { get; init; } = new();
    public List<ValidationIssue> Issues { get; init; } = new();
    public Dictionary<string, int> RecordsPerAlias { get; init; } = new();
}

/// <summary>Estado compartilhado durante uma geração.</summary>
internal sealed class BuildContext
{
    public required MappingPlan Plan { get; init; }
    public required GeneratorOptions Options { get; init; }
    public required IssueCollector Issues { get; init; }
    public TableDefinition? CurrentTable { get; set; }
}

/// <summary>
/// Monta o documento JSON a partir da estrutura (Jsonfields), do plano de mapeamento e dos registros.
/// Cada alias contribui com suas propriedades de topo; um array de topo gera um elemento por registro.
/// </summary>
public sealed class JsonGenerator
{
    public GenerationResult Generate(
        JsonFieldsDefinition json,
        GenerateDefinition generate,
        MappingPlan plan,
        IReadOnlyDictionary<string, RecordSet> recordSets,
        GeneratorOptions? options = null)
    {
        var ctx = new BuildContext { Plan = plan, Options = options ?? new GeneratorOptions(), Issues = new IssueCollector() };
        var root = new JsonObject();
        var counts = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);

        foreach (var alias in json.Aliases)
        {
            var table = generate.Tables.FirstOrDefault(t => t.Alias.Equals(alias.Name, StringComparison.OrdinalIgnoreCase));
            if (table is null) continue; // já reportado pelo MappingResolver

            ctx.CurrentTable = table;
            var rows = recordSets.TryGetValue(alias.Name, out var rs) ? rs.Rows : null;
            if (rows is null)
            {
                ctx.Issues.Add(IssueSeverity.Error, "ORIGEM_AUSENTE", $"Sem registros carregados para o alias '{alias.Name}'.");
                continue;
            }
            counts[alias.Name] = rows.Count;

            foreach (var field in alias.Fields)
            {
                if (root.ContainsKey(field.Name))
                {
                    ctx.Issues.Add(IssueSeverity.Error, "PROPRIEDADE_DUPLICADA", $"A propriedade de topo '{field.Name}' é definida por mais de um alias.");
                    continue;
                }

                var node = field.Type == JsonFieldType.Array
                    ? JsonArrayBuilder.BuildTopLevel(field, rows, ctx)
                    : JsonObjectBuilder.BuildProperty(field, rows.Count > 0 ? rows[0] : null, field.Name, ctx);

                if (node is not null) root[field.Name] = node;
            }
        }

        return new GenerationResult { Root = root, Issues = ctx.Issues.ToList(), RecordsPerAlias = counts };
    }
}

/// <summary>Monta objetos e propriedades escalares.</summary>
internal static class JsonObjectBuilder
{
    public static JsonObject BuildObject(IEnumerable<FieldDefinition> fields, DataRecord? record, string path, BuildContext ctx)
    {
        var obj = new JsonObject();
        foreach (var f in fields)
        {
            var node = BuildProperty(f, record, path + "." + f.Name, ctx);
            if (node is not null) obj[f.Name] = node;
        }
        return obj;
    }

    /// <summary>Devolve o nó da propriedade ou null quando ela deve ser omitida.</summary>
    public static JsonNode? BuildProperty(FieldDefinition f, DataRecord? record, string path, BuildContext ctx)
    {
        switch (f.Type)
        {
            case JsonFieldType.Array:
                return JsonArrayBuilder.BuildNested(f, record, path, ctx);
            case JsonFieldType.Object:
                return BuildObject(f.Children, record, path, ctx);
        }

        var mapping = ctx.Plan.Get(f);
        if (mapping is null || mapping.Kind is MappingKind.Pending or MappingKind.Invalid)
            return null; // já reportado no mapeamento; nunca inventa valor

        object? raw;
        string? columnFormat = null;

        switch (mapping.Kind)
        {
            case MappingKind.Literal:
                raw = mapping.Literal;
                break;

            case MappingKind.Column:
                if (record is null) { raw = null; }
                else
                {
                    raw = record[mapping.Column!];
                    columnFormat = ctx.CurrentTable?.FindColumn(mapping.Column!)?.Format;
                }
                if (raw is null or DBNull) raw = mapping.Default; // precedência 3: default como reserva
                break;

            case MappingKind.Default:
                raw = mapping.Default;
                break;

            default:
                return null;
        }

        var result = JsonValueConverter.Convert(raw, f, columnFormat, ctx.Options.SourceCulture);

        if (result.IsError)
        {
            ctx.Issues.Add(IssueSeverity.Error, "VALOR_INVALIDO",
                $"Campo '{f.Path}'" + (mapping.Column is not null ? $" (coluna {mapping.Column})" : "") + $": {result.Error}", path);
            return null;
        }

        if (result.IsNull)
        {
            if (f.Required)
                ctx.Issues.Add(IssueSeverity.Error, "VALOR_OBRIGATORIO_NULO",
                    $"Campo obrigatório '{f.Path}' sem valor" + (mapping.Column is not null ? $" na coluna {mapping.Column}" : "") + ".", path);
            else
                ctx.Issues.Add(IssueSeverity.Info, "VALOR_NULO_OMITIDO",
                    $"Campo '{f.Path}' sem valor; propriedade omitida.", path);
            return null;
        }

        return result.Node;
    }
}

/// <summary>Monta arrays: de topo (um item por registro) e aninhados.</summary>
internal static class JsonArrayBuilder
{
    /// <summary>Um elemento para cada registro da origem (ex.: uma declaração por registro).</summary>
    public static JsonArray BuildTopLevel(FieldDefinition array, IReadOnlyList<DataRecord> rows, BuildContext ctx)
    {
        var result = new JsonArray();
        if (array.Children.Count == 0) return result;

        for (var i = 0; i < rows.Count; i++)
            result.Add(JsonObjectBuilder.BuildObject(array.Children, rows[i], $"{array.Name}[{i}]", ctx));
        return result;
    }

    /// <summary>
    /// Array dentro de um item: sem filhos é uma coleção vazia declarada no XML; com filhos gera um elemento
    /// a partir do registro corrente. (Agrupamento por chave/origem própria é a evolução prevista na especificação, item 8.)
    /// </summary>
    public static JsonArray BuildNested(FieldDefinition array, DataRecord? record, string path, BuildContext ctx)
    {
        var result = new JsonArray();
        if (array.Children.Count == 0)
        {
            ctx.Issues.Add(IssueSeverity.Info, "ARRAY_VAZIO_DECLARADO",
                $"O array '{array.Path}' não tem origem nem campos e foi gerado vazio.", path);
            return result;
        }

        result.Add(JsonObjectBuilder.BuildObject(array.Children, record, path + "[0]", ctx));
        return result;
    }
}
