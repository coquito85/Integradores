using System.Globalization;
using System.Text.Json.Nodes;

namespace BetaJsonIntegrator.Core;

public sealed class ConversionResult
{
    public JsonNode? Node { get; init; }
    public string? Error { get; init; }
    public bool IsNull => Node is null && Error is null;
    public bool IsError => Error is not null;

    public static ConversionResult Null() => new();
    public static ConversionResult Ok(JsonNode node) => new() { Node = node };
    public static ConversionResult Fail(string error) => new() { Error = error };
}

/// <summary>
/// Conversão para o tipo JSON do campo: números nunca viram texto, decimais usam cultura invariável,
/// datas saem no formato configurado (padrão yyyy-MM-dd) e strings preservam zeros à esquerda.
/// Mensagens de erro não incluem o valor convertido (pode ser dado pessoal).
/// </summary>
public static class JsonValueConverter
{
    public const string DefaultDateFormat = "yyyy-MM-dd";
    private static readonly CultureInfo Inv = CultureInfo.InvariantCulture;
    private static readonly CultureInfo PtBr = CultureInfo.GetCultureInfo("pt-BR");
    private const decimal Normalizer = 1.000000000000000000000000000000000m;

    public static ConversionResult Convert(object? raw, FieldDefinition field, string? columnFormat = null, CultureInfo? sourceCulture = null)
    {
        sourceCulture ??= PtBr;
        if (raw is null or DBNull) return ConversionResult.Null();
        if (raw is string s0 && field.Type != JsonFieldType.String && string.IsNullOrWhiteSpace(s0)) return ConversionResult.Null();

        try
        {
            return field.Type switch
            {
                JsonFieldType.String => ToStringNode(raw, field, columnFormat),
                JsonFieldType.Bool => ToBool(raw, field),
                JsonFieldType.Decimal => ToDecimal(raw, sourceCulture),
                JsonFieldType.Integer => ToInteger(raw, sourceCulture),
                JsonFieldType.DateTime => ToDate(raw, field, columnFormat, sourceCulture),
                _ => ConversionResult.Fail($"Tipo '{field.TypeName}' não pode receber valor escalar.")
            };
        }
        catch (Exception ex) when (ex is FormatException or OverflowException or InvalidCastException)
        {
            return ConversionResult.Fail($"Valor não convertível para {field.TypeName}.");
        }
    }

    private static ConversionResult ToStringNode(object raw, FieldDefinition field, string? columnFormat)
    {
        switch (raw)
        {
            case string s: return ConversionResult.Ok(JsonValue.Create(s)!);
            case bool b: return ConversionResult.Ok(JsonValue.Create(b ? "true" : "false")!);
            case DateTime dt: return ConversionResult.Ok(JsonValue.Create(dt.ToString(field.Format ?? columnFormat ?? DefaultDateFormat, Inv))!);
            case DateTimeOffset dto: return ConversionResult.Ok(JsonValue.Create(dto.ToString(field.Format ?? columnFormat ?? DefaultDateFormat, Inv))!);
            case DateOnly d: return ConversionResult.Ok(JsonValue.Create(d.ToString(field.Format ?? columnFormat ?? DefaultDateFormat, Inv))!);
            case byte[]: return ConversionResult.Fail("Valor binário não pode ser convertido para string.");
            case IFormattable f: return ConversionResult.Ok(JsonValue.Create(f.ToString(null, Inv))!);
            default: return ConversionResult.Ok(JsonValue.Create(raw.ToString() ?? "")!);
        }
    }

    private static ConversionResult ToBool(object raw, FieldDefinition field)
    {
        switch (raw)
        {
            case bool b: return ConversionResult.Ok(JsonValue.Create(b)!);
            case string s:
                var t = s.Trim();
                if (field.TrueValues?.Any(v => v.Equals(t, StringComparison.OrdinalIgnoreCase)) == true) return ConversionResult.Ok(JsonValue.Create(true)!);
                if (field.FalseValues?.Any(v => v.Equals(t, StringComparison.OrdinalIgnoreCase)) == true) return ConversionResult.Ok(JsonValue.Create(false)!);
                if (t.Equals("true", StringComparison.OrdinalIgnoreCase) || t == "1") return ConversionResult.Ok(JsonValue.Create(true)!);
                if (t.Equals("false", StringComparison.OrdinalIgnoreCase) || t == "0") return ConversionResult.Ok(JsonValue.Create(false)!);
                return ConversionResult.Fail("Valor booleano não reconhecido (use true/false/1/0 ou trueValues/falseValues).");
            case sbyte or byte or short or ushort or int or uint or long or ulong or decimal:
                var n = System.Convert.ToDecimal(raw, Inv);
                if (n == 1) return ConversionResult.Ok(JsonValue.Create(true)!);
                if (n == 0) return ConversionResult.Ok(JsonValue.Create(false)!);
                return ConversionResult.Fail("Número não representa booleano (apenas 0 ou 1).");
            default:
                return ConversionResult.Fail("Tipo de origem não conversível para bool.");
        }
    }

    private static ConversionResult ToDecimal(object raw, CultureInfo sourceCulture)
    {
        if (!TryDecimal(raw, sourceCulture, out var d)) return ConversionResult.Fail("Valor numérico inválido.");
        return ConversionResult.Ok(JsonValue.Create(d / Normalizer)!);
    }

    private static ConversionResult ToInteger(object raw, CultureInfo sourceCulture)
    {
        if (!TryDecimal(raw, sourceCulture, out var d)) return ConversionResult.Fail("Valor inteiro inválido.");
        if (d != decimal.Truncate(d)) return ConversionResult.Fail("Valor não é inteiro.");
        if (d < long.MinValue || d > long.MaxValue) return ConversionResult.Fail("Inteiro fora da faixa.");
        return ConversionResult.Ok(JsonValue.Create((long)d)!);
    }

    private static bool TryDecimal(object raw, CultureInfo sourceCulture, out decimal d)
    {
        switch (raw)
        {
            case decimal x: d = x; return true;
            case double db: d = double.IsFinite(db) ? (decimal)db : 0; return double.IsFinite(db);
            case float fl: d = float.IsFinite(fl) ? (decimal)fl : 0; return float.IsFinite(fl);
            case sbyte or byte or short or ushort or int or uint or long or ulong:
                d = System.Convert.ToDecimal(raw, Inv); return true;
            case string s:
                s = s.Trim();
                // Invariável primeiro ("1234.56"); só então a cultura da origem ("1234,56").
                return decimal.TryParse(s, NumberStyles.Float, Inv, out d)
                       || decimal.TryParse(s, NumberStyles.Float | NumberStyles.AllowThousands, sourceCulture, out d);
            default:
                d = 0; return false;
        }
    }

    private static ConversionResult ToDate(object raw, FieldDefinition field, string? columnFormat, CultureInfo sourceCulture)
    {
        DateTime dt;
        switch (raw)
        {
            case DateTime x: dt = x; break;
            case DateTimeOffset o: dt = o.DateTime; break;
            case DateOnly o: dt = o.ToDateTime(TimeOnly.MinValue); break;
            case string s:
                s = s.Trim();
                if (!string.IsNullOrEmpty(field.SourceFormat))
                {
                    if (!DateTime.TryParseExact(s, field.SourceFormat, Inv, DateTimeStyles.None, out dt))
                        return ConversionResult.Fail($"Data fora do formato de leitura '{field.SourceFormat}'.");
                }
                else if (!DateTime.TryParse(s, sourceCulture, DateTimeStyles.None, out dt)
                         && !DateTime.TryParse(s, Inv, DateTimeStyles.None, out dt))
                {
                    return ConversionResult.Fail("Data inválida.");
                }
                break;
            default:
                return ConversionResult.Fail("Tipo de origem não conversível para data.");
        }

        return ConversionResult.Ok(JsonValue.Create(dt.ToString(field.Format ?? columnFormat ?? DefaultDateFormat, Inv))!);
    }
}
