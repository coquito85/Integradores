using System.Xml;
using System.Xml.Linq;

namespace BetaJsonIntegrator.Core;

public sealed class ParseResult
{
    public LayoutDefinition Layout { get; }
    public List<ValidationIssue> Issues { get; } = new();
    public ParseResult(LayoutDefinition layout) => Layout = layout;
}

/// <summary>
/// Converte o XML em modelos. Aceita o XML legado (Columnrefe, formate, Refealias, Jsonfields) e o formato
/// novo (source, format, default, required, configurable). Nomes de elementos e atributos não diferenciam
/// maiúsculas/minúsculas.
/// </summary>
public static class XmlLayoutParser
{
    public static ParseResult Parse(XDocument doc)
    {
        var root = doc.Root ?? throw new LayoutException("XML sem elemento raiz.");
        var layout = new LayoutDefinition
        {
            Name = Attr(root, "name") ?? "",
            Identifier = Attr(root, "identifier", "id") ?? "",
            Version = Attr(root, "version")
        };
        var result = new ParseResult(layout);

        if (!Is(root, "layout"))
            result.Issues.Add(new(IssueSeverity.Warning, "RAIZ_INESPERADA", $"Elemento raiz '{root.Name.LocalName}' em vez de 'Layout'."));

        foreach (var gen in root.Elements().Where(e => Is(e, "generate")))
            layout.Generates.Add(ParseGenerate(gen, result));

        foreach (var js in root.Descendants().Where(e => Is(e, "jsonfields")))
            layout.JsonDefinitions.Add(ParseJsonFields(js, result));

        return result;
    }

    private static GenerateDefinition ParseGenerate(XElement el, ParseResult result)
    {
        var gen = new GenerateDefinition { Name = Attr(el, "name") ?? "" };
        foreach (var t in el.Elements().Where(e => Is(e, "table")))
        {
            var table = new TableDefinition { Name = Attr(t, "name") ?? "", Alias = Attr(t, "alias") ?? "" };
            if (table.Alias.Length == 0) table.Alias = table.Name;

            foreach (var c in t.Descendants().Where(e => Is(e, "column")))
            {
                var typeName = Attr(c, "type") ?? "string";
                var type = JsonFieldTypes.Parse(typeName);
                if (type == JsonFieldType.Unknown)
                    result.Issues.Add(new(IssueSeverity.Error, "TIPO_DESCONHECIDO",
                        $"Coluna '{Attr(c, "name")}' da tabela '{table.Alias}' tem tipo desconhecido '{typeName}'.", Where(c)));

                table.Columns.Add(new ColumnDefinition
                {
                    Name = Attr(c, "name") ?? "",
                    TypeName = typeName,
                    Type = type == JsonFieldType.Unknown ? JsonFieldType.String : type,
                    OrderBy = Bool(Attr(c, "orderby")),
                    Description = Attr(c, "description"),
                    Format = Attr(c, "formate", "format")
                });
            }
            gen.Tables.Add(table);
        }
        return gen;
    }

    private static JsonFieldsDefinition ParseJsonFields(XElement el, ParseResult result)
    {
        var def = new JsonFieldsDefinition { Name = Attr(el, "name") ?? "" };
        foreach (var a in el.Elements().Where(e => Is(e, "refealias", "refalias", "aliasref", "alias")))
        {
            var alias = new AliasDefinition { Name = Attr(a, "name") ?? "" };
            foreach (var f in a.Elements().Where(e => Is(e, "field")))
                alias.Fields.Add(ParseField(f, null, alias, result));
            def.Aliases.Add(alias);
        }
        return def;
    }

    private static FieldDefinition ParseField(XElement el, FieldDefinition? parent, AliasDefinition alias, ParseResult result)
    {
        var childEls = el.Elements().Where(e => Is(e, "field")).ToList();
        var typeName = Attr(el, "type") ?? (childEls.Count > 0 ? "object" : "");
        var type = JsonFieldTypes.Parse(typeName);

        var f = new FieldDefinition
        {
            Name = Attr(el, "name") ?? "",
            TypeName = typeName,
            Type = type,
            Value = Attr(el, "value"),
            Source = Attr(el, "source"),
            ColumnRef = Attr(el, "columnrefe", "columnref"),
            Format = Attr(el, "formate", "format"),
            SourceFormat = Attr(el, "sourceformat"),
            Default = Attr(el, "default"),
            Required = Bool(Attr(el, "required")),
            Configurable = Bool(Attr(el, "configurable")),
            Description = Attr(el, "description"),
            TrueValues = List(Attr(el, "truevalues")),
            FalseValues = List(Attr(el, "falsevalues")),
            Parent = parent,
            Alias = alias
        };

        if (type == JsonFieldType.Unknown)
            result.Issues.Add(new(IssueSeverity.Error, "TIPO_DESCONHECIDO",
                string.IsNullOrEmpty(typeName)
                    ? $"Campo '{f.Name}' sem atributo type."
                    : $"Campo '{f.Name}' tem tipo desconhecido '{typeName}'.", Where(el)));

        foreach (var c in childEls) f.Children.Add(ParseField(c, f, alias, result));
        return f;
    }

    // ---------- helpers ----------

    private static bool Is(XElement e, params string[] names) =>
        names.Any(n => e.Name.LocalName.Equals(n, StringComparison.OrdinalIgnoreCase));

    private static string? Attr(XElement e, params string[] names)
    {
        foreach (var a in e.Attributes())
            if (names.Any(n => a.Name.LocalName.Equals(n, StringComparison.OrdinalIgnoreCase)))
                return a.Value;
        return null;
    }

    private static bool Bool(string? v) => v is not null && (v.Equals("true", StringComparison.OrdinalIgnoreCase) || v == "1");

    private static string[]? List(string? v) =>
        string.IsNullOrWhiteSpace(v) ? null : v.Split(',', StringSplitOptions.TrimEntries | StringSplitOptions.RemoveEmptyEntries);

    private static string Where(XElement e) =>
        e is IXmlLineInfo li && li.HasLineInfo() ? $"linha {li.LineNumber}" : e.Name.LocalName;
}
