using System.Xml.Linq;

namespace BetaJsonIntegrator.Core;

public enum CustomizationMode { Fixed, Column, Default }

/// <summary>Uma personalização de campo (arquivo separado do layout original).</summary>
public sealed class CustomizationEntry
{
    public string Name { get; set; } = "";

    /// <summary>Opcional: caminho de definição (declaracoes.adquirentes.ni) para campos com nome repetido.</summary>
    public string? Path { get; set; }
    public string? TypeName { get; set; }
    public CustomizationMode Mode { get; set; } = CustomizationMode.Fixed;
    public string? Value { get; set; }
    public string? Source { get; set; }
}

public sealed class CustomizationSet
{
    public string LayoutIdentifier { get; set; } = "";
    public string Version { get; set; } = "1";
    public List<CustomizationEntry> Entries { get; } = new();

    /// <summary>Procura primeiro por caminho completo e depois pelo nome do campo.</summary>
    public CustomizationEntry? Find(FieldDefinition field) =>
        Entries.FirstOrDefault(e => e.Path is not null && e.Path.Equals(field.Path, StringComparison.OrdinalIgnoreCase))
        ?? Entries.FirstOrDefault(e => e.Path is null && e.Name.Equals(field.Name, StringComparison.OrdinalIgnoreCase));

    public void Set(CustomizationEntry entry)
    {
        Entries.RemoveAll(e => e.Name.Equals(entry.Name, StringComparison.OrdinalIgnoreCase)
                               && string.Equals(e.Path, entry.Path, StringComparison.OrdinalIgnoreCase));
        Entries.Add(entry);
    }
}

public static class CustomizationStore
{
    public static CustomizationSet Load(string path)
    {
        if (!File.Exists(path)) return new CustomizationSet();
        return Parse(XmlLayoutReader.LoadFile(path));
    }

    public static CustomizationSet Parse(XDocument doc)
    {
        var root = doc.Root ?? throw new LayoutException("Arquivo de personalizações vazio.");
        var set = new CustomizationSet
        {
            LayoutIdentifier = Get(root, "layout") ?? "",
            Version = Get(root, "version") ?? "1"
        };

        foreach (var e in root.Elements().Where(e => e.Name.LocalName.Equals("field", StringComparison.OrdinalIgnoreCase)))
        {
            var source = Get(e, "source");
            var modeText = Get(e, "mode");
            var mode = modeText?.ToLowerInvariant() switch
            {
                "column" => CustomizationMode.Column,
                "default" => CustomizationMode.Default,
                "fixed" => CustomizationMode.Fixed,
                _ => source is not null ? CustomizationMode.Column : CustomizationMode.Fixed
            };

            set.Entries.Add(new CustomizationEntry
            {
                Name = Get(e, "name") ?? "",
                Path = Get(e, "path"),
                TypeName = Get(e, "type"),
                Mode = mode,
                Value = Get(e, "value"),
                Source = source
            });
        }
        return set;
    }

    public static void Save(string path, CustomizationSet set)
    {
        var root = new XElement("Customizations",
            new XAttribute("layout", set.LayoutIdentifier),
            new XAttribute("version", set.Version));

        foreach (var e in set.Entries)
        {
            var el = new XElement("field", new XAttribute("name", e.Name));
            if (!string.IsNullOrEmpty(e.Path)) el.Add(new XAttribute("path", e.Path));
            if (!string.IsNullOrEmpty(e.TypeName)) el.Add(new XAttribute("type", e.TypeName));
            if (e.Mode == CustomizationMode.Column) el.Add(new XAttribute("source", e.Source ?? ""));
            else el.Add(new XAttribute("value", e.Value ?? ""));
            el.Add(new XAttribute("mode", e.Mode.ToString().ToLowerInvariant()));
            root.Add(el);
        }

        var dir = Path.GetDirectoryName(Path.GetFullPath(path));
        if (!string.IsNullOrEmpty(dir)) Directory.CreateDirectory(dir);
        new XDocument(new XDeclaration("1.0", "utf-8", null), root).Save(path);
    }

    private static string? Get(XElement e, string name) =>
        e.Attributes().FirstOrDefault(a => a.Name.LocalName.Equals(name, StringComparison.OrdinalIgnoreCase))?.Value;
}
