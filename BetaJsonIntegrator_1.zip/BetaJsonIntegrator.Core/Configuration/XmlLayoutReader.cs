using System.Xml;
using System.Xml.Linq;

namespace BetaJsonIntegrator.Core;

public sealed class LayoutException : Exception
{
    public LayoutException(string message, Exception? inner = null) : base(message, inner) { }
}

/// <summary>Leitura do XML com proteção contra XXE: DTD proibido e sem resolvedor externo.</summary>
public static class XmlLayoutReader
{
    private static XmlReaderSettings SecureSettings() => new()
    {
        DtdProcessing = DtdProcessing.Prohibit,
        XmlResolver = null,
        IgnoreComments = true,
        IgnoreProcessingInstructions = true,
        MaxCharactersFromEntities = 0,
        MaxCharactersInDocument = 50_000_000
    };

    public static XDocument LoadFile(string path)
    {
        try
        {
            using var stream = File.OpenRead(path);
            using var reader = XmlReader.Create(stream, SecureSettings());
            return XDocument.Load(reader, LoadOptions.SetLineInfo);
        }
        catch (XmlException ex)
        {
            throw new LayoutException($"XML inválido em '{Path.GetFileName(path)}': {ex.Message}", ex);
        }
    }

    public static XDocument LoadText(string xml)
    {
        try
        {
            using var sr = new StringReader(xml);
            using var reader = XmlReader.Create(sr, SecureSettings());
            return XDocument.Load(reader, LoadOptions.SetLineInfo);
        }
        catch (XmlException ex)
        {
            throw new LayoutException($"XML inválido: {ex.Message}", ex);
        }
    }
}
