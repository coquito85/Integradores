namespace BetaJsonIntegrator.Core;

public enum JsonFieldType { Unknown, String, Bool, Decimal, Integer, DateTime, Array, Object }

public static class JsonFieldTypes
{
    public static JsonFieldType Parse(string? name) => name?.Trim().ToLowerInvariant() switch
    {
        "string" or "text" => JsonFieldType.String,
        "bool" or "boolean" => JsonFieldType.Bool,
        "decimal" or "number" or "double" or "float" => JsonFieldType.Decimal,
        "integer" or "int" or "long" => JsonFieldType.Integer,
        "datetime" or "date" => JsonFieldType.DateTime,
        "array" => JsonFieldType.Array,
        "object" => JsonFieldType.Object,
        _ => JsonFieldType.Unknown
    };
}

/// <summary>Elemento &lt;Layout&gt;: identificação e as configurações de geração/JSON.</summary>
public sealed class LayoutDefinition
{
    public string Name { get; set; } = "";
    public string Identifier { get; set; } = "";
    public string? Version { get; set; }
    public List<GenerateDefinition> Generates { get; } = new();
    public List<JsonFieldsDefinition> JsonDefinitions { get; } = new();
}

public sealed class GenerateDefinition
{
    public string Name { get; set; } = "";
    public List<TableDefinition> Tables { get; } = new();
}

public sealed class TableDefinition
{
    public string Name { get; set; } = "";
    public string Alias { get; set; } = "";
    public List<ColumnDefinition> Columns { get; } = new();

    public ColumnDefinition? FindColumn(string name) =>
        Columns.FirstOrDefault(c => c.Name.Equals(name, StringComparison.OrdinalIgnoreCase));
}

public sealed class ColumnDefinition
{
    public string Name { get; set; } = "";
    public string TypeName { get; set; } = "string";
    public JsonFieldType Type { get; set; } = JsonFieldType.String;
    public bool OrderBy { get; set; }
    public string? Description { get; set; }
    public string? Format { get; set; }
}

public sealed class JsonFieldsDefinition
{
    public string Name { get; set; } = "";
    public List<AliasDefinition> Aliases { get; } = new();
}

/// <summary>&lt;Refealias name="TAB_X"&gt;: vincula a estrutura JSON a um alias de origem.</summary>
public sealed class AliasDefinition
{
    public string Name { get; set; } = "";
    public List<FieldDefinition> Fields { get; } = new();
}

public sealed class FieldDefinition
{
    public string Name { get; set; } = "";
    public string TypeName { get; set; } = "";
    public JsonFieldType Type { get; set; }

    /// <summary>Atributo value (null = ausente). No XML legado pode ser literal ou nome de coluna.</summary>
    public string? Value { get; set; }

    /// <summary>Atributo source (referência explícita a coluna, formato novo).</summary>
    public string? Source { get; set; }

    /// <summary>Atributo Columnrefe (referência a coluna, formato legado).</summary>
    public string? ColumnRef { get; set; }

    /// <summary>Formato de saída (atributo formate/format), ex.: yyyy-MM-dd.</summary>
    public string? Format { get; set; }

    /// <summary>Formato de leitura quando a origem entrega texto (sourceFormat), ex.: dd/MM/yyyy.</summary>
    public string? SourceFormat { get; set; }

    public string? Default { get; set; }
    public bool Required { get; set; }
    public bool Configurable { get; set; }
    public string? Description { get; set; }
    public string[]? TrueValues { get; set; }
    public string[]? FalseValues { get; set; }

    public List<FieldDefinition> Children { get; } = new();
    public FieldDefinition? Parent { get; set; }
    public AliasDefinition? Alias { get; set; }

    public bool IsContainer => Type is JsonFieldType.Array or JsonFieldType.Object;

    /// <summary>Caminho de definição: declaracoes.adquirentes.ni</summary>
    public string Path => Parent is null ? Name : Parent.Path + "." + Name;

    /// <summary>Coluna referenciada de forma explícita (source ou Columnrefe).</summary>
    public string? ExplicitColumn => !string.IsNullOrWhiteSpace(Source) ? Source : (!string.IsNullOrWhiteSpace(ColumnRef) ? ColumnRef : null);

    public override string ToString() => $"{Path} ({TypeName})";
}
