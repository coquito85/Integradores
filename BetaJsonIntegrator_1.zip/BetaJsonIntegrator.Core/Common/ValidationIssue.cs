namespace BetaJsonIntegrator.Core;

public enum IssueSeverity { Info, Warning, Error }

/// <summary>Mensagem de validação. Nunca carrega valores de dados (dados pessoais), só nomes e caminhos.</summary>
public sealed record ValidationIssue(IssueSeverity Severity, string Code, string Message, string? Path = null)
{
    public override string ToString() => $"[{Severity}] {Code}: {Message}{(Path is null ? "" : " @ " + Path)}";
}

/// <summary>
/// Agrupa ocorrências repetidas (mesmo código no mesmo campo da definição) em uma só mensagem com contagem,
/// para que 10 mil registros com o mesmo problema não gerem 10 mil linhas.
/// </summary>
public sealed class IssueCollector
{
    private sealed class Entry
    {
        public IssueSeverity Severity;
        public string Code = "";
        public string Message = "";
        public string? FirstPath;
        public int Count;
    }

    private readonly Dictionary<string, Entry> _entries = new();
    private readonly List<string> _order = new();
    private readonly List<ValidationIssue> _plain = new();

    public void Add(IssueSeverity severity, string code, string message, string? path = null)
    {
        var key = $"{severity}|{code}|{message}|{Normalize(path)}";
        if (!_entries.TryGetValue(key, out var e))
        {
            e = new Entry { Severity = severity, Code = code, Message = message, FirstPath = path };
            _entries[key] = e;
            _order.Add(key);
        }
        e.Count++;
    }

    public void Add(ValidationIssue issue) => _plain.Add(issue);
    public void AddRange(IEnumerable<ValidationIssue> issues) => _plain.AddRange(issues);

    public bool HasErrors => _plain.Any(i => i.Severity == IssueSeverity.Error) || _entries.Values.Any(e => e.Severity == IssueSeverity.Error);

    public List<ValidationIssue> ToList()
    {
        var list = new List<ValidationIssue>(_plain);
        foreach (var key in _order)
        {
            var e = _entries[key];
            var msg = e.Count > 1 ? $"{e.Message} ({e.Count} ocorrências; primeira em {e.FirstPath ?? "?"})" : e.Message;
            list.Add(new ValidationIssue(e.Severity, e.Code, msg, e.FirstPath));
        }
        return list;
    }

    /// <summary>declaracoes[12].ni → declaracoes[].ni</summary>
    private static string Normalize(string? path) =>
        path is null ? "" : System.Text.RegularExpressions.Regex.Replace(path, @"\[\d+\]", "[]");
}

public sealed class ValidationReport
{
    public string Layout { get; set; } = "";
    public string Identifier { get; set; } = "";
    public string? LayoutVersion { get; set; }
    public string? SchemaVersion { get; set; }
    public DateTimeOffset ExecutedAt { get; set; } = DateTimeOffset.Now;
    public string Source { get; set; } = "";
    public double DurationSeconds { get; set; }
    public string LayoutHash { get; set; } = "";
    public Dictionary<string, int> RecordCounts { get; set; } = new();
    public List<ValidationIssue> Issues { get; set; } = new();

    public int ErrorCount => Issues.Count(i => i.Severity == IssueSeverity.Error);
    public int WarningCount => Issues.Count(i => i.Severity == IssueSeverity.Warning);
    public bool IsValid => ErrorCount == 0;
}
