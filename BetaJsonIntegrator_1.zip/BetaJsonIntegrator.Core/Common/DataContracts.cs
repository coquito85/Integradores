using System.Globalization;

namespace BetaJsonIntegrator.Core;

/// <summary>Um registro da origem. Nomes de coluna não diferenciam maiúsculas/minúsculas.</summary>
public sealed class DataRecord
{
    private readonly Dictionary<string, object?> _values = new(StringComparer.OrdinalIgnoreCase);

    public DataRecord() { }

    public DataRecord(IEnumerable<KeyValuePair<string, object?>> values)
    {
        foreach (var kv in values) _values[kv.Key] = kv.Value;
    }

    public object? this[string column]
    {
        get => _values.TryGetValue(column, out var v) ? v : null;
        set => _values[column] = value;
    }

    public bool TryGetValue(string column, out object? value) => _values.TryGetValue(column, out value);
    public bool Contains(string column) => _values.ContainsKey(column);
    public IEnumerable<string> Columns => _values.Keys;
}

/// <summary>Registros de uma tabela lógica (alias) mais a lista de colunas realmente disponíveis.</summary>
public sealed class RecordSet
{
    public string Alias { get; }
    public IReadOnlyList<string> Columns { get; }
    public List<DataRecord> Rows { get; }

    public RecordSet(string alias, IReadOnlyList<string> columns, List<DataRecord> rows)
    {
        Alias = alias;
        Columns = columns;
        Rows = rows;
    }
}

public enum FilterOperator { Equal, NotEqual, LessThan, LessOrEqual, GreaterThan, GreaterOrEqual, Like }

/// <summary>Filtro simples aplicado na origem (ex.: período de DtAto). Valores sempre parametrizados.</summary>
public sealed record SourceFilter(string Column, FilterOperator Operator, object? Value, string? Alias = null);

public sealed class SourceException : Exception
{
    public SourceException(string message, Exception? inner = null) : base(message, inner) { }
}

/// <summary>
/// Contrato comum das fontes de dados (banco, CSV, memória). O Core só conhece esta interface.
/// </summary>
public interface IRecordSource
{
    string Description { get; }

    Task<RecordSet> LoadAsync(TableDefinition table, IReadOnlyList<SourceFilter> filters, CancellationToken cancellationToken = default);
}

/// <summary>Comparação tolerante usada para ordenar e filtrar registros fora do SQL (CSV, memória).</summary>
public static class RecordValueComparer
{
    public static int Compare(object? a, object? b)
    {
        if (a is null or DBNull) return b is null or DBNull ? 0 : -1;
        if (b is null or DBNull) return 1;

        if (TryDecimal(a, out var da) && TryDecimal(b, out var db)) return da.CompareTo(db);
        if (TryDate(a, out var ta) && TryDate(b, out var tb)) return ta.CompareTo(tb);

        return string.Compare(Convert.ToString(a, CultureInfo.InvariantCulture), Convert.ToString(b, CultureInfo.InvariantCulture), StringComparison.OrdinalIgnoreCase);
    }

    public static bool Matches(object? value, FilterOperator op, object? expected)
    {
        if (op == FilterOperator.Like)
        {
            var text = Convert.ToString(value, CultureInfo.InvariantCulture) ?? "";
            var pattern = Convert.ToString(expected, CultureInfo.InvariantCulture) ?? "";
            var rx = "^" + System.Text.RegularExpressions.Regex.Escape(pattern).Replace("%", ".*").Replace("_", ".") + "$";
            return System.Text.RegularExpressions.Regex.IsMatch(text, rx, System.Text.RegularExpressions.RegexOptions.IgnoreCase | System.Text.RegularExpressions.RegexOptions.Singleline);
        }

        var c = Compare(value, expected);
        return op switch
        {
            FilterOperator.Equal => c == 0,
            FilterOperator.NotEqual => c != 0,
            FilterOperator.LessThan => c < 0,
            FilterOperator.LessOrEqual => c <= 0,
            FilterOperator.GreaterThan => c > 0,
            FilterOperator.GreaterOrEqual => c >= 0,
            _ => false
        };
    }

    private static bool TryDecimal(object v, out decimal d)
    {
        switch (v)
        {
            case decimal x: d = x; return true;
            case int or long or short or byte or float or double:
                d = Convert.ToDecimal(v, CultureInfo.InvariantCulture); return true;
            case string s:
                return decimal.TryParse(s, NumberStyles.Float, CultureInfo.InvariantCulture, out d);
            default: d = 0; return false;
        }
    }

    private static bool TryDate(object v, out DateTime d)
    {
        switch (v)
        {
            case DateTime x: d = x; return true;
            case DateTimeOffset o: d = o.DateTime; return true;
            case DateOnly o: d = o.ToDateTime(TimeOnly.MinValue); return true;
            case string s:
                return DateTime.TryParse(s, CultureInfo.GetCultureInfo("pt-BR"), DateTimeStyles.None, out d);
            default: d = default; return false;
        }
    }
}

/// <summary>Aplica filtros e ordenação (colunas orderby="true") em memória.</summary>
public static class RecordSetShaper
{
    public static RecordSet Shape(TableDefinition table, IReadOnlyList<string> columns, IEnumerable<DataRecord> rows, IReadOnlyList<SourceFilter> filters)
    {
        IEnumerable<DataRecord> q = rows;

        foreach (var f in filters.Where(f => AppliesTo(f, table)))
        {
            var filter = f;
            q = q.Where(r => RecordValueComparer.Matches(r[filter.Column], filter.Operator, filter.Value));
        }

        var order = table.Columns.Where(c => c.OrderBy).Select(c => c.Name).ToList();
        if (order.Count > 0)
        {
            var ordered = q.OrderBy(r => r[order[0]], Comparer<object?>.Create(RecordValueComparer.Compare));
            for (var i = 1; i < order.Count; i++)
            {
                var col = order[i];
                ordered = ordered.ThenBy(r => r[col], Comparer<object?>.Create(RecordValueComparer.Compare));
            }
            q = ordered;
        }

        return new RecordSet(table.Alias, columns, q.ToList());
    }

    /// <summary>Filtro vale para a tabela se o alias bate ou, sem alias, se a tabela declara a coluna.</summary>
    public static bool AppliesTo(SourceFilter f, TableDefinition table) =>
        f.Alias is null
            ? table.FindColumn(f.Column) is not null
            : f.Alias.Equals(table.Alias, StringComparison.OrdinalIgnoreCase);
}

/// <summary>Fonte em memória: primeiro marco funcional (protótipo sem banco) e testes.</summary>
public sealed class InMemoryRecordSource : IRecordSource
{
    private readonly Dictionary<string, List<DataRecord>> _data = new(StringComparer.OrdinalIgnoreCase);

    public string Description => "Memória";

    public InMemoryRecordSource Add(string aliasOrTable, IEnumerable<IDictionary<string, object?>> rows)
    {
        _data[aliasOrTable] = rows.Select(r => new DataRecord(r)).ToList();
        return this;
    }

    public Task<RecordSet> LoadAsync(TableDefinition table, IReadOnlyList<SourceFilter> filters, CancellationToken cancellationToken = default)
    {
        if (!_data.TryGetValue(table.Alias, out var rows) && !_data.TryGetValue(table.Name, out rows))
            throw new SourceException($"Sem dados em memória para a tabela '{table.Name}' (alias '{table.Alias}').");

        var columns = rows.SelectMany(r => r.Columns).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        return Task.FromResult(RecordSetShaper.Shape(table, columns, rows, filters));
    }
}
