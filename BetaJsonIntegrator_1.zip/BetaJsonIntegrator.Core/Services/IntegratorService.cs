using System.Diagnostics;
using System.Text.Encodings.Web;
using System.Text.Json;
using System.Text.Json.Nodes;

namespace BetaJsonIntegrator.Core;

public sealed class RunOptions
{
    public string? GenerateName { get; set; }
    public string? JsonDefinitionName { get; set; }
    public List<SourceFilter> Filters { get; } = new();
    public MappingOptions Mapping { get; set; } = new();
    public GeneratorOptions Generator { get; set; } = new();
}

public sealed class RunResult
{
    public bool Generated => Json is not null;
    public JsonObject? Json { get; set; }
    public string? JsonText { get; set; }
    public ValidationReport Report { get; set; } = new();
    public List<PendingField> Pending { get; set; } = new();
    public MappingPlan? Plan { get; set; }
    public bool HasErrors => Report.ErrorCount > 0;
}

/// <summary>
/// Orquestra o fluxo: valida layout → carrega dados → resolve mapeamento → gera JSON → valida Schema → relatório.
/// Não depende de interface gráfica nem de banco (usa IRecordSource).
/// </summary>
public sealed class IntegratorService
{
    public static readonly JsonSerializerOptions OutputJson = new()
    {
        WriteIndented = true,
        Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping
    };

    private readonly IIntegratorLogger _log;

    public IntegratorService(IIntegratorLogger? logger = null) => _log = logger ?? NullLogger.Instance;

    public async Task<RunResult> RunAsync(LayoutPackage package, IRecordSource source, RunOptions? options = null, CancellationToken ct = default)
    {
        options ??= new RunOptions();
        var sw = Stopwatch.StartNew();
        var result = new RunResult();
        var issues = new List<ValidationIssue>(package.Issues);

        var report = new ValidationReport
        {
            Layout = package.Layout.Name,
            Identifier = package.Layout.Identifier,
            LayoutVersion = package.Metadata.LayoutVersion,
            SchemaVersion = package.Metadata.SchemaVersion ?? package.Schema?.SchemaId,
            Source = source.Description,
            LayoutHash = package.Hash
        };
        result.Report = report;

        _log.Info($"Execução iniciada: layout={package.Layout.Identifier} versão={report.LayoutVersion} origem={source.Description} hash={package.Hash[..12]}");

        try
        {
            var generate = Pick(package.Layout.Generates, options.GenerateName, g => g.Name);
            var json = Pick(package.Layout.JsonDefinitions, options.JsonDefinitionName, j => j.Name);

            if (generate is null || json is null || issues.Any(i => i.Severity == IssueSeverity.Error && i.Code is "SEM_GENERATE" or "SEM_JSONFIELDS" or "TIPO_DESCONHECIDO"))
            {
                Finish(result, issues, sw);
                return result;
            }

            // 1) Carregar dados de cada tabela
            var sets = new Dictionary<string, RecordSet>(StringComparer.OrdinalIgnoreCase);
            foreach (var table in generate.Tables)
            {
                ct.ThrowIfCancellationRequested();
                try
                {
                    var filters = options.Filters.Where(f => RecordSetShaper.AppliesTo(f, table)).ToList();
                    sets[table.Alias] = await source.LoadAsync(table, filters, ct).ConfigureAwait(false);
                    report.RecordCounts[table.Alias] = sets[table.Alias].Rows.Count;
                }
                catch (SourceException ex)
                {
                    issues.Add(new(IssueSeverity.Error, "ORIGEM_INDISPONIVEL", $"Tabela '{table.Alias}': {ex.Message}"));
                    _log.Error($"Falha ao carregar a tabela {table.Alias}", ex);
                }
            }

            // 2) Mapeamento (valores fixos, colunas, padrões, personalizações, pendências)
            var available = sets.ToDictionary(kv => kv.Key, kv => (IReadOnlyCollection<string>)kv.Value.Columns, StringComparer.OrdinalIgnoreCase);
            var plan = new MappingResolver(options.Mapping).Resolve(json, generate, package.Customizations, available);
            result.Plan = plan;
            result.Pending = plan.Pending;
            issues.AddRange(plan.Issues);

            if (issues.Any(i => i.Severity == IssueSeverity.Error))
            {
                _log.Warning($"Geração bloqueada: {issues.Count(i => i.Severity == IssueSeverity.Error)} erro(s) de configuração/mapeamento, {plan.Pending.Count} campo(s) pendente(s).");
                Finish(result, issues, sw);
                return result;
            }

            // 3) Geração
            var gen = new JsonGenerator().Generate(json, generate, plan, sets, options.Generator);
            issues.AddRange(gen.Issues);
            result.Json = gen.Root;
            result.JsonText = gen.Root.ToJsonString(OutputJson);

            // 4) Validação com JSON Schema
            if (package.Schema is null)
                issues.Add(new(IssueSeverity.Warning, "SCHEMA_AUSENTE", "O layout não possui schema.json; a estrutura do JSON não foi validada."));
            else
                issues.AddRange(package.Schema.Validate(gen.Root));
        }
        catch (OperationCanceledException)
        {
            issues.Add(new(IssueSeverity.Warning, "CANCELADO", "Execução cancelada pelo usuário."));
            _log.Warning("Execução cancelada.");
        }
        catch (Exception ex)
        {
            issues.Add(new(IssueSeverity.Error, "FALHA_INESPERADA", ex.Message));
            _log.Error("Falha inesperada na execução", ex);
        }

        Finish(result, issues, sw);
        return result;
    }

    private void Finish(RunResult result, List<ValidationIssue> issues, Stopwatch sw)
    {
        result.Report.Issues = issues;
        result.Report.DurationSeconds = Math.Round(sw.Elapsed.TotalSeconds, 3);
        result.Report.ExecutedAt = DateTimeOffset.Now;

        var total = result.Report.RecordCounts.Values.Sum();
        _log.Info($"Execução concluída: layout={result.Report.Identifier} registros={total} erros={result.Report.ErrorCount} " +
                  $"avisos={result.Report.WarningCount} pendentes={result.Pending.Count} duração={result.Report.DurationSeconds}s " +
                  $"JSON gerado={(result.Generated ? "sim" : "não")}");
    }

    private static T? Pick<T>(List<T> items, string? name, Func<T, string> nameOf) where T : class =>
        name is null ? items.FirstOrDefault() : items.FirstOrDefault(i => nameOf(i).Equals(name, StringComparison.OrdinalIgnoreCase));
}
