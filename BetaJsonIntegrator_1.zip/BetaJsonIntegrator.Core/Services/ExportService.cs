using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace BetaJsonIntegrator.Core;

public enum OverwritePolicy
{
    /// <summary>Recusa se o arquivo existir (padrão).</summary>
    Fail,
    Overwrite,
    /// <summary>Mantém o existente e grava com sufixo -yyyyMMdd-HHmmss.</summary>
    AddTimestamp
}

public sealed class ExportOptions
{
    public string OutputRoot { get; set; } = "Output";
    public string LayoutFolder { get; set; } = "";

    /// <summary>Subpasta do período/competência, ex.: 2026.</summary>
    public string Subfolder { get; set; } = "";
    public string JsonFileName { get; set; } = "declaracoes.json";
    public string ReportFileName { get; set; } = "validation-report.json";
    public OverwritePolicy Overwrite { get; set; } = OverwritePolicy.Fail;

    /// <summary>Por padrão o JSON só é gravado sem erros; o relatório é gravado sempre.</summary>
    public bool AllowExportWithErrors { get; set; }
}

public sealed record ExportResult(string? JsonPath, string ReportPath, bool JsonSkippedBecauseOfErrors);

public sealed class ExportService
{
    private static readonly JsonSerializerOptions ReportJson = new()
    {
        WriteIndented = true,
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        Converters = { new JsonStringEnumConverter() },
        Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping
    };

    private readonly IIntegratorLogger _log;
    public ExportService(IIntegratorLogger? logger = null) => _log = logger ?? NullLogger.Instance;

    public ExportResult Export(RunResult run, ExportOptions options)
    {
        var dir = Path.Combine(options.OutputRoot, options.LayoutFolder, options.Subfolder);
        Directory.CreateDirectory(dir);

        string? jsonPath = null;
        var skipped = false;

        if (run.Json is not null && run.JsonText is not null)
        {
            if (run.HasErrors && !options.AllowExportWithErrors) skipped = true;
            else jsonPath = Write(dir, options.JsonFileName, run.JsonText, options.Overwrite);
        }

        var reportPath = Write(dir, options.ReportFileName, JsonSerializer.Serialize(run.Report, ReportJson), options.Overwrite);

        _log.Info($"Exportação: layout={run.Report.Identifier} json={(jsonPath is null ? "não gravado" : Path.GetFileName(jsonPath))} relatório={Path.GetFileName(reportPath)}");
        return new ExportResult(jsonPath, reportPath, skipped);
    }

    private static string Write(string dir, string fileName, string content, OverwritePolicy policy)
    {
        var path = Path.Combine(dir, fileName);

        if (File.Exists(path))
        {
            switch (policy)
            {
                case OverwritePolicy.Fail:
                    throw new IOException($"O arquivo '{fileName}' já existe em '{dir}'. Escolha sobrescrever ou gravar com data/hora.");
                case OverwritePolicy.AddTimestamp:
                    path = Path.Combine(dir, $"{Path.GetFileNameWithoutExtension(fileName)}-{DateTime.Now:yyyyMMdd-HHmmss}{Path.GetExtension(fileName)}");
                    break;
            }
        }

        File.WriteAllText(path, content, new UTF8Encoding(false));
        return path;
    }
}
