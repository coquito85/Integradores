using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace BetaJsonIntegrator.Core;

public sealed class LayoutMetadata
{
    public string? FriendlyName { get; set; }
    public string? Identifier { get; set; }
    public string LayoutVersion { get; set; } = "1";
    public string? SchemaVersion { get; set; }
    public DateTimeOffset? UpdatedAt { get; set; }
    public string? Notes { get; set; }
}

public sealed record LayoutSummary(string FolderName, string FriendlyName, string Identifier, string LayoutVersion, string? SchemaVersion, bool HasSchema, DateTimeOffset? UpdatedAt);

/// <summary>Um layout carregado do disco: XML interpretado, schema, personalizações e hash da configuração.</summary>
public sealed class LayoutPackage
{
    public string Folder { get; init; } = "";
    public string FolderName => Path.GetFileName(Folder.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar));
    public LayoutMetadata Metadata { get; init; } = new();
    public string LayoutXml { get; init; } = "";
    public LayoutDefinition Layout { get; init; } = new();
    public string? SchemaText { get; init; }
    public JsonSchemaValidator? Schema { get; init; }
    public CustomizationSet Customizations { get; set; } = new();
    public List<ValidationIssue> Issues { get; init; } = new();
    public string Hash { get; init; } = "";

    public string CustomizationsPath => Path.Combine(Folder, LayoutCatalog.CustomizationsFile);
}

/// <summary>Descobre, carrega e versiona layouts em Configurations/Layouts/&lt;Nome&gt;/.</summary>
public sealed class LayoutCatalog
{
    public const string LayoutFile = "layout.xml";
    public const string SchemaFile = "schema.json";
    public const string CustomizationsFile = "customizations.xml";
    public const string MetadataFile = "metadata.json";

    private static readonly JsonSerializerOptions MetaJson = new()
    {
        PropertyNameCaseInsensitive = true,
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        WriteIndented = true,
        DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull
    };

    private readonly string _root;
    public LayoutCatalog(string layoutsRoot) => _root = layoutsRoot;

    public IReadOnlyList<LayoutSummary> List()
    {
        if (!Directory.Exists(_root)) return Array.Empty<LayoutSummary>();

        var list = new List<LayoutSummary>();
        foreach (var dir in Directory.GetDirectories(_root).OrderBy(d => d, StringComparer.OrdinalIgnoreCase))
        {
            if (!File.Exists(Path.Combine(dir, LayoutFile))) continue;
            var meta = ReadMetadata(dir);
            var name = Path.GetFileName(dir);
            list.Add(new LayoutSummary(name, meta.FriendlyName ?? name, meta.Identifier ?? "", meta.LayoutVersion,
                meta.SchemaVersion, File.Exists(Path.Combine(dir, SchemaFile)), meta.UpdatedAt));
        }
        return list;
    }

    public LayoutPackage Load(string folderName)
    {
        var dir = Path.Combine(_root, folderName);
        var layoutPath = Path.Combine(dir, LayoutFile);
        if (!File.Exists(layoutPath)) throw new LayoutException($"layout.xml não encontrado em '{folderName}'.");

        var layoutXml = File.ReadAllText(layoutPath, Encoding.UTF8);
        var parsed = XmlLayoutParser.Parse(XmlLayoutReader.LoadText(layoutXml));
        var issues = new List<ValidationIssue>(parsed.Issues);
        issues.AddRange(LayoutValidator.Validate(parsed.Layout));

        string? schemaText = null;
        JsonSchemaValidator? schema = null;
        var schemaPath = Path.Combine(dir, SchemaFile);
        if (File.Exists(schemaPath))
        {
            schemaText = File.ReadAllText(schemaPath, Encoding.UTF8);
            try { schema = JsonSchemaValidator.Parse(schemaText); }
            catch (JsonException ex) { issues.Add(new(IssueSeverity.Error, "SCHEMA_INVALIDO", $"schema.json não é um JSON válido: {ex.Message}")); }
        }

        var customPath = Path.Combine(dir, CustomizationsFile);
        var customText = File.Exists(customPath) ? File.ReadAllText(customPath, Encoding.UTF8) : "";
        var customs = string.IsNullOrEmpty(customText) ? new CustomizationSet() : CustomizationStore.Load(customPath);
        if (string.IsNullOrEmpty(customs.LayoutIdentifier)) customs.LayoutIdentifier = parsed.Layout.Identifier;

        var meta = ReadMetadata(dir);
        meta.FriendlyName ??= parsed.Layout.Name;
        meta.Identifier ??= parsed.Layout.Identifier;

        return new LayoutPackage
        {
            Folder = dir,
            Metadata = meta,
            LayoutXml = layoutXml,
            Layout = parsed.Layout,
            SchemaText = schemaText,
            Schema = schema,
            Customizations = customs,
            Issues = issues,
            Hash = Hash(layoutXml, schemaText, customText)
        };
    }

    public void SaveCustomizations(LayoutPackage package) =>
        CustomizationStore.Save(package.CustomizationsPath, package.Customizations);

    /// <summary>
    /// Grava um novo layout.xml: valida o XML, arquiva a versão anterior em versions/ e incrementa a versão.
    /// Devolve a nova versão.
    /// </summary>
    public string SaveLayoutXml(string folderName, string newXml, string? notes = null)
    {
        XmlLayoutParser.Parse(XmlLayoutReader.LoadText(newXml)); // lança LayoutException se inválido

        var dir = Path.Combine(_root, folderName);
        Directory.CreateDirectory(dir);
        var layoutPath = Path.Combine(dir, LayoutFile);
        var meta = ReadMetadata(dir);

        if (File.Exists(layoutPath) && File.ReadAllText(layoutPath, Encoding.UTF8) == newXml)
            return meta.LayoutVersion; // nada mudou

        if (File.Exists(layoutPath))
        {
            var versions = Path.Combine(dir, "versions");
            Directory.CreateDirectory(versions);
            File.Copy(layoutPath, Path.Combine(versions, $"layout.v{meta.LayoutVersion}.xml"), overwrite: true);
            meta.LayoutVersion = int.TryParse(meta.LayoutVersion, out var n) ? (n + 1).ToString() : meta.LayoutVersion + ".1";
        }

        File.WriteAllText(layoutPath, newXml, new UTF8Encoding(false));
        meta.UpdatedAt = DateTimeOffset.Now;
        if (notes is not null) meta.Notes = notes;
        WriteMetadata(dir, meta);
        return meta.LayoutVersion;
    }

    public void SaveSchema(string folderName, string schemaText, string? schemaVersion)
    {
        JsonSchemaValidator.Parse(schemaText); // lança JsonException se inválido
        var dir = Path.Combine(_root, folderName);
        File.WriteAllText(Path.Combine(dir, SchemaFile), schemaText, new UTF8Encoding(false));
        var meta = ReadMetadata(dir);
        meta.SchemaVersion = schemaVersion ?? meta.SchemaVersion;
        meta.UpdatedAt = DateTimeOffset.Now;
        WriteMetadata(dir, meta);
    }

    private static LayoutMetadata ReadMetadata(string dir)
    {
        var path = Path.Combine(dir, MetadataFile);
        if (!File.Exists(path)) return new LayoutMetadata();
        try { return JsonSerializer.Deserialize<LayoutMetadata>(File.ReadAllText(path), MetaJson) ?? new LayoutMetadata(); }
        catch (JsonException) { return new LayoutMetadata(); }
    }

    private static void WriteMetadata(string dir, LayoutMetadata meta) =>
        File.WriteAllText(Path.Combine(dir, MetadataFile), JsonSerializer.Serialize(meta, MetaJson), new UTF8Encoding(false));

    private static string Hash(params string?[] parts)
    {
        using var sha = SHA256.Create();
        var bytes = sha.ComputeHash(Encoding.UTF8.GetBytes(string.Join("\n--\n", parts.Select(p => p ?? ""))));
        return Convert.ToHexString(bytes).ToLowerInvariant();
    }
}
