using System.Text.RegularExpressions;

namespace BetaJsonIntegrator.Core;

public interface IIntegratorLogger
{
    void Info(string message);
    void Warning(string message);
    void Error(string message, Exception? exception = null);
}

public sealed class NullLogger : IIntegratorLogger
{
    public static readonly NullLogger Instance = new();
    public void Info(string message) { }
    public void Warning(string message) { }
    public void Error(string message, Exception? exception = null) { }
}

/// <summary>Mascara CPF/CNPJ (formatados ou só dígitos) antes de gravar em log.</summary>
public static class PiiMasker
{
    private static readonly Regex Cnpj = new(@"\b\d{2}\.?\d{3}\.?\d{3}/?\d{4}-?\d{2}\b", RegexOptions.Compiled);
    private static readonly Regex Cpf = new(@"\b\d{3}\.?\d{3}\.?\d{3}-?\d{2}\b", RegexOptions.Compiled);

    public static string Mask(string text) => Cpf.Replace(Cnpj.Replace(text, "[DOC]"), "[DOC]");
}

/// <summary>Log em arquivo diário (integrator-yyyy-MM-dd.log). Thread-safe.</summary>
public sealed class FileLogger : IIntegratorLogger
{
    private readonly string _directory;
    private readonly object _lock = new();

    public FileLogger(string directory)
    {
        _directory = directory;
        Directory.CreateDirectory(directory);
    }

    public string CurrentFile => Path.Combine(_directory, $"integrator-{DateTime.Now:yyyy-MM-dd}.log");

    public void Info(string message) => Write("INFO ", message);
    public void Warning(string message) => Write("WARN ", message);

    public void Error(string message, Exception? exception = null) =>
        Write("ERROR", exception is null ? message : $"{message} | {exception.GetType().Name}: {exception.Message}");

    private void Write(string level, string message)
    {
        var line = $"{DateTime.Now:yyyy-MM-dd HH:mm:ss.fff} [{level}] {PiiMasker.Mask(message)}{Environment.NewLine}";
        lock (_lock)
        {
            try { File.AppendAllText(CurrentFile, line); }
            catch (IOException) { /* log nunca derruba a execução */ }
        }
    }
}
