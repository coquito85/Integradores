using System.Text.RegularExpressions;

namespace BetaJsonIntegrator.Core;

/// <summary>Verificações estruturais do layout, antes de qualquer dado ser lido.</summary>
public static class LayoutValidator
{
    private static readonly Regex SqlPart = new(@"^[\p{L}_][\p{L}\p{N}_$]*$", RegexOptions.Compiled);

    private static bool IsSqlPart(string? n) => !string.IsNullOrWhiteSpace(n) && n.Length <= 128 && SqlPart.IsMatch(n);

    private static bool IsSqlTable(string? n)
    {
        if (string.IsNullOrWhiteSpace(n)) return false;
        var parts = n.Split('.');
        return parts.Length is 1 or 2 && parts.All(IsSqlPart);
    }

    public static List<ValidationIssue> Validate(LayoutDefinition layout)
    {
        var issues = new List<ValidationIssue>();

        if (string.IsNullOrWhiteSpace(layout.Name)) issues.Add(new(IssueSeverity.Error, "LAYOUT_SEM_NOME", "O layout não tem atributo name."));
        if (string.IsNullOrWhiteSpace(layout.Identifier)) issues.Add(new(IssueSeverity.Error, "LAYOUT_SEM_IDENTIFICADOR", "O layout não tem atributo identifier."));
        if (layout.Generates.Count == 0) issues.Add(new(IssueSeverity.Error, "SEM_GENERATE", "Nenhum elemento <generate> encontrado."));
        if (layout.JsonDefinitions.Count == 0) issues.Add(new(IssueSeverity.Error, "SEM_JSONFIELDS", "Nenhum elemento <Jsonfields> encontrado."));

        foreach (var gen in layout.Generates)
        {
            var aliases = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var t in gen.Tables)
            {
                if (string.IsNullOrWhiteSpace(t.Name)) issues.Add(new(IssueSeverity.Error, "TABELA_SEM_NOME", $"Há uma tabela sem nome em '{gen.Name}'."));
                else if (!IsSqlTable(t.Name))
                    issues.Add(new(IssueSeverity.Warning, "TABELA_NOME_NAO_SQL", $"O nome de tabela '{t.Name}' não é um identificador SQL seguro; só poderá ser usada com origem CSV."));

                if (!aliases.Add(t.Alias)) issues.Add(new(IssueSeverity.Error, "ALIAS_DUPLICADO", $"Alias de tabela duplicado: '{t.Alias}'."));

                var cols = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                foreach (var c in t.Columns)
                {
                    if (string.IsNullOrWhiteSpace(c.Name)) issues.Add(new(IssueSeverity.Error, "COLUNA_SEM_NOME", $"Coluna sem nome na tabela '{t.Alias}'."));
                    else if (!cols.Add(c.Name)) issues.Add(new(IssueSeverity.Error, "COLUNA_DUPLICADA", $"Coluna duplicada '{c.Name}' na tabela '{t.Alias}'."));
                    else if (!IsSqlPart(c.Name))
                        issues.Add(new(IssueSeverity.Warning, "COLUNA_NOME_NAO_SQL", $"A coluna '{c.Name}' ({t.Alias}) não é um identificador SQL seguro; só poderá ser usada com origem CSV."));
                }
            }
        }

        foreach (var js in layout.JsonDefinitions)
            foreach (var alias in js.Aliases)
            {
                if (string.IsNullOrWhiteSpace(alias.Name)) issues.Add(new(IssueSeverity.Error, "ALIAS_SEM_NOME", $"Há um alias sem nome em '{js.Name}'."));
                CheckSiblings(alias.Fields, issues);
            }

        return issues;
    }

    private static void CheckSiblings(IReadOnlyList<FieldDefinition> fields, List<ValidationIssue> issues)
    {
        var names = new HashSet<string>(StringComparer.Ordinal);
        foreach (var f in fields)
        {
            if (string.IsNullOrWhiteSpace(f.Name)) issues.Add(new(IssueSeverity.Error, "CAMPO_SEM_NOME", "Há um campo sem atributo name."));
            else if (!names.Add(f.Name)) issues.Add(new(IssueSeverity.Error, "CAMPO_DUPLICADO", $"Campo duplicado no mesmo nível: '{f.Path}'.", f.Path));
            CheckSiblings(f.Children, issues);
        }
    }
}
