using System.Globalization;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Text.RegularExpressions;

namespace BetaJsonIntegrator.Core;

/// <summary>
/// Validador de JSON Schema (rascunhos 07 e 2019-09/2020-12, subconjunto estrutural): type, enum, const, required,
/// properties, additionalProperties, patternProperties, items/prefixItems, min/max (valor, tamanho, itens),
/// pattern, format (date, date-time, email, uuid), allOf/anyOf/oneOf/not, if/then/else, $ref local, multipleOf,
/// uniqueItems. Palavras-chave não suportadas geram aviso (SCHEMA_KEYWORD_IGNORADA) em vez de passarem em silêncio.
/// Erros trazem o caminho JSON, ex.: declaracoes[0].adquirentes[0].ni. Mensagens não incluem valores dos dados.
/// </summary>
public sealed class JsonSchemaValidator
{
    private static readonly string[] UnsupportedKeywords =
    {
        "contains", "propertyNames", "dependentSchemas", "dependencies", "unevaluatedProperties",
        "unevaluatedItems", "$dynamicRef", "$recursiveRef", "contentSchema"
    };

    private readonly JsonNode _root;
    private readonly Dictionary<string, Regex> _regexCache = new();
    private readonly HashSet<string> _ignoredKeywords = new();
    private int _errorBudget;

    public string? SchemaId { get; }
    public string? SchemaDialect { get; }

    public JsonSchemaValidator(JsonNode schema)
    {
        _root = schema ?? throw new ArgumentNullException(nameof(schema));
        if (schema is JsonObject o)
        {
            SchemaId = o["$id"]?.GetValue<string>();
            SchemaDialect = o["$schema"]?.GetValue<string>();
        }
    }

    public static JsonSchemaValidator Parse(string schemaText) =>
        new(JsonNode.Parse(schemaText, documentOptions: new JsonDocumentOptions { CommentHandling = JsonCommentHandling.Skip, AllowTrailingCommas = true })
            ?? throw new JsonException("Schema vazio."));

    public IReadOnlyList<ValidationIssue> Validate(JsonNode? instance, int maxIssues = 2000)
    {
        _ignoredKeywords.Clear();
        _errorBudget = maxIssues;

        // Reparse: garante nós baseados em JsonElement (números fiéis ao texto exportado).
        var normalized = instance is null ? null : JsonNode.Parse(instance.ToJsonString());

        var errors = new List<(string Path, string Code, string Message)>();
        Check(normalized, _root, "", errors, 0);

        var collector = new IssueCollector();
        foreach (var (path, code, message) in errors)
            collector.Add(IssueSeverity.Error, code, message, path.Length == 0 ? "$" : path);

        foreach (var kw in _ignoredKeywords)
            collector.Add(IssueSeverity.Info, "SCHEMA_KEYWORD_IGNORADA", $"A palavra-chave de Schema '{kw}' não é suportada e foi ignorada.");

        return collector.ToList();
    }

    // ---------------------------------------------------------------------------------

    private bool Check(JsonNode? inst, JsonNode? schema, string path, List<(string, string, string)> errors, int depth)
    {
        if (depth > 64) { Add(errors, path, "SCHEMA_PROFUNDO", "Schema com recursão excessiva."); return false; }
        if (schema is JsonValue sv && sv.TryGetValue<bool>(out var allowAll))
            return allowAll || Add(errors, path, "SCHEMA_FALSO", "Valor não permitido pelo schema.");
        if (schema is not JsonObject so) return true;

        var ok = true;

        if (so["$ref"] is JsonNode refNode && refNode.GetValueKind() == JsonValueKind.String)
        {
            var target = ResolveRef(refNode.GetValue<string>());
            if (target is null) { _ignoredKeywords.Add("$ref remoto/não resolvido: " + refNode.GetValue<string>()); }
            else ok &= Check(inst, target, path, errors, depth + 1);
        }

        foreach (var kw in UnsupportedKeywords)
            if (so.ContainsKey(kw)) _ignoredKeywords.Add(kw);

        if (so["type"] is { } typeNode && !CheckType(inst, typeNode, path, errors)) return false; // tipo errado: demais regras perdem sentido

        if (so["enum"] is JsonArray en && !en.Any(e => JsonEquals(e, inst)))
            ok &= Add(errors, path, "ENUM", "Valor fora das opções permitidas.");

        if (so.ContainsKey("const") && !JsonEquals(so["const"], inst))
            ok &= Add(errors, path, "CONST", "Valor diferente do valor fixo exigido.");

        switch (inst?.GetValueKind())
        {
            case JsonValueKind.Object: ok &= CheckObject((JsonObject)inst!, so, path, errors, depth); break;
            case JsonValueKind.Array: ok &= CheckArray((JsonArray)inst!, so, path, errors, depth); break;
            case JsonValueKind.String: ok &= CheckString(inst!.GetValue<string>(), so, path, errors); break;
            case JsonValueKind.Number: ok &= CheckNumber(inst!, so, path, errors); break;
        }

        ok &= CheckCombinators(inst, so, path, errors, depth);
        return ok;
    }

    private bool CheckType(JsonNode? inst, JsonNode typeNode, string path, List<(string, string, string)> errors)
    {
        var allowed = typeNode is JsonArray arr ? arr.Select(t => t?.GetValue<string>() ?? "").ToList() : new List<string> { typeNode.GetValue<string>() };
        if (allowed.Any(t => IsType(inst, t))) return true;
        return Add(errors, path, "TIPO", $"Tipo esperado {string.Join(" ou ", allowed)}, recebido {KindName(inst)}.");
    }

    private static bool IsType(JsonNode? inst, string type)
    {
        var kind = inst?.GetValueKind() ?? JsonValueKind.Null;
        return type switch
        {
            "null" => kind == JsonValueKind.Null,
            "string" => kind == JsonValueKind.String,
            "boolean" => kind is JsonValueKind.True or JsonValueKind.False,
            "object" => kind == JsonValueKind.Object,
            "array" => kind == JsonValueKind.Array,
            "number" => kind == JsonValueKind.Number,
            "integer" => kind == JsonValueKind.Number && TryNumber(inst!, out var d) && d == decimal.Truncate(d),
            _ => true
        };
    }

    private static string KindName(JsonNode? n) => (n?.GetValueKind() ?? JsonValueKind.Null) switch
    {
        JsonValueKind.True or JsonValueKind.False => "boolean",
        JsonValueKind.Null or JsonValueKind.Undefined => "null",
        var k => k.ToString().ToLowerInvariant()
    };

    private bool CheckObject(JsonObject obj, JsonObject schema, string path, List<(string, string, string)> errors, int depth)
    {
        var ok = true;

        if (schema["required"] is JsonArray required)
            foreach (var r in required)
            {
                var name = r?.GetValue<string>();
                if (name is not null && !obj.ContainsKey(name))
                    ok &= Add(errors, path, "OBRIGATORIO", $"Propriedade obrigatória ausente: '{name}'.");
            }

        var props = schema["properties"] as JsonObject;
        var patternProps = schema["patternProperties"] as JsonObject;

        foreach (var (name, value) in obj)
        {
            var childPath = path.Length == 0 ? name : path + "." + name;
            var matched = false;

            if (props is not null && props.TryGetPropertyValue(name, out var propSchema))
            {
                matched = true;
                ok &= Check(value, propSchema, childPath, errors, depth + 1);
            }

            if (patternProps is not null)
                foreach (var (pattern, ps) in patternProps)
                    if (Rx(pattern).IsMatch(name)) { matched = true; ok &= Check(value, ps, childPath, errors, depth + 1); }

            if (!matched && schema.TryGetPropertyValue("additionalProperties", out var addl) && addl is not null)
            {
                if (addl is JsonValue av && av.TryGetValue<bool>(out var allowed))
                {
                    if (!allowed) ok &= Add(errors, childPath, "PROPRIEDADE_ADICIONAL", $"Propriedade não permitida: '{name}'.");
                }
                else ok &= Check(value, addl, childPath, errors, depth + 1);
            }
        }

        if (schema["minProperties"] is { } mn && obj.Count < mn.GetValue<int>())
            ok &= Add(errors, path, "MIN_PROPRIEDADES", $"Mínimo de {mn.GetValue<int>()} propriedade(s).");
        if (schema["maxProperties"] is { } mx && obj.Count > mx.GetValue<int>())
            ok &= Add(errors, path, "MAX_PROPRIEDADES", $"Máximo de {mx.GetValue<int>()} propriedade(s).");

        return ok;
    }

    private bool CheckArray(JsonArray arr, JsonObject schema, string path, List<(string, string, string)> errors, int depth)
    {
        var ok = true;
        var positional = 0;

        if (schema["prefixItems"] is JsonArray prefix)
        {
            positional = prefix.Count;
            for (var i = 0; i < Math.Min(arr.Count, prefix.Count); i++)
                ok &= Check(arr[i], prefix[i], $"{path}[{i}]", errors, depth + 1);
        }

        if (schema["items"] is JsonArray tuple)
        {
            positional = tuple.Count;
            for (var i = 0; i < Math.Min(arr.Count, tuple.Count); i++)
                ok &= Check(arr[i], tuple[i], $"{path}[{i}]", errors, depth + 1);
        }
        else if (schema["items"] is { } items)
        {
            for (var i = positional; i < arr.Count; i++)
                ok &= Check(arr[i], items, $"{path}[{i}]", errors, depth + 1);
        }

        if (schema["minItems"] is { } mn && arr.Count < mn.GetValue<int>())
            ok &= Add(errors, path, "MIN_ITENS", $"Mínimo de {mn.GetValue<int>()} item(ns).");
        if (schema["maxItems"] is { } mx && arr.Count > mx.GetValue<int>())
            ok &= Add(errors, path, "MAX_ITENS", $"Máximo de {mx.GetValue<int>()} item(ns).");

        if (schema["uniqueItems"] is { } u && u.GetValueKind() == JsonValueKind.True)
        {
            var seen = new HashSet<string>();
            if (arr.Any(a => !seen.Add(a?.ToJsonString() ?? "null")))
                ok &= Add(errors, path, "ITENS_UNICOS", "Os itens do array devem ser únicos.");
        }

        return ok;
    }

    private bool CheckString(string s, JsonObject schema, string path, List<(string, string, string)> errors)
    {
        var ok = true;
        var len = new StringInfo(s).LengthInTextElements;

        if (schema["minLength"] is { } mn && len < mn.GetValue<int>())
            ok &= Add(errors, path, "MIN_TAMANHO", $"Tamanho mínimo {mn.GetValue<int>()}.");
        if (schema["maxLength"] is { } mx && len > mx.GetValue<int>())
            ok &= Add(errors, path, "MAX_TAMANHO", $"Tamanho máximo {mx.GetValue<int>()}.");
        if (schema["pattern"] is { } p && !Rx(p.GetValue<string>()).IsMatch(s))
            ok &= Add(errors, path, "PADRAO", "Valor não corresponde ao padrão exigido.");

        if (schema["format"] is { } f)
        {
            var valid = f.GetValue<string>() switch
            {
                "date" => DateOnly.TryParseExact(s, "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out _),
                "date-time" => DateTimeOffset.TryParse(s, CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind, out _) && s.Contains('T'),
                "email" => Regex.IsMatch(s, @"^[^@\s]+@[^@\s]+\.[^@\s]+$"),
                "uuid" => Guid.TryParse(s, out _),
                _ => true
            };
            if (!valid) ok &= Add(errors, path, "FORMATO", $"Valor não está no formato '{f.GetValue<string>()}'.");
        }

        return ok;
    }

    private bool CheckNumber(JsonNode n, JsonObject schema, string path, List<(string, string, string)> errors)
    {
        if (!TryNumber(n, out var v)) return true;
        var ok = true;

        if (Num(schema, "minimum") is { } min && v < min) ok &= Add(errors, path, "MINIMO", $"Valor abaixo do mínimo {min}.");
        if (Num(schema, "maximum") is { } max && v > max) ok &= Add(errors, path, "MAXIMO", $"Valor acima do máximo {max}.");
        if (Num(schema, "exclusiveMinimum") is { } emin && v <= emin) ok &= Add(errors, path, "MINIMO_EXCLUSIVO", $"Valor deve ser maior que {emin}.");
        if (Num(schema, "exclusiveMaximum") is { } emax && v >= emax) ok &= Add(errors, path, "MAXIMO_EXCLUSIVO", $"Valor deve ser menor que {emax}.");
        if (Num(schema, "multipleOf") is { } mult && mult != 0 && v % mult != 0) ok &= Add(errors, path, "MULTIPLO", $"Valor deve ser múltiplo de {mult}.");
        return ok;
    }

    private bool CheckCombinators(JsonNode? inst, JsonObject schema, string path, List<(string, string, string)> errors, int depth)
    {
        var ok = true;

        if (schema["allOf"] is JsonArray all)
            foreach (var s in all) ok &= Check(inst, s, path, errors, depth + 1);

        if (schema["anyOf"] is JsonArray any && !any.Any(s => Probe(inst, s, path, depth).Count == 0))
            ok &= Add(errors, path, "ANY_OF", "O valor não satisfaz nenhuma das alternativas permitidas.");

        if (schema["oneOf"] is JsonArray one)
        {
            var results = one.Select(s => Probe(inst, s, path, depth)).ToList();
            var matches = results.Count(r => r.Count == 0);

            if (matches == 0)
            {
                var constOnly = one.All(s => s is JsonObject so && so.ContainsKey("const"));
                if (constOnly)
                {
                    ok &= Add(errors, path, "ONE_OF", $"Valor não corresponde a nenhuma das {one.Count} opções permitidas.");
                }
                else
                {
                    // mostra os erros da alternativa mais próxima (menos erros)
                    var best = results.OrderBy(r => r.Count).First();
                    ok &= Add(errors, path, "ONE_OF", "O valor não satisfaz nenhuma das alternativas exclusivas.");
                    foreach (var e in best.Take(10)) { errors.Add(e); }
                }
            }
            else if (matches > 1)
            {
                ok &= Add(errors, path, "ONE_OF", $"O valor satisfaz {matches} alternativas, mas deve satisfazer exatamente uma.");
            }
        }

        if (schema["not"] is { } not && Probe(inst, not, path, depth).Count == 0)
            ok &= Add(errors, path, "NOT", "O valor corresponde a um padrão proibido pelo schema.");

        if (schema["if"] is { } cond)
        {
            var passed = Probe(inst, cond, path, depth).Count == 0;
            if (passed && schema["then"] is { } then) ok &= Check(inst, then, path, errors, depth + 1);
            if (!passed && schema["else"] is { } els) ok &= Check(inst, els, path, errors, depth + 1);
        }

        return ok;
    }

    private List<(string Path, string Code, string Message)> Probe(JsonNode? inst, JsonNode? schema, string path, int depth)
    {
        var scratch = new List<(string, string, string)>();
        var saved = _errorBudget;
        _errorBudget = int.MaxValue;
        Check(inst, schema, path, scratch, depth + 1);
        _errorBudget = saved;
        return scratch;
    }

    private JsonNode? ResolveRef(string reference)
    {
        if (reference == "#") return _root;
        if (!reference.StartsWith("#/")) return null;

        JsonNode? current = _root;
        foreach (var raw in reference[2..].Split('/'))
        {
            var seg = Uri.UnescapeDataString(raw).Replace("~1", "/").Replace("~0", "~");
            current = current switch
            {
                JsonObject o => o[seg],
                JsonArray a when int.TryParse(seg, out var i) && i >= 0 && i < a.Count => a[i],
                _ => null
            };
            if (current is null) return null;
        }
        return current;
    }

    private Regex Rx(string pattern)
    {
        if (!_regexCache.TryGetValue(pattern, out var rx))
            _regexCache[pattern] = rx = new Regex(pattern, RegexOptions.CultureInvariant, TimeSpan.FromSeconds(1));
        return rx;
    }

    private bool Add(List<(string, string, string)> errors, string path, string code, string message)
    {
        if (_errorBudget-- > 0) errors.Add((path, code, message));
        return false;
    }

    private static decimal? Num(JsonObject o, string key) => o[key] is { } n && TryNumber(n, out var d) ? d : null;

    private static bool TryNumber(JsonNode n, out decimal d)
    {
        d = 0;
        if (n is not JsonValue v) return false;
        if (v.TryGetValue<decimal>(out d)) return true;
        if (v.TryGetValue<double>(out var dbl) && double.IsFinite(dbl) && Math.Abs(dbl) < 7.9e28) { d = (decimal)dbl; return true; }
        return false;
    }

    private static bool JsonEquals(JsonNode? a, JsonNode? b)
    {
        if (a is null || b is null) return a is null && b is null;
        if (a.GetValueKind() == JsonValueKind.Number && b.GetValueKind() == JsonValueKind.Number
            && TryNumber(a, out var x) && TryNumber(b, out var y)) return x == y;
        return a.ToJsonString() == b.ToJsonString();
    }
}
