# Beta JSON Integrator

Gerador dinâmico de JSON orientado por XML (DOI Web), com um ORM próprio multi-bancos.
Abra `BetaJsonIntegrator.slnx` (Visual Studio 2022 17.13+ ou 2026).
Implementa a *Especificação Funcional e Técnica* (.NET, WinForms). Dentro de `Configurations/` ficam layouts e conexões.

## Projetos

| Projeto | Papel |
|---|---|
| `BetaJsonIntegrator.Orm` | ORM novo (MySQL/MariaDB, SQL Server, PostgreSQL, SQLite) + JSON de conexões criptografado |
| `BetaJsonIntegrator.Core` | XML → modelos, mapeamento, geração JSON, JSON Schema, catálogo de layouts, exportação, log. Sem dependência de UI/banco |
| `BetaJsonIntegrator.Data` | Fontes de dados: `DatabaseProvider` (via ORM), `MariaDbProvider`, `SqlServerProvider`, `CsvProvider`, `DataTableProvider` |
| `BetaJsonIntegrator.App` | Windows Forms: principal, layouts, XML, fonte de dados, personalização, visualizador, validação |
| `BetaJsonIntegrator.Tools` | `bji-tools`: gera chave, criptografa/descriptografa o JSON de conexões, testa conexão |
| `BetaJsonIntegrator.Tests` | 25 testes (console): `dotnet run --project BetaJsonIntegrator.Tests` |

## Conexões (JSON criptografado)

1. Copie `Configurations/connections.sample.json`, edite os perfis (`kind`: `MySql`, `MariaDb`, `SqlServer`, `PostgreSql`, `Sqlite`).
2. Defina o segredo: `bji-tools init-key connections.key` (guarde **fora** do repositório e da pasta do arquivo), ou use a variável `BETA_DB_SECRET`.
3. `bji-tools encrypt meu-plano.json Configurations/connections.json --key-file connections.key` e apague o texto puro.
4. O App lê `Configurations/connections.json` (segredo: `BETA_DB_SECRET`, senão `Configurations/connections.key`).

AES-256-GCM, chave derivada por PBKDF2-SHA256 (210 mil iterações), sal/nonce aleatórios; adulteração e segredo errado são detectados. Texto puro é recusado por padrão.

## ORM

```csharp
[Table("clientes")]
public class Cliente
{
    [Key] public int Id { get; set; }                 // auto-incremento
    [Column("nome_cli")] public string? Nome { get; set; }
    public decimal? Saldo { get; set; }
}

var factory = DbContextFactory.FromFile("Configurations/connections.json", SecretSource.Default("Configurations"));
using var db = factory.Create("principal");           // ou Create() = defaultProfile

db.Insert(new Cliente { Nome = "Ana" });              // preenche o Id gerado
var lista = db.Set<Cliente>().Where(c => c.Saldo > 100 && c.Nome!.StartsWith("A")).OrderBy(c => c.Nome).Take(20).ToList();
using (var tx = db.BeginTransaction()) { db.Update(cliente); tx.Commit(); }   // sem Commit = rollback
var rows = db.Query<Cliente>("SELECT * FROM clientes WHERE id = @id", new { id = 5 });
```

Os valores sempre vão por parâmetro; nomes de tabela/coluna vindos de XML são validados. Os drivers (`MySqlConnector`, `Microsoft.Data.SqlClient`, `Npgsql`, `Microsoft.Data.Sqlite`) são carregados por reflexão e vêm como `PackageReference` do projeto Orm (versões flutuantes: fixe se preferir).

## Regras de campo (XML)

Precedência: 1) `value` literal, 2) coluna (`source` ou legado `Columnrefe`), 3) `default`, 4) sem configuração = **pendente** (nunca preenche sozinho).
`required="true"` pendente bloqueia a geração; `configurable="true"` aceita personalização mesmo com valor no XML.
No XML legado, `value="NomeDeColuna"` é reconhecido como coluna quando a coluna existe; `value` parecido com nome de coluna inexistente (ex. `cpfcnpjAdquirente`) fica pendente em vez de virar texto literal.
Personalizações ficam em `customizations.xml`, separado do layout. Array de topo = um elemento por registro; array aninhado sem filhos = `[]`; com filhos = um elemento do registro corrente.

## Pastas de execução

`Configurations/Layouts/<Nome>/{layout.xml, schema.json, customizations.xml, metadata.json, versions/}`, `Output/<Nome>/<período>/{declaracoes.json, validation-report.json}`, `Logs/integrator-AAAA-MM-DD.log` (CPF/CNPJ mascarados).

## Observações

- `Layouts/SATUBA` é um **exemplo reduzido** montado do trecho da especificação; substitua `layout.xml` e `schema.json` pelos oficiais.
- O validador de JSON Schema é próprio (sem pacote): cobre o subconjunto estrutural usado em contratos como o da DOI e avisa sobre palavras-chave não suportadas (`SCHEMA_KEYWORD_IGNORADA`). Validar com o Schema oficial antes de produção.
- `dotnet build -p:OfflineBuild=true` compila sem baixar os drivers de banco.
