using BetaJsonIntegrator.Orm;

// bji-tools: gerencia o arquivo de conexões criptografado.
//
//   bji-tools init-key   [arquivo-chave]                     gera connections.key
//   bji-tools encrypt    <plano.json> <saida.json> [segredo]
//   bji-tools decrypt    <criptografado.json> <saida.json> [segredo]
//   bji-tools list       <criptografado.json> [segredo]
//   bji-tools test       <criptografado.json> <perfil> [segredo]
//
// [segredo] = --key-file <arquivo> | --prompt | (omitido: variável BETA_DB_SECRET)

return Run(args);

static int Run(string[] args)
{
    if (args.Length == 0 || args[0] is "-h" or "--help") { Help(); return 0; }

    try
    {
        var cmd = args[0].ToLowerInvariant();
        var rest = args.Skip(1).ToArray();

        switch (cmd)
        {
            case "init-key":
            {
                var path = rest.FirstOrDefault(a => !a.StartsWith("--")) ?? "connections.key";
                if (File.Exists(path)) { Console.Error.WriteLine($"'{path}' já existe; não foi sobrescrito."); return 2; }
                KeyFileSecretSource.Create(path);
                Console.WriteLine($"Chave criada em {path}. Guarde-a FORA do repositório e do mesmo local do arquivo criptografado.");
                return 0;
            }

            case "encrypt":
            {
                var (pos, secret) = Split(rest);
                Need(pos, 2, "encrypt <plano.json> <saida.json>");
                ConnectionStore.EncryptFile(pos[0], pos[1], secret);
                Console.WriteLine($"Arquivo criptografado gravado em {pos[1]}. Apague o arquivo em texto puro ({pos[0]}).");
                return 0;
            }

            case "decrypt":
            {
                var (pos, secret) = Split(rest);
                Need(pos, 2, "decrypt <criptografado.json> <saida.json>");
                ConnectionStore.DecryptFile(pos[0], pos[1], secret);
                Console.WriteLine($"Texto puro gravado em {pos[1]} (contém senhas: apague após o uso).");
                return 0;
            }

            case "list":
            {
                var (pos, secret) = Split(rest);
                Need(pos, 1, "list <criptografado.json>");
                var s = ConnectionStore.Load(pos[0], secret);
                foreach (var p in s.Profiles)
                    Console.WriteLine($"{(p.Name.Equals(s.DefaultProfile, StringComparison.OrdinalIgnoreCase) ? "*" : " ")} {p}");
                return 0;
            }

            case "test":
            {
                var (pos, secret) = Split(rest);
                Need(pos, 2, "test <criptografado.json> <perfil>");
                var factory = DbContextFactory.FromFile(pos[0], secret);
                using var ctx = factory.Create(pos[1]);
                ctx.TestConnection();
                Console.WriteLine($"Conexão OK: {ctx.Profile}");
                return 0;
            }

            default:
                Console.Error.WriteLine($"Comando desconhecido: {cmd}");
                Help();
                return 1;
        }
    }
    catch (Exception ex) when (ex is ConnectionStoreException or InvalidOperationException or KeyNotFoundException or IOException or ArgumentException)
    {
        Console.Error.WriteLine("Erro: " + ex.Message);
        return 2;
    }
    catch (Exception ex)
    {
        // erros de driver/rede no 'test': mostra a mensagem, nunca a string de conexão
        Console.Error.WriteLine($"Falha: {ex.GetType().Name}: {ex.Message}");
        return 3;
    }
}

static (string[] Positional, SecretSource Secret) Split(string[] args)
{
    var pos = new List<string>();
    SecretSource? secret = null;

    for (var i = 0; i < args.Length; i++)
    {
        if (args[i] == "--key-file" && i + 1 < args.Length) secret = new KeyFileSecretSource(args[++i]);
        else if (args[i] == "--prompt") secret = new LiteralSecretSource(ReadHidden("Segredo: "));
        else pos.Add(args[i]);
    }

    return (pos.ToArray(), secret ?? new EnvironmentSecretSource());
}

static void Need(string[] pos, int count, string usage)
{
    if (pos.Length < count) throw new ArgumentException("Uso: bji-tools " + usage);
}

static string ReadHidden(string prompt)
{
    Console.Error.Write(prompt);
    var sb = new System.Text.StringBuilder();
    while (true)
    {
        var key = Console.ReadKey(intercept: true);
        if (key.Key == ConsoleKey.Enter) break;
        if (key.Key == ConsoleKey.Backspace) { if (sb.Length > 0) sb.Length--; }
        else sb.Append(key.KeyChar);
    }
    Console.Error.WriteLine();
    return sb.ToString();
}

static void Help() => Console.WriteLine(
    """
    bji-tools - arquivo de conexões criptografado (AES-256-GCM)

      init-key [arquivo-chave]
      encrypt <plano.json> <saida.json>  [--key-file f | --prompt]
      decrypt <criptografado.json> <saida.json>  [--key-file f | --prompt]
      list    <criptografado.json>  [--key-file f | --prompt]
      test    <criptografado.json> <perfil>  [--key-file f | --prompt]

    Sem --key-file/--prompt, o segredo vem da variável de ambiente BETA_DB_SECRET.
    """);
