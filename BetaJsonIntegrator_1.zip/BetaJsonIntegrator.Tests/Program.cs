using Row = System.Collections.Generic.Dictionary<string, object?>;
using System.Data;
using System.Text.Json.Nodes;
using BetaJsonIntegrator.Core;
using BetaJsonIntegrator.Data;
using BetaJsonIntegrator.Orm;
using BetaJsonIntegrator.Tests;

var tests = new List<(string Name, Func<Task> Body)>();
void T(string name, Func<Task> body) => tests.Add((name, body));
void T0(string name, Action body) => tests.Add((name, () => { body(); return Task.CompletedTask; }));

// ================= helpers =================
string FindRoot()
{
    var d = new DirectoryInfo(AppContext.BaseDirectory);
    while (d is not null && !Directory.Exists(Path.Combine(d.FullName, "Configurations"))) d = d.Parent;
    return d?.FullName ?? throw new Exception("raiz da solution não encontrada");
}

LayoutPackage TempLayout(string xml, string? schema = null, string? customs = null)
{
    var root = Path.Combine(Path.GetTempPath(), "bji-" + Guid.NewGuid().ToString("N"));
    var dir = Path.Combine(root, "L");
    Directory.CreateDirectory(dir);
    File.WriteAllText(Path.Combine(dir, "layout.xml"), xml);
    if (schema is not null) File.WriteAllText(Path.Combine(dir, "schema.json"), schema);
    if (customs is not null) File.WriteAllText(Path.Combine(dir, "customizations.xml"), customs);
    return new LayoutCatalog(root).Load("L");
}

string MiniLayout(string fields) => $"""
    <Layout name="T" identifier="T1">
      <generate name="G">
        <table name="Tab" alias="A">
          <selection>
            <Column name="Nome" type="string" orderby="true" />
            <Column name="Valor" type="decimal" />
            <Column name="NrMatricula" type="string" />
            <Column name="Data" type="datetime" formate="yyyy-MM-dd" />
          </selection>
        </table>
      </generate>
      <Jsonfields name="J"><Refealias name="A"><field name="itens" type="array">{fields}</field></Refealias></Jsonfields>
    </Layout>
    """;

InMemoryRecordSource Mem(params Row[] rows) => new InMemoryRecordSource().Add("A", rows);

void Eq<TV>(TV expected, TV actual, string what = "")
{
    if (!EqualityComparer<TV>.Default.Equals(expected, actual))
        throw new Exception($"{what} esperado [{expected}] obtido [{actual}]");
}
void True(bool cond, string what) { if (!cond) throw new Exception("falhou: " + what); }
void Has(string text, string part) { if (!text.Contains(part)) throw new Exception($"'{part}' não encontrado em: {text}"); }

var profile = (DatabaseKind k) => new ConnectionProfile { Name = "t", Kind = k, Database = "x", Host = "h" };

// ================= ORM: dialetos / SQL =================
T0("ORM: consulta com expressão em 4 dialetos", () =>
{
    var ids = new[] { 1, 2, 3 };
    foreach (var kind in new[] { DatabaseKind.MySql, DatabaseKind.SqlServer, DatabaseKind.PostgreSql, DatabaseKind.Sqlite })
    {
        var f = new FakeFactory();
        using var ctx = new DbContext(profile(kind), f);
        var s = ctx.Set<Cliente>()
            .Where(c => c.Nome!.StartsWith("A_") && c.Saldo > 10 && ids.Contains(c.Id) && c.Criado != null)
            .OrderBy(c => c.Nome).Skip(5).Take(10).ToSql();

        var q = SqlDialects.For(kind);
        Has(s.Sql, $"{q.QuoteIdentifier("nome_cli")} LIKE @__p0 ESCAPE '!'");
        Has(s.Sql, $"{q.QuoteIdentifier("nome_cli")} AS {q.QuoteIdentifier("Nome")}");
        Has(s.Sql, "IN (@__p2, @__p3, @__p4)");
        Has(s.Sql, "IS NOT NULL");
        Eq("A!_%", (string)s.Parameters["__p0"]!, "LIKE escapado");
        Eq(10m, Convert.ToDecimal(s.Parameters["__p1"]), "valor como parâmetro");
        True(!s.Sql.Contains("A_"), "valor não pode aparecer no SQL");
        Has(s.Sql, kind == DatabaseKind.SqlServer ? "OFFSET 5 ROWS FETCH NEXT 10 ROWS ONLY" : "LIMIT 10");
    }
});

T0("ORM: paginação SQL Server sem ORDER BY", () =>
{
    using var ctx = new DbContext(profile(DatabaseKind.SqlServer), new FakeFactory());
    Has(ctx.Set<Cliente>().Take(3).ToSql().Sql, "ORDER BY (SELECT NULL) OFFSET 0 ROWS FETCH NEXT 3 ROWS ONLY");
});

T0("ORM: Insert devolve id (SQL Server OUTPUT)", () =>
{
    var f = new FakeFactory { Responder = sql => sql.Contains("OUTPUT INSERTED") ? Table(("id", typeof(long)), new object[] { 42L }) : null };
    using var ctx = new DbContext(profile(DatabaseKind.SqlServer), f);
    var c = new Cliente { Nome = "Ana", Saldo = 5m };
    var id = ctx.Insert(c);
    Eq(42, c.Id, "id preenchido");
    Eq(42, (int)id!, "retorno");
    Has(f.Log[0].Sql, "OUTPUT INSERTED.[Id]");
    True(!f.Log[0].Sql.Contains("[Id],"), "identidade fora do INSERT");
    True(!f.Log[0].Parameters.Values.Contains("Temp"), "NotMapped ignorado");
});

T0("ORM: Insert MySQL usa LAST_INSERT_ID e PostgreSQL usa RETURNING", () =>
{
    var f = new FakeFactory { Responder = sql => sql.StartsWith("SELECT LAST_INSERT_ID") ? Table(("x", typeof(long)), new object[] { 7L }) : null };
    using (var ctx = new DbContext(profile(DatabaseKind.MariaDb), f))
    {
        var c = new Cliente { Nome = "B" };
        ctx.Insert(c);
        Eq(7, c.Id);
        Eq(2, f.Log.Count, "dois comandos");
        Has(f.Log[0].Sql, "INSERT INTO `Cliente`");
    }
    var f2 = new FakeFactory { Responder = _ => Table(("id", typeof(int)), new object[] { 9 }) };
    using (var ctx = new DbContext(profile(DatabaseKind.PostgreSql), f2))
    {
        var c = new Cliente { Nome = "C" };
        ctx.Insert(c);
        Eq(9, c.Id);
        Has(f2.Log[0].Sql, "RETURNING \"Id\"");
    }
});

T0("ORM: Update e Delete por chave", () =>
{
    var f = new FakeFactory();
    using var ctx = new DbContext(profile(DatabaseKind.Sqlite), f);
    ctx.Update(new Cliente { Id = 3, Nome = "Z", Saldo = 1m });
    ctx.DeleteByKey<Cliente>(3);
    Has(f.Log[0].Sql, "UPDATE \"Cliente\" SET \"nome_cli\" = @p0");
    Has(f.Log[0].Sql, "WHERE \"Id\" = @p4");
    Eq("DELETE FROM \"Cliente\" WHERE \"Id\" = @p0", f.Log[1].Sql);
});

T0("ORM: materialização (snake_case, bool, nulos)", () =>
{
    var dt = new DataTable();
    dt.Columns.Add("Id", typeof(long)); dt.Columns.Add("Nome", typeof(string));
    dt.Columns.Add("Saldo", typeof(double)); dt.Columns.Add("ativo", typeof(long)); dt.Columns.Add("criado", typeof(DateTime));
    dt.Rows.Add(5L, "Ana", 2.5, 1L, DBNull.Value);
    var f = new FakeFactory { Responder = _ => dt };
    using var ctx = new DbContext(profile(DatabaseKind.MySql), f);
    var c = ctx.Query<Cliente>("SELECT * FROM x WHERE id = @id", new { id = 5 }).Single();
    Eq(5, c.Id); Eq("Ana", c.Nome); Eq(2.5m, c.Saldo); True(c.Ativo, "bool de 1"); True(c.Criado is null, "nulo");
    Eq(5, (int)f.Log[0].Parameters["id"]!, "parâmetro nomeado");
});

T0("ORM: transação faz rollback sem Commit", () =>
{
    var f = new FakeFactory();
    using var ctx = new DbContext(profile(DatabaseKind.Sqlite), f);
    using (ctx.BeginTransaction()) { ctx.Execute("DELETE FROM t"); }
    Eq(1, f.Rollbacks, "rollback"); Eq(0, f.Commits);
    using (var tx = ctx.BeginTransaction()) { tx.Commit(); }
    Eq(1, f.Commits);
});

T0("ORM: identificadores perigosos são recusados", () =>
{
    using var ctx = new DbContext(profile(DatabaseKind.MySql), new FakeFactory());
    try { ctx.GetColumnNames("x; DROP TABLE y"); throw new Exception("deveria falhar"); }
    catch (ArgumentException) { }
    True(SqlIdentifier.IsValidTableName("dbo.Clientes"), "schema.tabela");
    True(!SqlIdentifier.IsValidPart("a b"), "espaço");
});

// ================= Conexões criptografadas =================
T0("Conexões: criptografa, descriptografa e detecta segredo errado/adulteração", () =>
{
    var settings = ConnectionStore.Parse("""{"defaultProfile":"a","profiles":[{"name":"a","kind":"MariaDb","host":"h","port":3306,"database":"d","user":"u","password":"p;w\"d"}]}""");
    var path = Path.Combine(Path.GetTempPath(), Guid.NewGuid() + ".json");
    ConnectionStore.Save(path, settings, new LiteralSecretSource("segredo-forte"));

    var raw = File.ReadAllText(path);
    True(!raw.Contains("p;w") && !raw.Contains("MariaDb") && !raw.Contains("host"), "nada legível no arquivo");
    True(ConnectionStore.IsEncrypted(path), "envelope");

    var back = ConnectionStore.Load(path, new LiteralSecretSource("segredo-forte"));
    Eq("p;w\"d", back.Get().Password);
    Eq("Server=h;Port=3306;Database=d;User ID=u;Password=\"p;w\"\"d\";", back.Get().BuildConnectionString());

    try { ConnectionStore.Load(path, new LiteralSecretSource("errado")); throw new Exception("deveria falhar"); }
    catch (ConnectionStoreException) { }

    var node = JsonNode.Parse(raw)!;
    var data = node["data"]!.GetValue<string>();
    node["data"] = (data[0] == 'A' ? "B" : "A") + data[1..];
    File.WriteAllText(path, node.ToJsonString());
    try { ConnectionStore.Load(path, new LiteralSecretSource("segredo-forte")); throw new Exception("adulteração não detectada"); }
    catch (ConnectionStoreException) { }
});

T0("Conexões: texto puro é recusado por padrão; chave em arquivo; senha não vaza no ToString", () =>
{
    var plain = Path.Combine(Path.GetTempPath(), Guid.NewGuid() + ".json");
    File.WriteAllText(plain, """{"profiles":[{"name":"a","kind":"Sqlite","database":"x.db","password":"segredo"}]}""");
    try { ConnectionStore.Load(plain, new LiteralSecretSource("s")); throw new Exception("deveria recusar"); }
    catch (ConnectionStoreException) { }
    Eq("a", ConnectionStore.Load(plain, new LiteralSecretSource("s"), allowPlainText: true).Get().Name);

    var keyPath = Path.Combine(Path.GetTempPath(), Guid.NewGuid() + ".key");
    var ks = new KeyFileSecretSource(keyPath, createIfMissing: true);
    var secret = ks.GetSecret();
    True(secret.Length >= 40, "chave gerada");
    Eq(secret, new KeyFileSecretSource(keyPath).GetSecret());

    var p = new ConnectionProfile { Name = "n", Kind = DatabaseKind.MySql, Host = "h", Database = "d", Password = "segredo" };
    True(!p.ToString().Contains("segredo"), "ToString mascara senha");
});

T0("Conexões: strings por banco", () =>
{
    Eq("Server=s,1433;Database=d;Integrated Security=true;TrustServerCertificate=true;",
        new ConnectionProfile { Kind = DatabaseKind.SqlServer, Host = "s", Port = 1433, Database = "d", IntegratedSecurity = true, Options = { ["TrustServerCertificate"] = "true" } }.BuildConnectionString());
    Eq("Host=h;Port=5432;Database=d;Username=u;Password=p;",
        new ConnectionProfile { Kind = DatabaseKind.PostgreSql, Host = "h", Port = 5432, Database = "d", User = "u", Password = "p" }.BuildConnectionString());
    Eq("Data Source=a.db;", new ConnectionProfile { Kind = DatabaseKind.Sqlite, Database = "a.db" }.BuildConnectionString());
});

// ================= Core =================
T("Core: layout SATUBA + CSV gera JSON válido no Schema", async () =>
{
    var root = FindRoot();
    var catalog = new LayoutCatalog(Path.Combine(root, "Configurations", "Layouts"));
    var pkg = catalog.Load("SATUBA");
    Eq(0, pkg.Issues.Count(i => i.Severity == IssueSeverity.Error), "erros de layout");
    Eq(1, pkg.Layout.Generates.Count); Eq(5, pkg.Layout.Generates[0].Tables[0].Columns.Count);

    var csv = new CsvOptions { DefaultFile = Path.Combine(root, "Configurations", "Layouts", "SATUBA", "sample", "TAB_SATUBA.csv") };
    var run = await new IntegratorService().RunAsync(pkg, new CsvProvider(csv));

    if (run.HasErrors) throw new Exception(string.Join("\n", run.Report.Issues.Where(i => i.Severity == IssueSeverity.Error)));
    var decl = run.Json!["declaracoes"]!.AsArray();
    Eq(2, decl.Count, "declarações");
    Eq("1", decl[0]!["tipoServico"]!.GetValue<string>(), "ordenação orderby");
    Eq("55566677788", decl[0]!["adquirentes"]![0]!["ni"]!.GetValue<string>());
    Eq("000123", decl[0]!["matricula"]!.GetValue<string>(), "zeros à esquerda");
    Eq("2025-11-05", decl[0]!["dataLavraturaRegistroAverbacao"]!.GetValue<string>(), "data pt-BR → ISO");
    Eq("2", decl[0]!["naturezaTitulo"]!.GetValue<string>(), "personalização");
    True(run.JsonText!.Contains("\"participacao\": 100") && !run.JsonText.Contains("\"participacao\": \"100\""), "número, não texto");
    True(run.JsonText.Contains("\"indicadorEspolio\": false"), "default booleano");
    Eq(0, decl[0]!["adquirentes"]![0]!["representantes"]!.AsArray().Count, "array vazio declarado");
});

T("Core: sem personalização o campo fica pendente e a geração é bloqueada", async () =>
{
    var root = FindRoot();
    var dir = Path.Combine(Path.GetTempPath(), "bji-" + Guid.NewGuid().ToString("N"));
    Directory.CreateDirectory(dir);
    CopyDir(Path.Combine(root, "Configurations", "Layouts"), dir);
    File.Delete(Path.Combine(dir, "SATUBA", "customizations.xml"));

    var pkg = new LayoutCatalog(dir).Load("SATUBA");
    var csv = new CsvOptions { DefaultFile = Path.Combine(dir, "SATUBA", "sample", "TAB_SATUBA.csv") };
    var run = await new IntegratorService().RunAsync(pkg, new CsvProvider(csv));

    True(!run.Generated, "não deve gerar");
    Eq("naturezaTitulo", run.Pending.Single().Name);
    True(run.Pending.Single().Required, "obrigatório");
    True(run.Report.Issues.Any(i => i.Code == "CAMPO_NAO_CONFIGURADO" && i.Severity == IssueSeverity.Error), "erro reportado");

    // preencher via personalização e rodar de novo
    pkg.Customizations.Set(new CustomizationEntry { Name = "naturezaTitulo", Mode = CustomizationMode.Fixed, Value = "9" });
    new LayoutCatalog(dir).SaveCustomizations(pkg);
    var again = await new IntegratorService().RunAsync(new LayoutCatalog(dir).Load("SATUBA"), new CsvProvider(csv));
    True(again.Generated && !again.HasErrors, "gera após personalizar");
    Eq("9", again.Json!["declaracoes"]![0]!["naturezaTitulo"]!.GetValue<string>());
});

T("Core: erro de Schema aponta o caminho da propriedade", async () =>
{
    var root = FindRoot();
    var pkg = new LayoutCatalog(Path.Combine(root, "Configurations", "Layouts")).Load("SATUBA");
    var src = new InMemoryRecordSource().Add("TAB_SATUBA", new[]
    {
        new Dictionary<string, object?> { ["TpdeServico"] = "1", ["DtAto"] = new DateTime(2025, 11, 5), ["NrMatricula"] = "1", ["CpfAlienante"] = "11122233344", ["CpfAdquirente"] = "123" },
        new Dictionary<string, object?> { ["TpdeServico"] = "9", ["DtAto"] = new DateTime(2025, 11, 6), ["NrMatricula"] = "2", ["CpfAlienante"] = "11122233344", ["CpfAdquirente"] = "55566677788" },
    });
    var run = await new IntegratorService().RunAsync(pkg, src);
    var paths = run.Report.Issues.Where(i => i.Severity == IssueSeverity.Error).Select(i => i.Path).ToList();
    True(paths.Contains("declaracoes[0].adquirentes[0].ni"), "ni inválido: " + string.Join(",", paths));
    True(paths.Contains("declaracoes[1].tipoServico"), "oneOf/const: " + string.Join(",", paths));
    True(!run.Report.Issues.Any(i => i.Message.Contains("123")), "mensagens sem valores de dados");
});

T("Core: campos legados (value como coluna / ambíguo / coluna ausente)", async () =>
{
    // value="NrMatricula" é coluna declarada -> referência legada
    var pkg = TempLayout(MiniLayout("""
        <field name="m" type="string" value="NrMatricula" />
        <field name="amb" type="string" value="cpfcnpjAdquirente" />
        <field name="uf" type="string" value="SP" />
        <field name="x" type="string" source="Inexistente" />
        """));
    var run = await new IntegratorService().RunAsync(pkg, Mem(new Row { ["Nome"] = "a", ["Valor"] = 1, ["NrMatricula"] = "7", ["Data"] = DateTime.Today }));
    var codes = run.Report.Issues.Select(i => i.Code).ToList();
    True(codes.Contains("VALUE_LEGADO_COMO_COLUNA"), "legado como coluna");
    Eq("amb", run.Pending.Single().Name);
    True(codes.Contains("COLUNA_INEXISTENTE"), "coluna inexistente");
    var x = run.Report.Issues.First(i => i.Code == "COLUNA_INEXISTENTE");
    Has(x.Message, "itens.x"); Has(x.Message, "Inexistente");
    True(!run.Generated, "bloqueado");

    var pkg2 = TempLayout(MiniLayout("""<field name="m" type="string" value="NrMatricula" /><field name="uf" type="string" value="SP" />"""));
    var ok = await new IntegratorService().RunAsync(pkg2, Mem(new Row { ["Nome"] = "a", ["Valor"] = 1, ["NrMatricula"] = "7", ["Data"] = DateTime.Today }));
    Eq("7", ok.Json!["itens"]![0]!["m"]!.GetValue<string>());
    Eq("SP", ok.Json["itens"]![0]!["uf"]!.GetValue<string>(), "literal curto continua literal");
});

T("Core: coluna declarada mas ausente na origem é reportada", async () =>
{
    var pkg = TempLayout(MiniLayout("""<field name="m" type="string" source="NrMatricula" />"""));
    var run = await new IntegratorService().RunAsync(pkg, Mem(new Row { ["Nome"] = "a", ["Valor"] = 1 }));
    var issue = run.Report.Issues.Single(i => i.Code == "COLUNA_AUSENTE_NA_ORIGEM");
    Eq("itens.m", issue.Path);
});

T("Core: conversão de tipos (cultura invariável, inteiro, bool, data, null, precedência)", async () =>
{
    var pkg = TempLayout(MiniLayout("""
        <field name="dec" type="decimal" source="Valor" />
        <field name="dec2" type="decimal" value="100.50" />
        <field name="int" type="integer" value="7" />
        <field name="b" type="bool" source="Nome" trueValues="S,SIM" falseValues="N" />
        <field name="d" type="datetime" source="Data" formate="dd/MM/yyyy" />
        <field name="ds" type="datetime" source="Data" />
        <field name="opt" type="string" source="NrMatricula" />
        <field name="def" type="string" source="NrMatricula" default="padrao" />
        """));
    var run = await new IntegratorService().RunAsync(pkg, Mem(new Row
    {
        ["Nome"] = "SIM", ["Valor"] = "1234,50", ["NrMatricula"] = null, ["Data"] = "31/12/2025"
    }));
    if (run.HasErrors) throw new Exception(string.Join("\n", run.Report.Issues.Where(i => i.Severity == IssueSeverity.Error)));
    var o = run.Json!["itens"]![0]!.AsObject();
    Has(run.JsonText!, "\"dec\": 1234.5,");
    Has(run.JsonText!, "\"dec2\": 100.5,");
    Has(run.JsonText!, "\"int\": 7,");
    Eq(true, o["b"]!.GetValue<bool>());
    Eq("31/12/2025", o["d"]!.GetValue<string>(), "formate de saída");
    Eq("2025-12-31", o["ds"]!.GetValue<string>(), "padrão yyyy-MM-dd");
    True(!o.ContainsKey("opt"), "nulo opcional é omitido, não inventado");
    Eq("padrao", o["def"]!.GetValue<string>(), "default como reserva");
});

T("Core: valor inválido e obrigatório nulo geram erro sem expor o dado", async () =>
{
    var pkg = TempLayout(MiniLayout("""
        <field name="dec" type="decimal" source="Valor" />
        <field name="req" type="string" source="NrMatricula" required="true" />
        """));
    var run = await new IntegratorService().RunAsync(pkg, Mem(
        new Row { ["Nome"] = "a", ["Valor"] = "abc-segredo", ["NrMatricula"] = null, ["Data"] = DateTime.Today },
        new Row { ["Nome"] = "b", ["Valor"] = "x", ["NrMatricula"] = null, ["Data"] = DateTime.Today }));
    True(run.Report.Issues.Any(i => i.Code == "VALOR_INVALIDO"), "valor inválido");
    var req = run.Report.Issues.Single(i => i.Code == "VALOR_OBRIGATORIO_NULO");
    Has(req.Message, "2 ocorrências");
    True(!run.Report.Issues.Any(i => i.Message.Contains("segredo")), "sem dado na mensagem");
});

T0("Core: XXE/DTD é recusado", () =>
{
    try
    {
        XmlLayoutReader.LoadText("""<?xml version="1.0"?><!DOCTYPE x [<!ENTITY e SYSTEM "file:///etc/passwd">]><Layout name="a">&e;</Layout>""");
        throw new Exception("DTD aceito");
    }
    catch (LayoutException) { }
});

T0("Core: JSON Schema (tipos, required, additionalProperties, $ref, enum, formato)", () =>
{
    var v = JsonSchemaValidator.Parse("""
        {"type":"object","required":["a"],"additionalProperties":false,
         "properties":{"a":{"$ref":"#/$defs/s"},"n":{"type":"integer","minimum":1},"d":{"type":"string","format":"date"},"e":{"enum":["x","y"]},"l":{"type":"array","items":{"type":"string"},"maxItems":1}},
         "$defs":{"s":{"type":"string","minLength":2}}}
        """);
    Eq(0, v.Validate(JsonNode.Parse("""{"a":"ok","n":2,"d":"2025-02-28","e":"x","l":["q"]}""")).Count, "válido");
    var errs = v.Validate(JsonNode.Parse("""{"a":"x","n":1.5,"d":"2025-02-30","e":"z","l":[1,"b"],"extra":1}""")).Select(i => (i.Path, i.Code)).ToList();
    True(errs.Contains(("a", "MIN_TAMANHO")), "minLength via $ref");
    True(errs.Contains(("n", "TIPO")), "integer");
    True(errs.Contains(("d", "FORMATO")), "data inexistente");
    True(errs.Contains(("e", "ENUM")), "enum");
    True(errs.Contains(("l[0]", "TIPO")), "item do array");
    True(errs.Contains(("l", "MAX_ITENS")), "maxItems");
    True(errs.Contains(("extra", "PROPRIEDADE_ADICIONAL")), "adicional");
    True(v.Validate(JsonNode.Parse("""{}""")).Any(i => i.Code == "OBRIGATORIO"), "required");
});

T0("Core: máscara de CPF/CNPJ no log", () =>
{
    var m = PiiMasker.Mask("cpf 111.222.333-44 cnpj 12.345.678/0001-99 e 11122233344");
    True(!m.Contains("111") && !m.Contains("12.345") && !m.Contains("1122223"), m);
});

T0("Core: exportação — não sobrescreve, bloqueia JSON com erro, grava relatório", () =>
{
    var dir = Path.Combine(Path.GetTempPath(), "bji-out-" + Guid.NewGuid().ToString("N"));
    var run = new RunResult { Json = new JsonObject { ["a"] = 1 }, JsonText = "{\"a\":1}" };
    var svc = new ExportService();
    var opt = new ExportOptions { OutputRoot = dir, LayoutFolder = "L", Subfolder = "2026" };

    var r = svc.Export(run, opt);
    True(File.Exists(r.JsonPath!) && File.Exists(r.ReportPath), "arquivos");
    try { svc.Export(run, opt); throw new Exception("sobrescreveu"); } catch (IOException) { }

    opt.Overwrite = OverwritePolicy.AddTimestamp;
    True(svc.Export(run, opt).JsonPath != r.JsonPath, "sufixo de data/hora");

    run.Report.Issues.Add(new ValidationIssue(IssueSeverity.Error, "X", "erro"));
    opt.Subfolder = "2027";
    var bad = svc.Export(run, opt);
    True(bad.JsonSkippedBecauseOfErrors && bad.JsonPath is null && File.Exists(bad.ReportPath), "JSON bloqueado, relatório gravado");
});

T0("Core: catálogo versiona o layout", () =>
{
    var pkg = TempLayout(MiniLayout("""<field name="m" type="string" value="1" />"""));
    var root = Path.GetDirectoryName(pkg.Folder)!;
    var cat = new LayoutCatalog(root);
    Eq("1", pkg.Metadata.LayoutVersion);
    var v = cat.SaveLayoutXml("L", pkg.LayoutXml.Replace("value=\"1\"", "value=\"2\""));
    Eq("2", v);
    True(File.Exists(Path.Combine(pkg.Folder, "versions", "layout.v1.xml")), "versão anterior arquivada");
    True(cat.Load("L").Hash != pkg.Hash, "hash muda");
});

// ================= Data =================
T0("Data: CSV (aspas, delimitador, quebra de linha em campo)", () =>
{
    var rows = CsvProvider.Parse("a;b\r\n\"x;1\";\"linha1\nlinha2\"\r\n\"aspas \"\"ok\"\"\";z\r\n", ';');
    Eq(3, rows.Count); Eq("x;1", rows[1][0]); Eq("linha1\nlinha2", rows[1][1]); Eq("aspas \"ok\"", rows[2][0]);
});

T("Data: DatabaseProvider seleciona só colunas existentes, filtra por parâmetro e ordena", async () =>
{
    var f = new FakeFactory
    {
        Responder = sql =>
        {
            if (sql.Contains("1 = 0"))
            {
                var h = new DataTable();
                foreach (var c in new[] { "TpdeServico", "DtAto", "NrMatricula" }) h.Columns.Add(c, typeof(string));
                return h;
            }
            var d = new DataTable();
            d.Columns.Add("TpdeServico"); d.Columns.Add("DtAto"); d.Columns.Add("NrMatricula");
            d.Rows.Add("1", "2025-11-05", "9");
            return d;
        }
    };
    using var ctx = new DbContext(profile(DatabaseKind.MariaDb), f);
    var table = new TableDefinition { Name = "ComunicaoPrefeitura", Alias = "TAB" };
    table.Columns.Add(new ColumnDefinition { Name = "TpdeServico", OrderBy = true });
    table.Columns.Add(new ColumnDefinition { Name = "DtAto" });
    table.Columns.Add(new ColumnDefinition { Name = "NrMatricula" });
    table.Columns.Add(new ColumnDefinition { Name = "CpfAlienante" }); // não existe no banco

    var set = await new DatabaseProvider(ctx).LoadAsync(table, new[] { new SourceFilter("DtAto", FilterOperator.GreaterOrEqual, new DateTime(2025, 1, 1)) });
    var select = f.Log.Last();
    Eq("SELECT `TpdeServico`, `DtAto`, `NrMatricula` FROM `ComunicaoPrefeitura` WHERE `DtAto` >= @f0 ORDER BY `TpdeServico`", select.Sql);
    Eq(new DateTime(2025, 1, 1), (DateTime)select.Parameters["f0"]!, "valor por parâmetro");
    Eq(3, set.Columns.Count); Eq("9", (string)set.Rows[0]["NrMatricula"]!);
});

// ================= execução =================
static DataTable Table((string Name, Type Type) col, object[] row)
{
    var t = new DataTable();
    t.Columns.Add(col.Name, col.Type);
    t.Rows.Add(row);
    return t;
}

static void CopyDir(string from, string to)
{
    foreach (var d in Directory.GetDirectories(from, "*", SearchOption.AllDirectories)) Directory.CreateDirectory(d.Replace(from, to));
    foreach (var f in Directory.GetFiles(from, "*", SearchOption.AllDirectories)) File.Copy(f, f.Replace(from, to), true);
}

int failed = 0;
foreach (var (name, body) in tests)
{
    try { await body(); Console.WriteLine($"  OK    {name}"); }
    catch (Exception ex) { failed++; Console.WriteLine($"  FALHA {name}\n        {ex.Message.Replace("\n", "\n        ")}"); }
}
Console.WriteLine($"\n{tests.Count - failed}/{tests.Count} testes passaram.");
return failed == 0 ? 0 : 1;
