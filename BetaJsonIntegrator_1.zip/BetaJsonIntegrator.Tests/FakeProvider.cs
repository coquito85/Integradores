using System.Collections;
using System.Data;
using System.Data.Common;
using System.Diagnostics.CodeAnalysis;

namespace BetaJsonIntegrator.Tests;

public sealed record Executed(string Sql, Dictionary<string, object?> Parameters);

/// <summary>Provedor ADO.NET falso: registra comandos e responde com DataTables.</summary>
public sealed class FakeFactory : DbProviderFactory
{
    public List<Executed> Log { get; } = new();
    public Func<string, DataTable?>? Responder { get; set; }
    public int Commits, Rollbacks;

    public override DbConnection CreateConnection() => new FakeConnection(this);
    public override DbCommand CreateCommand() => new FakeCommand(this);
    public override DbParameter CreateParameter() => new FakeParameter();
}

public sealed class FakeConnection : DbConnection
{
    private readonly FakeFactory _f;
    private ConnectionState _state = ConnectionState.Closed;
    public FakeConnection(FakeFactory f) => _f = f;

    [AllowNull] public override string ConnectionString { get; set; } = "";
    public override string Database => "fake";
    public override string DataSource => "fake";
    public override string ServerVersion => "1";
    public override ConnectionState State => _state;
    public override void ChangeDatabase(string databaseName) { }
    public override void Close() => _state = ConnectionState.Closed;
    public override void Open() => _state = ConnectionState.Open;
    protected override DbTransaction BeginDbTransaction(IsolationLevel isolationLevel) => new FakeTransaction(_f, this);
    protected override DbCommand CreateDbCommand() => new FakeCommand(_f) { Connection = this };
}

public sealed class FakeTransaction : DbTransaction
{
    private readonly FakeFactory _f;
    private readonly DbConnection _c;
    public FakeTransaction(FakeFactory f, DbConnection c) { _f = f; _c = c; }
    public override IsolationLevel IsolationLevel => IsolationLevel.ReadCommitted;
    protected override DbConnection DbConnection => _c;
    public override void Commit() => _f.Commits++;
    public override void Rollback() => _f.Rollbacks++;
}

public sealed class FakeCommand : DbCommand
{
    private readonly FakeFactory _f;
    private readonly FakeParamCollection _params = new();
    public FakeCommand(FakeFactory f) => _f = f;

    [AllowNull] public override string CommandText { get; set; } = "";
    public override int CommandTimeout { get; set; }
    public override CommandType CommandType { get; set; }
    public override bool DesignTimeVisible { get; set; }
    public override UpdateRowSource UpdatedRowSource { get; set; }
    protected override DbConnection? DbConnection { get; set; }
    protected override DbParameterCollection DbParameterCollection => _params;
    protected override DbTransaction? DbTransaction { get; set; }

    public override void Cancel() { }
    public override void Prepare() { }
    protected override DbParameter CreateDbParameter() => new FakeParameter();

    private void Record() =>
        _f.Log.Add(new Executed(CommandText, _params.Items.ToDictionary(p => p.ParameterName.TrimStart('@'), p => p.Value is DBNull ? null : p.Value)));

    public override int ExecuteNonQuery() { Record(); return 1; }

    public override object? ExecuteScalar()
    {
        Record();
        var t = _f.Responder?.Invoke(CommandText);
        return t is { Rows.Count: > 0 } ? t.Rows[0][0] : null;
    }

    protected override DbDataReader ExecuteDbDataReader(CommandBehavior behavior)
    {
        Record();
        var t = _f.Responder?.Invoke(CommandText) ?? new DataTable();
        return new DataTableReader(t);
    }
}

public sealed class FakeParameter : DbParameter
{
    public override DbType DbType { get; set; }
    public override ParameterDirection Direction { get; set; }
    public override bool IsNullable { get; set; }
    [AllowNull] public override string ParameterName { get; set; } = "";
    public override int Size { get; set; }
    [AllowNull] public override string SourceColumn { get; set; } = "";
    public override bool SourceColumnNullMapping { get; set; }
    public override object? Value { get; set; }
    public override void ResetDbType() { }
}

public sealed class FakeParamCollection : DbParameterCollection
{
    public List<DbParameter> Items { get; } = new();
    public override int Count => Items.Count;
    public override object SyncRoot => Items;
    public override int Add(object value) { Items.Add((DbParameter)value); return Items.Count - 1; }
    public override void AddRange(Array values) { foreach (var v in values) Add(v!); }
    public override void Clear() => Items.Clear();
    public override bool Contains(object value) => Items.Contains((DbParameter)value);
    public override bool Contains(string value) => IndexOf(value) >= 0;
    public override void CopyTo(Array array, int index) => ((ICollection)Items).CopyTo(array, index);
    public override IEnumerator GetEnumerator() => Items.GetEnumerator();
    public override int IndexOf(object value) => Items.IndexOf((DbParameter)value);
    public override int IndexOf(string parameterName) => Items.FindIndex(p => p.ParameterName == parameterName);
    public override void Insert(int index, object value) => Items.Insert(index, (DbParameter)value);
    public override void Remove(object value) => Items.Remove((DbParameter)value);
    public override void RemoveAt(int index) => Items.RemoveAt(index);
    public override void RemoveAt(string parameterName) => Items.RemoveAt(IndexOf(parameterName));
    protected override DbParameter GetParameter(int index) => Items[index];
    protected override DbParameter GetParameter(string parameterName) => Items[IndexOf(parameterName)];
    protected override void SetParameter(int index, DbParameter value) => Items[index] = value;
    protected override void SetParameter(string parameterName, DbParameter value) => Items[IndexOf(parameterName)] = value;
}
