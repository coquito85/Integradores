using BetaJsonIntegrator.Orm;

namespace BetaJsonIntegrator.Tests;

public class Cliente
{
    [Key] public int Id { get; set; }
    [Column("nome_cli")] public string? Nome { get; set; }
    public decimal? Saldo { get; set; }
    public bool Ativo { get; set; }
    public DateTime? Criado { get; set; }
    [NotMapped] public string? Temp { get; set; }
}
