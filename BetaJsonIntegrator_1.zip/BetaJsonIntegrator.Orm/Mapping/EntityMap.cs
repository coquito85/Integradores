using System.Collections.Concurrent;
using System.Reflection;

namespace BetaJsonIntegrator.Orm;

public sealed class PropertyMap
{
    public PropertyInfo Property { get; }
    public string ColumnName { get; }
    public bool IsKey { get; }
    public bool IsAutoIncrement { get; }
    public Type ClrType => Property.PropertyType;

    internal PropertyMap(PropertyInfo property, string columnName, bool isKey, bool isAutoIncrement)
    {
        Property = property;
        ColumnName = columnName;
        IsKey = isKey;
        IsAutoIncrement = isAutoIncrement;
    }

    public object? GetValue(object entity) => Property.GetValue(entity);
    public void SetValue(object entity, object? value) => Property.SetValue(entity, value);
}

/// <summary>Metadados de uma entidade (tabela, colunas, chaves), calculados uma vez por tipo.</summary>
public sealed class EntityMap
{
    private static readonly ConcurrentDictionary<Type, EntityMap> Cache = new();

    public Type EntityType { get; }
    public string TableName { get; }
    public string? Schema { get; }
    public IReadOnlyList<PropertyMap> Properties { get; }
    public IReadOnlyList<PropertyMap> Keys { get; }
    public PropertyMap? Identity { get; }

    public static EntityMap For<T>() => For(typeof(T));
    public static EntityMap For(Type type) => Cache.GetOrAdd(type, t => new EntityMap(t));

    private EntityMap(Type type)
    {
        EntityType = type;
        var table = type.GetCustomAttribute<TableAttribute>();
        TableName = table?.Name ?? type.Name;
        Schema = table?.Schema;

        var props = type.GetProperties(BindingFlags.Public | BindingFlags.Instance)
            .Where(p => p.CanRead && p.CanWrite && p.GetIndexParameters().Length == 0 && p.GetCustomAttribute<NotMappedAttribute>() is null)
            .ToList();

        var keyProps = props.Where(p => p.GetCustomAttribute<KeyAttribute>() is not null).ToList();
        if (keyProps.Count == 0)
        {
            // Convenção: "Id" ou "<Tabela>Id" vira chave
            var conv = props.FirstOrDefault(p => p.Name.Equals("Id", StringComparison.OrdinalIgnoreCase))
                       ?? props.FirstOrDefault(p => p.Name.Equals(type.Name + "Id", StringComparison.OrdinalIgnoreCase));
            if (conv is not null) keyProps.Add(conv);
        }

        var list = new List<PropertyMap>();
        foreach (var p in props)
        {
            var isKey = keyProps.Contains(p);
            var keyAttr = p.GetCustomAttribute<KeyAttribute>();
            var auto = isKey && keyProps.Count == 1 && (keyAttr?.AutoIncrement ?? true) && IsIntegral(p.PropertyType);
            var col = p.GetCustomAttribute<ColumnAttribute>()?.Name ?? p.Name;
            list.Add(new PropertyMap(p, col, isKey, auto));
        }

        Properties = list;
        Keys = list.Where(p => p.IsKey).ToList();
        Identity = list.FirstOrDefault(p => p.IsAutoIncrement);
    }

    public PropertyMap GetByProperty(string propertyName) =>
        Properties.FirstOrDefault(p => p.Property.Name == propertyName)
        ?? throw new InvalidOperationException($"Propriedade '{propertyName}' não é mapeada em {EntityType.Name}.");

    private static bool IsIntegral(Type t)
    {
        t = Nullable.GetUnderlyingType(t) ?? t;
        return t == typeof(int) || t == typeof(long) || t == typeof(short) || t == typeof(uint) || t == typeof(ulong);
    }
}
