using System.Collections.Concurrent;
using System.Data.Common;
using System.Reflection;

namespace BetaJsonIntegrator.Orm;

/// <summary>
/// Localiza o DbProviderFactory de cada banco por reflexão, sem referência em tempo de compilação
/// aos drivers. Os pacotes NuGet só precisam estar na pasta do executável.
/// </summary>
public static class ProviderRegistry
{
    private static readonly ConcurrentDictionary<DatabaseKind, DbProviderFactory> Cache = new();

    private static readonly Dictionary<DatabaseKind, (string[] Types, string Package)> Known = new()
    {
        [DatabaseKind.MySql] = (new[] { "MySqlConnector.MySqlConnectorFactory, MySqlConnector", "MySql.Data.MySqlClient.MySqlClientFactory, MySql.Data" }, "MySqlConnector"),
        [DatabaseKind.MariaDb] = (new[] { "MySqlConnector.MySqlConnectorFactory, MySqlConnector", "MySql.Data.MySqlClient.MySqlClientFactory, MySql.Data" }, "MySqlConnector"),
        [DatabaseKind.SqlServer] = (new[] { "Microsoft.Data.SqlClient.SqlClientFactory, Microsoft.Data.SqlClient", "System.Data.SqlClient.SqlClientFactory, System.Data.SqlClient" }, "Microsoft.Data.SqlClient"),
        [DatabaseKind.PostgreSql] = (new[] { "Npgsql.NpgsqlFactory, Npgsql" }, "Npgsql"),
        [DatabaseKind.Sqlite] = (new[] { "Microsoft.Data.Sqlite.SqliteFactory, Microsoft.Data.Sqlite" }, "Microsoft.Data.Sqlite")
    };

    /// <summary>Registra manualmente um factory (testes, drivers customizados).</summary>
    public static void Register(DatabaseKind kind, DbProviderFactory factory) => Cache[kind] = factory;

    public static DbProviderFactory Get(DatabaseKind kind)
    {
        if (Cache.TryGetValue(kind, out var cached)) return cached;

        var (types, package) = Known[kind];
        foreach (var typeName in types)
        {
            var type = Type.GetType(typeName, throwOnError: false);
            if (type is null) continue;

            var instance = type.GetField("Instance", BindingFlags.Public | BindingFlags.Static)?.GetValue(null)
                           ?? type.GetProperty("Instance", BindingFlags.Public | BindingFlags.Static)?.GetValue(null);

            if (instance is DbProviderFactory factory)
            {
                Cache[kind] = factory;
                return factory;
            }
        }

        throw new InvalidOperationException(
            $"Driver para {kind} não encontrado. Instale o pacote NuGet '{package}' no projeto executável.");
    }
}
