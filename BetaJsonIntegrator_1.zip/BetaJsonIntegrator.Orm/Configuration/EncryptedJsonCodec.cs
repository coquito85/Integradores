using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace BetaJsonIntegrator.Orm;

public sealed class ConnectionStoreException : Exception
{
    public ConnectionStoreException(string message, Exception? inner = null) : base(message, inner) { }
}

/// <summary>
/// Envelope criptografado: AES-256-GCM com chave derivada do segredo por PBKDF2-SHA256.
/// Sal e nonce são aleatórios a cada gravação; o GCM detecta adulteração do arquivo.
/// </summary>
public static class EncryptedJsonCodec
{
    public const string FormatName = "bji-enc";
    private const int Version = 1;
    private const int DefaultIterations = 210_000;
    private static readonly byte[] Aad = Encoding.UTF8.GetBytes("BetaJsonIntegrator.Connections.v1");

    private sealed class Envelope
    {
        [JsonPropertyName("format")] public string Format { get; set; } = FormatName;
        [JsonPropertyName("version")] public int Version { get; set; }
        [JsonPropertyName("kdf")] public string Kdf { get; set; } = "PBKDF2-SHA256";
        [JsonPropertyName("iterations")] public int Iterations { get; set; }
        [JsonPropertyName("salt")] public string Salt { get; set; } = "";
        [JsonPropertyName("nonce")] public string Nonce { get; set; } = "";
        [JsonPropertyName("tag")] public string Tag { get; set; } = "";
        [JsonPropertyName("data")] public string Data { get; set; } = "";
    }

    private static readonly JsonSerializerOptions EnvelopeOptions = new() { WriteIndented = true };

    public static bool IsEnvelope(string text)
    {
        try
        {
            using var doc = JsonDocument.Parse(text, new JsonDocumentOptions { AllowTrailingCommas = true, CommentHandling = JsonCommentHandling.Skip });
            return doc.RootElement.ValueKind == JsonValueKind.Object
                   && doc.RootElement.TryGetProperty("format", out var f)
                   && f.ValueKind == JsonValueKind.String
                   && f.GetString() == FormatName;
        }
        catch (JsonException)
        {
            return false;
        }
    }

    public static string Encrypt(string plainText, string secret, int iterations = DefaultIterations)
    {
        var salt = RandomNumberGenerator.GetBytes(16);
        var nonce = RandomNumberGenerator.GetBytes(12);
        var key = DeriveKey(secret, salt, iterations);
        try
        {
            var plain = Encoding.UTF8.GetBytes(plainText);
            var cipher = new byte[plain.Length];
            var tag = new byte[16];

            using (var aes = new AesGcm(key, tagSizeInBytes: 16))
                aes.Encrypt(nonce, plain, cipher, tag, Aad);

            CryptographicOperations.ZeroMemory(plain);

            return JsonSerializer.Serialize(new Envelope
            {
                Version = Version,
                Iterations = iterations,
                Salt = Convert.ToBase64String(salt),
                Nonce = Convert.ToBase64String(nonce),
                Tag = Convert.ToBase64String(tag),
                Data = Convert.ToBase64String(cipher)
            }, EnvelopeOptions);
        }
        finally
        {
            CryptographicOperations.ZeroMemory(key);
        }
    }

    public static string Decrypt(string envelopeJson, string secret)
    {
        Envelope env;
        try
        {
            env = JsonSerializer.Deserialize<Envelope>(envelopeJson) ?? throw new JsonException("vazio");
        }
        catch (JsonException ex)
        {
            throw new ConnectionStoreException("Arquivo de conexões inválido (envelope ilegível).", ex);
        }

        if (env.Format != FormatName || env.Version != Version)
            throw new ConnectionStoreException($"Formato de arquivo não suportado ({env.Format} v{env.Version}).");

        byte[] key = Array.Empty<byte>();
        try
        {
            var salt = Convert.FromBase64String(env.Salt);
            var nonce = Convert.FromBase64String(env.Nonce);
            var tag = Convert.FromBase64String(env.Tag);
            var cipher = Convert.FromBase64String(env.Data);
            key = DeriveKey(secret, salt, env.Iterations);

            var plain = new byte[cipher.Length];
            using (var aes = new AesGcm(key, tagSizeInBytes: 16))
                aes.Decrypt(nonce, cipher, tag, plain, Aad);

            var text = Encoding.UTF8.GetString(plain);
            CryptographicOperations.ZeroMemory(plain);
            return text;
        }
        catch (CryptographicException ex)
        {
            throw new ConnectionStoreException("Não foi possível descriptografar: segredo incorreto ou arquivo adulterado.", ex);
        }
        catch (FormatException ex)
        {
            throw new ConnectionStoreException("Arquivo de conexões corrompido (base64 inválido).", ex);
        }
        finally
        {
            CryptographicOperations.ZeroMemory(key);
        }
    }

    private static byte[] DeriveKey(string secret, byte[] salt, int iterations)
    {
        if (string.IsNullOrEmpty(secret)) throw new ConnectionStoreException("Segredo vazio.");
        if (iterations < 100_000) throw new ConnectionStoreException("Número de iterações PBKDF2 abaixo do mínimo aceito.");
        return Rfc2898DeriveBytes.Pbkdf2(Encoding.UTF8.GetBytes(secret), salt, iterations, HashAlgorithmName.SHA256, 32);
    }
}
