using System.Text.Json;
using System.Text.Json.Serialization;

namespace BetaJsonIntegrator.Orm;

/// <summary>Lê e grava o JSON de conexões, criptografado em disco.</summary>
public static class ConnectionStore
{
    public static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNameCaseInsensitive = true,
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        ReadCommentHandling = JsonCommentHandling.Skip,
        AllowTrailingCommas = true,
        WriteIndented = true,
        Converters = { new JsonStringEnumConverter() }
    };

    public static bool IsEncrypted(string path) => EncryptedJsonCodec.IsEnvelope(File.ReadAllText(path));

    /// <summary>
    /// Carrega as conexões. Arquivo em texto puro só é aceito com <paramref name="allowPlainText"/>
    /// (útil em desenvolvimento); por padrão é recusado.
    /// </summary>
    public static ConnectionSettings Load(string path, SecretSource secret, bool allowPlainText = false)
    {
        if (!File.Exists(path)) throw new ConnectionStoreException($"Arquivo de conexões não encontrado: {path}");

        var text = File.ReadAllText(path);
        string json;
        if (EncryptedJsonCodec.IsEnvelope(text))
        {
            json = EncryptedJsonCodec.Decrypt(text, secret.GetSecret());
        }
        else if (allowPlainText)
        {
            json = text;
        }
        else
        {
            throw new ConnectionStoreException("O arquivo de conexões não está criptografado. Use 'bji-tools encrypt' para protegê-lo.");
        }

        return Parse(json);
    }

    public static ConnectionSettings Parse(string json)
    {
        try
        {
            var settings = JsonSerializer.Deserialize<ConnectionSettings>(json, JsonOptions)
                           ?? throw new ConnectionStoreException("Arquivo de conexões vazio.");
            Validate(settings);
            return settings;
        }
        catch (JsonException ex)
        {
            throw new ConnectionStoreException("JSON de conexões inválido: " + ex.Message, ex);
        }
    }

    public static string Serialize(ConnectionSettings settings) => JsonSerializer.Serialize(settings, JsonOptions);

    /// <summary>Grava criptografado, de forma atômica (arquivo temporário + troca).</summary>
    public static void Save(string path, ConnectionSettings settings, SecretSource secret)
    {
        Validate(settings);
        WriteAtomic(path, EncryptedJsonCodec.Encrypt(Serialize(settings), secret.GetSecret()));
    }

    public static void EncryptFile(string plainPath, string outPath, SecretSource secret)
    {
        var settings = Parse(File.ReadAllText(plainPath));
        Save(outPath, settings, secret);
    }

    public static void DecryptFile(string encryptedPath, string outPath, SecretSource secret)
    {
        var settings = Load(encryptedPath, secret);
        File.WriteAllText(outPath, Serialize(settings));
    }

    private static void Validate(ConnectionSettings s)
    {
        var names = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (var p in s.Profiles)
        {
            if (string.IsNullOrWhiteSpace(p.Name)) throw new ConnectionStoreException("Há um perfil de conexão sem 'name'.");
            if (!names.Add(p.Name)) throw new ConnectionStoreException($"Perfil de conexão duplicado: '{p.Name}'.");
            if (string.IsNullOrWhiteSpace(p.ConnectionString) && string.IsNullOrWhiteSpace(p.Database))
                throw new ConnectionStoreException($"Perfil '{p.Name}': informe 'connectionString' ou 'database'.");
        }

        if (!string.IsNullOrWhiteSpace(s.DefaultProfile) && !names.Contains(s.DefaultProfile))
            throw new ConnectionStoreException($"'defaultProfile' aponta para um perfil inexistente: '{s.DefaultProfile}'.");
    }

    private static void WriteAtomic(string path, string content)
    {
        var full = Path.GetFullPath(path);
        var dir = Path.GetDirectoryName(full);
        if (!string.IsNullOrEmpty(dir)) Directory.CreateDirectory(dir);

        var tmp = full + ".tmp";
        File.WriteAllText(tmp, content);
        File.Move(tmp, full, overwrite: true);
    }
}
