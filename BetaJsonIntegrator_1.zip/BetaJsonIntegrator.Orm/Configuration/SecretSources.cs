using System.Security.Cryptography;

namespace BetaJsonIntegrator.Orm;

/// <summary>De onde vem o segredo (senha-mestra) que protege o arquivo de conexões.</summary>
public abstract class SecretSource
{
    public abstract string? TryGetSecret();

    public string GetSecret() => TryGetSecret()
        ?? throw new ConnectionStoreException("Segredo do arquivo de conexões não encontrado (variável de ambiente ou arquivo de chave).");

    /// <summary>Variável de ambiente BETA_DB_SECRET; se ausente, o arquivo connections.key ao lado do arquivo.</summary>
    public static SecretSource Default(string baseDirectory) => new ChainSecretSource(
        new EnvironmentSecretSource(),
        new KeyFileSecretSource(Path.Combine(baseDirectory, "connections.key")));
}

public sealed class LiteralSecretSource : SecretSource
{
    private readonly string _secret;
    public LiteralSecretSource(string secret) => _secret = secret;
    public override string? TryGetSecret() => string.IsNullOrEmpty(_secret) ? null : _secret;
}

public sealed class EnvironmentSecretSource : SecretSource
{
    private readonly string _variable;
    public EnvironmentSecretSource(string variable = "BETA_DB_SECRET") => _variable = variable;

    public override string? TryGetSecret()
    {
        var v = Environment.GetEnvironmentVariable(_variable);
        return string.IsNullOrWhiteSpace(v) ? null : v.Trim();
    }
}

public sealed class KeyFileSecretSource : SecretSource
{
    private readonly string _path;
    private readonly bool _createIfMissing;

    public KeyFileSecretSource(string path, bool createIfMissing = false)
    {
        _path = path;
        _createIfMissing = createIfMissing;
    }

    public string Path => _path;

    public override string? TryGetSecret()
    {
        if (!File.Exists(_path))
        {
            if (!_createIfMissing) return null;
            Create(_path);
        }

        var text = File.ReadAllText(_path).Trim();
        return text.Length == 0 ? null : text;
    }

    /// <summary>Gera 32 bytes aleatórios (base64) e grava no arquivo.</summary>
    public static void Create(string path)
    {
        var dir = System.IO.Path.GetDirectoryName(System.IO.Path.GetFullPath(path));
        if (!string.IsNullOrEmpty(dir)) Directory.CreateDirectory(dir);

        File.WriteAllText(path, Convert.ToBase64String(RandomNumberGenerator.GetBytes(32)));
        try { File.SetAttributes(path, FileAttributes.Hidden | FileAttributes.ReadOnly); } catch { /* melhor esforço */ }
    }
}

public sealed class ChainSecretSource : SecretSource
{
    private readonly SecretSource[] _sources;
    public ChainSecretSource(params SecretSource[] sources) => _sources = sources;

    public override string? TryGetSecret()
    {
        foreach (var s in _sources)
        {
            var v = s.TryGetSecret();
            if (v is not null) return v;
        }
        return null;
    }
}
