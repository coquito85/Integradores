using System.Text;
using System.Text.Json.Serialization;

namespace BetaJsonIntegrator.Orm;

/// <summary>Uma conexão nomeada do arquivo JSON de conexões.</summary>
public sealed class ConnectionProfile
{
    public string Name { get; set; } = "";
    public DatabaseKind Kind { get; set; } = DatabaseKind.MySql;
    public string? Host { get; set; }
    public int? Port { get; set; }

    /// <summary>Nome do banco. Em SQLite é o caminho do arquivo.</summary>
    public string? Database { get; set; }
    public string? User { get; set; }
    public string? Password { get; set; }

    /// <summary>SQL Server: usa autenticação do Windows (ignora User/Password).</summary>
    public bool IntegratedSecurity { get; set; }

    /// <summary>Se informada, é usada como está e os campos acima são ignorados.</summary>
    public string? ConnectionString { get; set; }

    public int CommandTimeoutSeconds { get; set; } = 30;

    /// <summary>Opções extras do driver, ex.: { "SslMode": "None" }.</summary>
    public Dictionary<string, string> Options { get; set; } = new(StringComparer.OrdinalIgnoreCase);

    [JsonIgnore]
    public string DisplayName => $"{Name} ({Kind})";

    public string BuildConnectionString()
    {
        if (!string.IsNullOrWhiteSpace(ConnectionString)) return ConnectionString!;

        var sb = new StringBuilder();
        void Add(string key, string? value)
        {
            if (string.IsNullOrEmpty(value)) return;
            sb.Append(key).Append('=').Append(Quote(value)).Append(';');
        }

        switch (Kind)
        {
            case DatabaseKind.MySql:
            case DatabaseKind.MariaDb:
                Add("Server", Host);
                if (Port is not null) Add("Port", Port.ToString());
                Add("Database", Database);
                Add("User ID", User);
                Add("Password", Password);
                break;

            case DatabaseKind.SqlServer:
                Add("Server", Port is null ? Host : $"{Host},{Port}");
                Add("Database", Database);
                if (IntegratedSecurity) Add("Integrated Security", "true");
                else { Add("User Id", User); Add("Password", Password); }
                break;

            case DatabaseKind.PostgreSql:
                Add("Host", Host);
                if (Port is not null) Add("Port", Port.ToString());
                Add("Database", Database);
                Add("Username", User);
                Add("Password", Password);
                break;

            case DatabaseKind.Sqlite:
                Add("Data Source", Database);
                Add("Password", Password);
                break;
        }

        foreach (var (k, v) in Options) Add(k, v);
        return sb.ToString();
    }

    /// <summary>Nunca expõe senha.</summary>
    public override string ToString() =>
        $"{Name} [{Kind}] " + (string.IsNullOrEmpty(Host) ? "" : $"{Host}{(Port is null ? "" : ":" + Port)}/") + Database;

    private static string Quote(string value)
    {
        var needs = value.Any(c => c is ';' or '"' or '\'' or '=') || value != value.Trim();
        return needs ? "\"" + value.Replace("\"", "\"\"") + "\"" : value;
    }
}

/// <summary>Conteúdo do JSON de conexões (antes de criptografar / depois de descriptografar).</summary>
public sealed class ConnectionSettings
{
    public string? DefaultProfile { get; set; }
    public List<ConnectionProfile> Profiles { get; set; } = new();

    public ConnectionProfile Get(string? name = null)
    {
        name ??= DefaultProfile;
        if (string.IsNullOrWhiteSpace(name))
        {
            if (Profiles.Count == 1) return Profiles[0];
            throw new InvalidOperationException("Nenhum perfil informado e o arquivo não define 'defaultProfile'.");
        }

        return Profiles.FirstOrDefault(p => p.Name.Equals(name, StringComparison.OrdinalIgnoreCase))
               ?? throw new KeyNotFoundException($"Perfil de conexão '{name}' não encontrado.");
    }
}
