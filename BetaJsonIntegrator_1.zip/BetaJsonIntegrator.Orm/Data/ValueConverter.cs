using System.Globalization;

namespace BetaJsonIntegrator.Orm;

/// <summary>Conversões entre tipos CLR e o que os drivers aceitam/devolvem.</summary>
public static class ValueConverter
{
    /// <summary>CLR → valor de parâmetro.</summary>
    public static object ToDb(object? value) => value switch
    {
        null => DBNull.Value,
        DBNull => DBNull.Value,
        Enum e => Convert.ChangeType(e, Enum.GetUnderlyingType(e.GetType()), CultureInfo.InvariantCulture),
        DateOnly d => d.ToDateTime(TimeOnly.MinValue),
        TimeOnly t => t.ToTimeSpan(),
        char c => c.ToString(),
        _ => value
    };

    /// <summary>Valor lido do banco → tipo da propriedade.</summary>
    public static object? FromDb(object? value, Type target)
    {
        var underlying = Nullable.GetUnderlyingType(target);
        var t = underlying ?? target;

        if (value is null or DBNull)
            return t.IsValueType && underlying is null ? Activator.CreateInstance(t) : null;

        if (t.IsInstanceOfType(value)) return value;

        if (t.IsEnum)
            return value is string s ? Enum.Parse(t, s, true)
                                     : Enum.ToObject(t, Convert.ChangeType(value, Enum.GetUnderlyingType(t), CultureInfo.InvariantCulture));

        if (t == typeof(Guid))
            return value switch { string gs => Guid.Parse(gs), byte[] gb => new Guid(gb), _ => throw Fail(value, t) };

        if (t == typeof(bool))
            return value is string bs ? bs == "1" || bs.Equals("true", StringComparison.OrdinalIgnoreCase)
                                      : Convert.ToBoolean(value, CultureInfo.InvariantCulture);

        if (t == typeof(DateOnly))
            return value switch
            {
                DateTime dt => DateOnly.FromDateTime(dt),
                DateTimeOffset dto => DateOnly.FromDateTime(dto.DateTime),
                string ds => DateOnly.Parse(ds, CultureInfo.InvariantCulture),
                _ => throw Fail(value, t)
            };

        if (t == typeof(TimeOnly))
            return value switch
            {
                TimeSpan ts => TimeOnly.FromTimeSpan(ts),
                DateTime dt => TimeOnly.FromDateTime(dt),
                string ts2 => TimeOnly.Parse(ts2, CultureInfo.InvariantCulture),
                _ => throw Fail(value, t)
            };

        if (t == typeof(DateTimeOffset) && value is DateTime d2) return new DateTimeOffset(d2);
        if (t == typeof(string)) return Convert.ToString(value, CultureInfo.InvariantCulture);
        if (t == typeof(char) && value is string cs && cs.Length > 0) return cs[0];

        try { return Convert.ChangeType(value, t, CultureInfo.InvariantCulture); }
        catch (Exception ex) when (ex is InvalidCastException or FormatException or OverflowException)
        {
            throw Fail(value, t);
        }
    }

    private static InvalidCastException Fail(object value, Type t) =>
        new($"Não foi possível converter {value.GetType().Name} para {t.Name}.");
}
