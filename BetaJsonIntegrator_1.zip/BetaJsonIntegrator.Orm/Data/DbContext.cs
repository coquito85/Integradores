using System.Data;
using System.Data.Common;
using System.Diagnostics;

namespace BetaJsonIntegrator.Orm;

/// <summary>Registro de um comando executado. Só nomes de parâmetros: valores (dados pessoais) nunca são expostos.</summary>
public sealed record SqlLogEntry(DatabaseKind Kind, string Sql, IReadOnlyList<string> ParameterNames, TimeSpan Duration);

/// <summary>
/// Sessão com um banco: abre a conexão sob demanda, executa SQL, mapeia entidades e controla transação.
/// Não é thread-safe: use uma instância por unidade de trabalho.
/// </summary>
public sealed class DbContext : IDisposable, IAsyncDisposable
{
    private readonly DbProviderFactory _factory;
    private DbConnection? _connection;
    internal DbTransaction? ActiveTransaction { get; private set; }

    public ConnectionProfile Profile { get; }
    public ISqlDialect Dialect { get; }
    public int CommandTimeoutSeconds { get; set; }

    /// <summary>Disparado depois de cada comando (para log técnico).</summary>
    public event Action<SqlLogEntry>? CommandExecuted;

    public DbContext(ConnectionProfile profile, DbProviderFactory? factory = null)
    {
        Profile = profile ?? throw new ArgumentNullException(nameof(profile));
        Dialect = SqlDialects.For(profile.Kind);
        _factory = factory ?? ProviderRegistry.Get(profile.Kind);
        CommandTimeoutSeconds = profile.CommandTimeoutSeconds;
    }

    // ---------- Conexão ----------

    private DbConnection EnsureConnection()
    {
        if (_connection is null)
        {
            _connection = _factory.CreateConnection() ?? throw new InvalidOperationException("O provedor não criou a conexão.");
            _connection.ConnectionString = Profile.BuildConnectionString();
        }
        return _connection;
    }

    public DbConnection Connection
    {
        get
        {
            var c = EnsureConnection();
            if (c.State != ConnectionState.Open) c.Open();
            return c;
        }
    }

    public void Open() => _ = Connection;

    public async Task OpenAsync(CancellationToken ct = default)
    {
        var c = EnsureConnection();
        if (c.State != ConnectionState.Open) await c.OpenAsync(ct).ConfigureAwait(false);
    }

    public void Close()
    {
        if (_connection is { State: not ConnectionState.Closed }) _connection.Close();
    }

    /// <summary>Testa a conexão com um SELECT simples.</summary>
    public void TestConnection() => ExecuteScalar<object>("SELECT 1");

    // ---------- Transação ----------

    public DbTransactionScope BeginTransaction(IsolationLevel isolation = IsolationLevel.Unspecified)
    {
        if (ActiveTransaction is not null) throw new InvalidOperationException("Já existe uma transação ativa neste contexto.");
        ActiveTransaction = Connection.BeginTransaction(isolation);
        return new DbTransactionScope(this, ActiveTransaction);
    }

    internal void ClearTransaction() => ActiveTransaction = null;

    // ---------- SQL cru ----------

    private (DbCommand Command, IReadOnlyList<string> Names) Prepare(string sql, object? parameters)
    {
        var cmd = Connection.CreateCommand();
        cmd.CommandText = sql;
        cmd.CommandTimeout = CommandTimeoutSeconds;
        cmd.Transaction = ActiveTransaction;
        var names = ParameterBinder.Bind(cmd, parameters, Dialect);
        return (cmd, names);
    }

    private T Run<T>(string sql, object? parameters, Func<DbCommand, T> execute)
    {
        var (cmd, names) = Prepare(sql, parameters);
        using (cmd)
        {
            var sw = Stopwatch.StartNew();
            try { return execute(cmd); }
            finally { CommandExecuted?.Invoke(new SqlLogEntry(Dialect.Kind, sql, names, sw.Elapsed)); }
        }
    }

    private async Task<T> RunAsync<T>(string sql, object? parameters, Func<DbCommand, Task<T>> execute)
    {
        await OpenAsync().ConfigureAwait(false);
        var (cmd, names) = Prepare(sql, parameters);
        await using (cmd.ConfigureAwait(false))
        {
            var sw = Stopwatch.StartNew();
            try { return await execute(cmd).ConfigureAwait(false); }
            finally { CommandExecuted?.Invoke(new SqlLogEntry(Dialect.Kind, sql, names, sw.Elapsed)); }
        }
    }

    public int Execute(string sql, object? parameters = null) => Run(sql, parameters, c => c.ExecuteNonQuery());

    public Task<int> ExecuteAsync(string sql, object? parameters = null, CancellationToken ct = default) =>
        RunAsync(sql, parameters, c => c.ExecuteNonQueryAsync(ct));

    public T? ExecuteScalar<T>(string sql, object? parameters = null) =>
        (T?)ValueConverter.FromDb(Run(sql, parameters, c => c.ExecuteScalar()), typeof(T));

    public async Task<T?> ExecuteScalarAsync<T>(string sql, object? parameters = null, CancellationToken ct = default) =>
        (T?)ValueConverter.FromDb(await RunAsync(sql, parameters, c => c.ExecuteScalarAsync(ct)).ConfigureAwait(false), typeof(T));

    public DataTable QueryTable(string sql, object? parameters = null) =>
        Run(sql, parameters, c =>
        {
            using var reader = c.ExecuteReader();
            var table = new DataTable();
            table.Load(reader);
            return table;
        });

    public Task<DataTable> QueryTableAsync(string sql, object? parameters = null, CancellationToken ct = default) =>
        RunAsync(sql, parameters, async c =>
        {
            await using var reader = await c.ExecuteReaderAsync(ct).ConfigureAwait(false);
            var table = new DataTable();
            table.Load(reader);
            return table;
        });

    public List<T> Query<T>(string sql, object? parameters = null) where T : class, new() =>
        Run(sql, parameters, c =>
        {
            using var reader = c.ExecuteReader();
            return EntityMaterializer.ReadAll<T>(reader);
        });

    public Task<List<T>> QueryAsync<T>(string sql, object? parameters = null, CancellationToken ct = default) where T : class, new() =>
        RunAsync(sql, parameters, async c =>
        {
            await using var reader = await c.ExecuteReaderAsync(ct).ConfigureAwait(false);
            return await EntityMaterializer.ReadAllAsync<T>(reader, ct).ConfigureAwait(false);
        });

    /// <summary>Nomes das colunas de uma tabela (consulta vazia, portável entre bancos).</summary>
    public IReadOnlyList<string> GetColumnNames(string table)
    {
        SqlIdentifier.EnsureValidTable(table);
        var parts = table.Split('.');
        var quoted = parts.Length == 2 ? Dialect.QuoteTable(parts[0], parts[1]) : Dialect.QuoteTable(null, parts[0]);

        return Run(Dialect.BuildEmptySelect(quoted), null, c =>
        {
            using var reader = c.ExecuteReader(CommandBehavior.SchemaOnly);
            var names = new List<string>(reader.FieldCount);
            for (var i = 0; i < reader.FieldCount; i++) names.Add(reader.GetName(i));
            return (IReadOnlyList<string>)names;
        });
    }

    // ---------- Entidades ----------

    public QueryBuilder<T> Set<T>() where T : class, new() => new(this);

    public T? Find<T>(params object?[] keyValues) where T : class, new()
    {
        var (sql, args) = SqlGenerator.SelectByKeys(EntityMap.For<T>(), Dialect, keyValues);
        return Query<T>(sql, args).FirstOrDefault();
    }

    public async Task<T?> FindAsync<T>(object?[] keyValues, CancellationToken ct = default) where T : class, new()
    {
        var (sql, args) = SqlGenerator.SelectByKeys(EntityMap.For<T>(), Dialect, keyValues);
        return (await QueryAsync<T>(sql, args, ct).ConfigureAwait(false)).FirstOrDefault();
    }

    /// <summary>Insere e, se a chave é auto-incremento, preenche o id gerado na entidade e o devolve.</summary>
    public object? Insert<T>(T entity) where T : class
    {
        var map = EntityMap.For<T>();
        var (sql, args, identity) = SqlGenerator.Insert(map, Dialect, entity);

        if (identity is null) { Execute(sql, args); return null; }

        object? id;
        if (Dialect.LastInsertIdQuery is { } lastId)
        {
            Execute(sql, args);
            id = ExecuteScalar<object>(lastId);
        }
        else
        {
            id = ExecuteScalar<object>(sql, args);
        }

        identity.SetValue(entity, ValueConverter.FromDb(id, identity.ClrType));
        return identity.GetValue(entity);
    }

    public async Task<object?> InsertAsync<T>(T entity, CancellationToken ct = default) where T : class
    {
        var map = EntityMap.For<T>();
        var (sql, args, identity) = SqlGenerator.Insert(map, Dialect, entity);

        if (identity is null) { await ExecuteAsync(sql, args, ct).ConfigureAwait(false); return null; }

        object? id;
        if (Dialect.LastInsertIdQuery is { } lastId)
        {
            await ExecuteAsync(sql, args, ct).ConfigureAwait(false);
            id = await ExecuteScalarAsync<object>(lastId, null, ct).ConfigureAwait(false);
        }
        else
        {
            id = await ExecuteScalarAsync<object>(sql, args, ct).ConfigureAwait(false);
        }

        identity.SetValue(entity, ValueConverter.FromDb(id, identity.ClrType));
        return identity.GetValue(entity);
    }

    /// <summary>Insere vários dentro de uma transação (reaproveita a transação ativa, se houver).</summary>
    public void InsertRange<T>(IEnumerable<T> entities) where T : class
    {
        var own = ActiveTransaction is null ? BeginTransaction() : null;
        try
        {
            foreach (var e in entities) Insert(e);
            own?.Commit();
        }
        finally { own?.Dispose(); }
    }

    public int Update<T>(T entity) where T : class
    {
        var (sql, args) = SqlGenerator.Update(EntityMap.For<T>(), Dialect, entity);
        return Execute(sql, args);
    }

    public Task<int> UpdateAsync<T>(T entity, CancellationToken ct = default) where T : class
    {
        var (sql, args) = SqlGenerator.Update(EntityMap.For<T>(), Dialect, entity);
        return ExecuteAsync(sql, args, ct);
    }

    public int Delete<T>(T entity) where T : class
    {
        var map = EntityMap.For<T>();
        return DeleteByKey<T>(SqlGenerator.KeyValues(map, entity));
    }

    public int DeleteByKey<T>(params object?[] keyValues) where T : class
    {
        var (sql, args) = SqlGenerator.DeleteByKeys(EntityMap.For<T>(), Dialect, keyValues);
        return Execute(sql, args);
    }

    public Task<int> DeleteAsync<T>(T entity, CancellationToken ct = default) where T : class
    {
        var map = EntityMap.For<T>();
        var (sql, args) = SqlGenerator.DeleteByKeys(map, Dialect, SqlGenerator.KeyValues(map, entity));
        return ExecuteAsync(sql, args, ct);
    }

    // ---------- Descarte ----------

    public void Dispose()
    {
        ActiveTransaction?.Dispose();
        ActiveTransaction = null;
        _connection?.Dispose();
        _connection = null;
    }

    public async ValueTask DisposeAsync()
    {
        if (ActiveTransaction is not null) await ActiveTransaction.DisposeAsync().ConfigureAwait(false);
        ActiveTransaction = null;
        if (_connection is not null) await _connection.DisposeAsync().ConfigureAwait(false);
        _connection = null;
    }
}

/// <summary>Transação com rollback automático se não houver Commit.</summary>
public sealed class DbTransactionScope : IDisposable
{
    private readonly DbContext _context;
    private readonly DbTransaction _transaction;
    private bool _done;

    internal DbTransactionScope(DbContext context, DbTransaction transaction)
    {
        _context = context;
        _transaction = transaction;
    }

    public void Commit()
    {
        if (_done) return;
        _transaction.Commit();
        Finish();
    }

    public void Rollback()
    {
        if (_done) return;
        _transaction.Rollback();
        Finish();
    }

    public void Dispose()
    {
        if (!_done)
        {
            try { _transaction.Rollback(); } catch { /* conexão pode já ter caído */ }
            Finish();
        }
        _transaction.Dispose();
    }

    private void Finish()
    {
        _done = true;
        _context.ClearTransaction();
    }
}
