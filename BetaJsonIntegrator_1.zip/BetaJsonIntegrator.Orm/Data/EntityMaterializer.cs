using System.Data.Common;

namespace BetaJsonIntegrator.Orm;

/// <summary>Cria entidades a partir de um DbDataReader casando colunas por nome.</summary>
internal static class EntityMaterializer
{
    public static List<T> ReadAll<T>(DbDataReader reader) where T : class, new()
    {
        var map = EntityMap.For<T>();
        var bindings = BuildBindings(reader, map);
        var list = new List<T>();
        while (reader.Read()) list.Add(ReadRow<T>(reader, bindings));
        return list;
    }

    public static async Task<List<T>> ReadAllAsync<T>(DbDataReader reader, CancellationToken ct) where T : class, new()
    {
        var map = EntityMap.For<T>();
        var bindings = BuildBindings(reader, map);
        var list = new List<T>();
        while (await reader.ReadAsync(ct).ConfigureAwait(false)) list.Add(ReadRow<T>(reader, bindings));
        return list;
    }

    private static PropertyMap?[] BuildBindings(DbDataReader reader, EntityMap map)
    {
        var result = new PropertyMap?[reader.FieldCount];
        for (var i = 0; i < reader.FieldCount; i++)
        {
            var name = reader.GetName(i);
            result[i] = map.Properties.FirstOrDefault(p => p.Property.Name.Equals(name, StringComparison.OrdinalIgnoreCase))
                        ?? map.Properties.FirstOrDefault(p => p.ColumnName.Equals(name, StringComparison.OrdinalIgnoreCase))
                        ?? map.Properties.FirstOrDefault(p => Normalize(p.Property.Name) == Normalize(name));
        }
        return result;
    }

    private static T ReadRow<T>(DbDataReader reader, PropertyMap?[] bindings) where T : class, new()
    {
        var entity = new T();
        for (var i = 0; i < bindings.Length; i++)
        {
            var b = bindings[i];
            if (b is null) continue;
            b.SetValue(entity, ValueConverter.FromDb(reader.IsDBNull(i) ? null : reader.GetValue(i), b.ClrType));
        }
        return entity;
    }

    /// <summary>nome_cliente, NomeCliente e NOMECLIENTE casam entre si.</summary>
    private static string Normalize(string s) => s.Replace("_", "").ToLowerInvariant();
}
