using System.Collections;
using System.Data.Common;
using System.Reflection;

namespace BetaJsonIntegrator.Orm;

/// <summary>Converte "new { id = 1 }" ou IDictionary em parâmetros do comando.</summary>
internal static class ParameterBinder
{
    public static IReadOnlyList<string> Bind(DbCommand command, object? parameters, ISqlDialect dialect)
    {
        var names = new List<string>();
        if (parameters is null) return names;

        foreach (var (name, value) in Enumerate(parameters))
        {
            var clean = name.TrimStart('@', ':', '?');
            var p = command.CreateParameter();
            p.ParameterName = dialect.ParameterPrefix + clean;
            p.Value = ValueConverter.ToDb(value);
            command.Parameters.Add(p);
            names.Add(clean);
        }
        return names;
    }

    private static IEnumerable<(string, object?)> Enumerate(object parameters)
    {
        if (parameters is IDictionary<string, object?> dict)
        {
            foreach (var kv in dict) yield return (kv.Key, kv.Value);
            yield break;
        }

        if (parameters is IDictionary legacy)
        {
            foreach (DictionaryEntry kv in legacy) yield return (kv.Key.ToString()!, kv.Value);
            yield break;
        }

        foreach (var prop in parameters.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance))
            if (prop.GetIndexParameters().Length == 0)
                yield return (prop.Name, prop.GetValue(parameters));
    }
}
