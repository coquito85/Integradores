namespace BetaJsonIntegrator.Orm;

/// <summary>Cria DbContext por nome de perfil a partir do JSON de conexões (multi-bancos).</summary>
public sealed class DbContextFactory
{
    private readonly ConnectionSettings _settings;

    public DbContextFactory(ConnectionSettings settings) => _settings = settings;

    public static DbContextFactory FromFile(string path, SecretSource secret, bool allowPlainText = false) =>
        new(ConnectionStore.Load(path, secret, allowPlainText));

    public IReadOnlyList<ConnectionProfile> Profiles => _settings.Profiles;
    public string? DefaultProfile => _settings.DefaultProfile;

    public DbContext Create(string? profileName = null) => new(_settings.Get(profileName));
}
