namespace BetaJsonIntegrator.Orm;

/// <summary>Nome da tabela (e schema opcional). Sem o atributo, vale o nome da classe.</summary>
[AttributeUsage(AttributeTargets.Class, Inherited = false)]
public sealed class TableAttribute : Attribute
{
    public string Name { get; }
    public string? Schema { get; set; }
    public TableAttribute(string name) => Name = name;
}

/// <summary>Nome da coluna. Sem o atributo, vale o nome da propriedade.</summary>
[AttributeUsage(AttributeTargets.Property)]
public sealed class ColumnAttribute : Attribute
{
    public string Name { get; }
    public ColumnAttribute(string name) => Name = name;
}

/// <summary>
/// Chave primária. Várias propriedades com [Key] formam chave composta.
/// AutoIncrement só vale para chave simples numérica.
/// </summary>
[AttributeUsage(AttributeTargets.Property)]
public sealed class KeyAttribute : Attribute
{
    public bool AutoIncrement { get; set; } = true;
}

/// <summary>Propriedade ignorada pelo ORM.</summary>
[AttributeUsage(AttributeTargets.Property)]
public sealed class NotMappedAttribute : Attribute { }
