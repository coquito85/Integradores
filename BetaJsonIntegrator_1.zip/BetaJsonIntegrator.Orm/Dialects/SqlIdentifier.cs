using System.Text.RegularExpressions;

namespace BetaJsonIntegrator.Orm;

/// <summary>
/// Validação de nomes de tabela/coluna que vêm de configuração (XML etc.).
/// Identificadores nunca são parâmetros SQL, por isso só passam se forem "seguros".
/// </summary>
public static class SqlIdentifier
{
    private static readonly Regex Part = new(@"^[\p{L}_][\p{L}\p{N}_$]*$", RegexOptions.Compiled);

    public static bool IsValidPart(string? name) => !string.IsNullOrWhiteSpace(name) && name.Length <= 128 && Part.IsMatch(name);

    /// <summary>Aceita "tabela" ou "schema.tabela".</summary>
    public static bool IsValidTableName(string? name)
    {
        if (string.IsNullOrWhiteSpace(name)) return false;
        var parts = name.Split('.');
        return parts.Length is 1 or 2 && parts.All(IsValidPart);
    }

    public static void EnsureValidPart(string? name, string what)
    {
        if (!IsValidPart(name))
            throw new ArgumentException($"{what} inválido: '{name}'. Use apenas letras, números, '_' e '$'.");
    }

    public static void EnsureValidTable(string? name)
    {
        if (!IsValidTableName(name))
            throw new ArgumentException($"Nome de tabela inválido: '{name}'.");
    }
}
