namespace BetaJsonIntegrator.Orm;

public enum DatabaseKind
{
    MySql,
    MariaDb,
    SqlServer,
    PostgreSql,
    Sqlite
}
