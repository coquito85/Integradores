namespace BetaJsonIntegrator.Orm;

/// <summary>Diferenças de SQL entre bancos: aspas, paginação, retorno de identidade, LIKE.</summary>
public interface ISqlDialect
{
    DatabaseKind Kind { get; }

    /// <summary>Prefixo usado nos parâmetros ("@" em todos os provedores suportados).</summary>
    string ParameterPrefix { get; }

    string QuoteIdentifier(string identifier);
    string QuoteTable(string? schema, string table);

    /// <summary>Acrescenta paginação a um SELECT já montado (com ou sem ORDER BY).</summary>
    string ApplyPaging(string selectSql, bool hasOrderBy, int? skip, int? take);

    /// <summary>
    /// INSERT. Quando <paramref name="quotedIdentityColumn"/> não é nulo e o banco suporta retorno
    /// inline (SQL Server: OUTPUT, PostgreSQL: RETURNING), o SQL devolve o id como escalar.
    /// </summary>
    string BuildInsert(string quotedTable, IReadOnlyList<string> quotedColumns, IReadOnlyList<string> parameterNames, string? quotedIdentityColumn);

    /// <summary>Consulta separada para obter o último id (MySQL/SQLite). Nulo quando o INSERT já devolve o id.</summary>
    string? LastInsertIdQuery { get; }

    /// <summary>Escapa curingas de LIKE; a cláusula ESCAPE usada é sempre '!'.</summary>
    string EscapeLike(string value);

    /// <summary>SELECT que não retorna linhas, usado para descobrir as colunas de uma tabela.</summary>
    string BuildEmptySelect(string quotedTable);
}
