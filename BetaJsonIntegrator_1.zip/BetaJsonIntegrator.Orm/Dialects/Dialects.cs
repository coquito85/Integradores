namespace BetaJsonIntegrator.Orm;

public sealed class MySqlDialect : SqlDialectBase
{
    private readonly DatabaseKind _kind;
    public MySqlDialect(DatabaseKind kind = DatabaseKind.MySql) => _kind = kind;

    public override DatabaseKind Kind => _kind;
    public override string? LastInsertIdQuery => "SELECT LAST_INSERT_ID()";
    protected override string DefaultValuesClause => "VALUES ()";

    public override string QuoteIdentifier(string identifier) => "`" + identifier.Replace("`", "``") + "`";

    public override string ApplyPaging(string selectSql, bool hasOrderBy, int? skip, int? take)
    {
        if (skip is null && take is null) return selectSql;
        if (take is null) return $"{selectSql} LIMIT 18446744073709551615 OFFSET {skip}";
        return skip is null ? $"{selectSql} LIMIT {take}" : $"{selectSql} LIMIT {take} OFFSET {skip}";
    }
}

public sealed class SqlServerDialect : SqlDialectBase
{
    public override DatabaseKind Kind => DatabaseKind.SqlServer;

    public override string QuoteIdentifier(string identifier) => "[" + identifier.Replace("]", "]]") + "]";

    protected override string InsertOutputClause(string quotedIdentityColumn) => $" OUTPUT INSERTED.{quotedIdentityColumn}";

    public override string ApplyPaging(string selectSql, bool hasOrderBy, int? skip, int? take)
    {
        if (skip is null && take is null) return selectSql;
        // OFFSET/FETCH exige ORDER BY
        var sql = hasOrderBy ? selectSql : selectSql + " ORDER BY (SELECT NULL)";
        sql += $" OFFSET {skip ?? 0} ROWS";
        if (take is not null) sql += $" FETCH NEXT {take} ROWS ONLY";
        return sql;
    }

    public override string EscapeLike(string value) => base.EscapeLike(value).Replace("[", "![");
}

public sealed class PostgreSqlDialect : SqlDialectBase
{
    public override DatabaseKind Kind => DatabaseKind.PostgreSql;

    public override string QuoteIdentifier(string identifier) => "\"" + identifier.Replace("\"", "\"\"") + "\"";

    protected override string InsertReturningClause(string quotedIdentityColumn) => $" RETURNING {quotedIdentityColumn}";

    public override string ApplyPaging(string selectSql, bool hasOrderBy, int? skip, int? take)
    {
        var sql = selectSql;
        if (take is not null) sql += $" LIMIT {take}";
        if (skip is not null) sql += $" OFFSET {skip}";
        return sql;
    }
}

public sealed class SqliteDialect : SqlDialectBase
{
    public override DatabaseKind Kind => DatabaseKind.Sqlite;
    public override string? LastInsertIdQuery => "SELECT last_insert_rowid()";

    public override string QuoteIdentifier(string identifier) => "\"" + identifier.Replace("\"", "\"\"") + "\"";

    public override string ApplyPaging(string selectSql, bool hasOrderBy, int? skip, int? take)
    {
        if (skip is null && take is null) return selectSql;
        var sql = $"{selectSql} LIMIT {take ?? -1}";
        if (skip is not null) sql += $" OFFSET {skip}";
        return sql;
    }
}

public static class SqlDialects
{
    public static ISqlDialect For(DatabaseKind kind) => kind switch
    {
        DatabaseKind.MySql => new MySqlDialect(DatabaseKind.MySql),
        DatabaseKind.MariaDb => new MySqlDialect(DatabaseKind.MariaDb),
        DatabaseKind.SqlServer => new SqlServerDialect(),
        DatabaseKind.PostgreSql => new PostgreSqlDialect(),
        DatabaseKind.Sqlite => new SqliteDialect(),
        _ => throw new NotSupportedException($"Banco não suportado: {kind}")
    };
}
