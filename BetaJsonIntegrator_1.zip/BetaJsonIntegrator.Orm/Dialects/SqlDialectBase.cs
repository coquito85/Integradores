namespace BetaJsonIntegrator.Orm;

public abstract class SqlDialectBase : ISqlDialect
{
    public abstract DatabaseKind Kind { get; }
    public virtual string ParameterPrefix => "@";
    public virtual string? LastInsertIdQuery => null;

    public abstract string QuoteIdentifier(string identifier);

    public virtual string QuoteTable(string? schema, string table) =>
        string.IsNullOrEmpty(schema) ? QuoteIdentifier(table) : $"{QuoteIdentifier(schema)}.{QuoteIdentifier(table)}";

    public abstract string ApplyPaging(string selectSql, bool hasOrderBy, int? skip, int? take);

    protected virtual string InsertOutputClause(string quotedIdentityColumn) => "";
    protected virtual string InsertReturningClause(string quotedIdentityColumn) => "";
    protected virtual string DefaultValuesClause => "DEFAULT VALUES";

    public string BuildInsert(string quotedTable, IReadOnlyList<string> quotedColumns, IReadOnlyList<string> parameterNames, string? quotedIdentityColumn)
    {
        var output = quotedIdentityColumn is null ? "" : InsertOutputClause(quotedIdentityColumn);
        var returning = quotedIdentityColumn is null ? "" : InsertReturningClause(quotedIdentityColumn);

        if (quotedColumns.Count == 0)
            return $"INSERT INTO {quotedTable}{output} {DefaultValuesClause}{returning}";

        var cols = string.Join(", ", quotedColumns);
        var vals = string.Join(", ", parameterNames.Select(n => ParameterPrefix + n));
        return $"INSERT INTO {quotedTable} ({cols}){output} VALUES ({vals}){returning}";
    }

    public virtual string EscapeLike(string value) =>
        value.Replace("!", "!!").Replace("%", "!%").Replace("_", "!_");

    public virtual string BuildEmptySelect(string quotedTable) => $"SELECT * FROM {quotedTable} WHERE 1 = 0";
}
