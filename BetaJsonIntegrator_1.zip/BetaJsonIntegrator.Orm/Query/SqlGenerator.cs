namespace BetaJsonIntegrator.Orm;

/// <summary>SQL de CRUD por entidade.</summary>
internal static class SqlGenerator
{
    public static string Table(EntityMap map, ISqlDialect d) => d.QuoteTable(map.Schema, map.TableName);

    public static string SelectColumns(EntityMap map, ISqlDialect d) =>
        string.Join(", ", map.Properties.Select(p =>
            p.ColumnName == p.Property.Name
                ? d.QuoteIdentifier(p.ColumnName)
                : $"{d.QuoteIdentifier(p.ColumnName)} AS {d.QuoteIdentifier(p.Property.Name)}"));

    public static (string Sql, Dictionary<string, object?> Args, PropertyMap? Identity) Insert(EntityMap map, ISqlDialect d, object entity)
    {
        var args = new Dictionary<string, object?>();
        var cols = new List<string>();
        var names = new List<string>();
        var identity = map.Identity;
        var skipIdentity = identity is not null && IsDefault(identity.GetValue(entity), identity.ClrType);

        foreach (var p in map.Properties)
        {
            if (skipIdentity && p == identity) continue;
            cols.Add(d.QuoteIdentifier(p.ColumnName));
            var n = "p" + names.Count;
            names.Add(n);
            args[n] = p.GetValue(entity);
        }

        var sql = d.BuildInsert(Table(map, d), cols, names, skipIdentity ? d.QuoteIdentifier(identity!.ColumnName) : null);
        return (sql, args, skipIdentity ? identity : null);
    }

    public static (string Sql, Dictionary<string, object?> Args) Update(EntityMap map, ISqlDialect d, object entity)
    {
        RequireKeys(map, "Update");
        var sets = map.Properties.Where(p => !p.IsKey).ToList();
        if (sets.Count == 0) throw new InvalidOperationException($"{map.EntityType.Name} não tem colunas além da chave para atualizar.");

        var args = new Dictionary<string, object?>();
        var i = 0;
        var setSql = string.Join(", ", sets.Select(p =>
        {
            var n = "p" + i++;
            args[n] = p.GetValue(entity);
            return $"{d.QuoteIdentifier(p.ColumnName)} = {d.ParameterPrefix}{n}";
        }));

        var where = KeyWhere(map, d, args, ref i, k => k.GetValue(entity));
        return ($"UPDATE {Table(map, d)} SET {setSql} WHERE {where}", args);
    }

    public static (string Sql, Dictionary<string, object?> Args) DeleteByKeys(EntityMap map, ISqlDialect d, object?[] keyValues)
    {
        RequireKeys(map, "Delete");
        if (keyValues.Length != map.Keys.Count)
            throw new ArgumentException($"{map.EntityType.Name} tem {map.Keys.Count} coluna(s) de chave; recebidas {keyValues.Length}.");

        var args = new Dictionary<string, object?>();
        var i = 0;
        var where = KeyWhere(map, d, args, ref i, k => keyValues[map.Keys.ToList().IndexOf(k)]);
        return ($"DELETE FROM {Table(map, d)} WHERE {where}", args);
    }

    public static (string Sql, Dictionary<string, object?> Args) SelectByKeys(EntityMap map, ISqlDialect d, object?[] keyValues)
    {
        RequireKeys(map, "Find");
        if (keyValues.Length != map.Keys.Count)
            throw new ArgumentException($"{map.EntityType.Name} tem {map.Keys.Count} coluna(s) de chave; recebidas {keyValues.Length}.");

        var args = new Dictionary<string, object?>();
        var i = 0;
        var where = KeyWhere(map, d, args, ref i, k => keyValues[map.Keys.ToList().IndexOf(k)]);
        var select = $"SELECT {SelectColumns(map, d)} FROM {Table(map, d)} WHERE {where}";
        return (d.ApplyPaging(select, false, null, 1), args);
    }

    public static object?[] KeyValues(EntityMap map, object entity) => map.Keys.Select(k => k.GetValue(entity)).ToArray();

    private static string KeyWhere(EntityMap map, ISqlDialect d, Dictionary<string, object?> args, ref int counter, Func<PropertyMap, object?> value)
    {
        var parts = new List<string>();
        foreach (var k in map.Keys)
        {
            var n = "p" + counter++;
            args[n] = value(k);
            parts.Add($"{d.QuoteIdentifier(k.ColumnName)} = {d.ParameterPrefix}{n}");
        }
        return string.Join(" AND ", parts);
    }

    private static void RequireKeys(EntityMap map, string op)
    {
        if (map.Keys.Count == 0)
            throw new InvalidOperationException($"{op} exige chave primária: marque uma propriedade de {map.EntityType.Name} com [Key].");
    }

    private static bool IsDefault(object? value, Type type)
    {
        if (value is null) return true;
        var t = Nullable.GetUnderlyingType(type) ?? type;
        return t.IsValueType && value.Equals(Activator.CreateInstance(t));
    }
}
