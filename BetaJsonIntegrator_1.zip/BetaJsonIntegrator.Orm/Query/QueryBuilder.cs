using System.Linq.Expressions;

namespace BetaJsonIntegrator.Orm;

public sealed record SqlStatement(string Sql, IReadOnlyDictionary<string, object?> Parameters);

/// <summary>Consulta fluente tipada: Where/OrderBy/Skip/Take e execução.</summary>
public sealed class QueryBuilder<T> where T : class, new()
{
    private readonly DbContext _context;
    private readonly EntityMap _map = EntityMap.For<T>();
    private readonly List<string> _where = new();
    private readonly List<string> _order = new();
    private readonly Dictionary<string, object?> _args = new();
    private int _counter;
    private int? _skip;
    private int? _take;

    internal QueryBuilder(DbContext context) => _context = context;

    private ISqlDialect Dialect => _context.Dialect;

    public QueryBuilder<T> Where(Expression<Func<T, bool>> predicate)
    {
        var translator = new ExpressionTranslator(_map, Dialect, _args, predicate.Parameters[0], () => "__p" + _counter++);
        _where.Add(translator.Translate(predicate.Body));
        return this;
    }

    /// <summary>Filtro em SQL puro; valores sempre por parâmetro (use nomes que não comecem com "__p").</summary>
    public QueryBuilder<T> WhereRaw(string sqlCondition, object? parameters = null)
    {
        if (string.IsNullOrWhiteSpace(sqlCondition)) throw new ArgumentException("Condição vazia.", nameof(sqlCondition));
        _where.Add($"({sqlCondition})");
        if (parameters is not null)
            foreach (var (k, v) in ParameterBag(parameters)) _args[k] = v;
        return this;
    }

    public QueryBuilder<T> OrderBy<TKey>(Expression<Func<T, TKey>> key) => AddOrder(key, false);
    public QueryBuilder<T> OrderByDescending<TKey>(Expression<Func<T, TKey>> key) => AddOrder(key, true);
    public QueryBuilder<T> Skip(int count) { _skip = count; return this; }
    public QueryBuilder<T> Take(int count) { _take = count; return this; }

    public SqlStatement ToSql() => Build(SqlGenerator.SelectColumns(_map, Dialect), true, _skip, _take);

    public List<T> ToList()
    {
        var s = ToSql();
        return _context.Query<T>(s.Sql, s.Parameters);
    }

    public Task<List<T>> ToListAsync(CancellationToken ct = default)
    {
        var s = ToSql();
        return _context.QueryAsync<T>(s.Sql, s.Parameters, ct);
    }

    public T? FirstOrDefault()
    {
        var s = Build(SqlGenerator.SelectColumns(_map, Dialect), true, _skip, 1);
        return _context.Query<T>(s.Sql, s.Parameters).FirstOrDefault();
    }

    public async Task<T?> FirstOrDefaultAsync(CancellationToken ct = default)
    {
        var s = Build(SqlGenerator.SelectColumns(_map, Dialect), true, _skip, 1);
        return (await _context.QueryAsync<T>(s.Sql, s.Parameters, ct).ConfigureAwait(false)).FirstOrDefault();
    }

    public long Count()
    {
        var s = Build("COUNT(*)", false, null, null);
        return _context.ExecuteScalar<long>(s.Sql, s.Parameters);
    }

    public async Task<long> CountAsync(CancellationToken ct = default)
    {
        var s = Build("COUNT(*)", false, null, null);
        return await _context.ExecuteScalarAsync<long>(s.Sql, s.Parameters, ct).ConfigureAwait(false);
    }

    public bool Any() => Count() > 0;

    private QueryBuilder<T> AddOrder<TKey>(Expression<Func<T, TKey>> key, bool desc)
    {
        var body = key.Body;
        while (body is UnaryExpression { NodeType: ExpressionType.Convert or ExpressionType.ConvertChecked } u) body = u.Operand;
        if (body is not MemberExpression m || m.Expression != key.Parameters[0])
            throw new NotSupportedException("OrderBy aceita apenas uma propriedade da entidade.");

        var col = Dialect.QuoteIdentifier(_map.GetByProperty(m.Member.Name).ColumnName);
        _order.Add(desc ? col + " DESC" : col);
        return this;
    }

    private SqlStatement Build(string selectList, bool withOrder, int? skip, int? take)
    {
        var sql = $"SELECT {selectList} FROM {SqlGenerator.Table(_map, Dialect)}";
        if (_where.Count > 0) sql += " WHERE " + string.Join(" AND ", _where);

        var hasOrder = withOrder && _order.Count > 0;
        if (hasOrder) sql += " ORDER BY " + string.Join(", ", _order);

        if (withOrder) sql = Dialect.ApplyPaging(sql, hasOrder, skip, take);
        return new SqlStatement(sql, new Dictionary<string, object?>(_args));
    }

    private static IEnumerable<KeyValuePair<string, object?>> ParameterBag(object parameters)
    {
        if (parameters is IDictionary<string, object?> d) return d;
        return parameters.GetType().GetProperties().Select(p => new KeyValuePair<string, object?>(p.Name, p.GetValue(parameters)));
    }
}
