using System.Collections;
using System.Linq.Expressions;

namespace BetaJsonIntegrator.Orm;

/// <summary>
/// Traduz predicados C# (x =&gt; x.Nome == "A" &amp;&amp; ids.Contains(x.Id)) em SQL parametrizado.
/// Valores nunca entram no texto SQL: sempre viram parâmetros.
/// </summary>
internal sealed class ExpressionTranslator
{
    private readonly EntityMap _map;
    private readonly ISqlDialect _dialect;
    private readonly Dictionary<string, object?> _args;
    private readonly ParameterExpression _root;
    private readonly Func<string> _nextName;

    public ExpressionTranslator(EntityMap map, ISqlDialect dialect, Dictionary<string, object?> args,
        ParameterExpression root, Func<string> nextName)
    {
        _map = map;
        _dialect = dialect;
        _args = args;
        _root = root;
        _nextName = nextName;
    }

    public string Translate(Expression body) => Visit(body);

    private string Visit(Expression e)
    {
        switch (e)
        {
            case BinaryExpression { NodeType: ExpressionType.AndAlso } b:
                return $"({Visit(b.Left)} AND {Visit(b.Right)})";
            case BinaryExpression { NodeType: ExpressionType.OrElse } b:
                return $"({Visit(b.Left)} OR {Visit(b.Right)})";
            case BinaryExpression b:
                return Comparison(b);
            case UnaryExpression { NodeType: ExpressionType.Not } u:
                return $"(NOT {Visit(u.Operand)})";
            case UnaryExpression { NodeType: ExpressionType.Convert or ExpressionType.ConvertChecked or ExpressionType.Quote } u:
                return Visit(u.Operand);
            case MemberExpression m when IsColumn(m):
                return $"{Column(m)} = {Param(true)}";
            case ConstantExpression { Value: bool flag }:
                return flag ? "1 = 1" : "1 = 0";
            case MethodCallExpression call:
                return Method(call);
            default:
                if (!ContainsRoot(e) && e.Type == typeof(bool))
                    return (bool)Evaluate(e)! ? "1 = 1" : "1 = 0";
                throw new NotSupportedException($"Expressão não suportada no filtro: {e}");
        }
    }

    private string Comparison(BinaryExpression b)
    {
        var op = b.NodeType switch
        {
            ExpressionType.Equal => "=",
            ExpressionType.NotEqual => "<>",
            ExpressionType.LessThan => "<",
            ExpressionType.LessThanOrEqual => "<=",
            ExpressionType.GreaterThan => ">",
            ExpressionType.GreaterThanOrEqual => ">=",
            _ => throw new NotSupportedException($"Operador não suportado: {b.NodeType}")
        };

        var leftCol = IsColumn(b.Left);
        var rightCol = IsColumn(b.Right);

        if (leftCol && rightCol) return $"{Column(b.Left)} {op} {Column(b.Right)}";

        if (!leftCol && !rightCol)
            throw new NotSupportedException($"A comparação precisa envolver uma propriedade da entidade: {b}");

        // Normaliza para "coluna op valor"
        var col = leftCol ? b.Left : b.Right;
        var valueExpr = leftCol ? b.Right : b.Left;
        if (!leftCol) op = Flip(op);

        var value = Evaluate(valueExpr);
        if (value is null)
        {
            return op switch
            {
                "=" => $"{Column(col)} IS NULL",
                "<>" => $"{Column(col)} IS NOT NULL",
                _ => throw new NotSupportedException("Comparação de ordem com null não é suportada.")
            };
        }

        return $"{Column(col)} {op} {Param(value)}";
    }

    private string Method(MethodCallExpression call)
    {
        // string.Contains / StartsWith / EndsWith
        if (call.Object is not null && call.Object.Type == typeof(string) && IsColumn(call.Object) && call.Arguments.Count == 1)
        {
            var text = (string?)Evaluate(call.Arguments[0]) ?? throw new NotSupportedException("Valor nulo em LIKE.");
            var escaped = _dialect.EscapeLike(text);
            var pattern = call.Method.Name switch
            {
                "Contains" => $"%{escaped}%",
                "StartsWith" => $"{escaped}%",
                "EndsWith" => $"%{escaped}",
                _ => throw new NotSupportedException($"Método string não suportado: {call.Method.Name}")
            };
            return $"{Column(call.Object)} LIKE {Param(pattern)} ESCAPE '!'";
        }

        // coleção.Contains(x.Coluna) -> IN (...)
        if (call.Method.Name == "Contains")
        {
            Expression? collection;
            Expression? item;
            if (call.Object is not null && call.Arguments.Count == 1) { collection = call.Object; item = call.Arguments[0]; }
            else if (call.Object is null && call.Arguments.Count == 2) { collection = call.Arguments[0]; item = call.Arguments[1]; }
            else throw new NotSupportedException($"Contains não suportado: {call}");

            // C# 14 pode embrulhar arrays em op_Implicit (span)
            if (collection is MethodCallExpression { Method.Name: "op_Implicit" } wrap && wrap.Arguments.Count == 1)
                collection = wrap.Arguments[0];

            if (IsColumn(item) && !ContainsRoot(collection) && Evaluate(collection) is IEnumerable values and not string)
            {
                var list = values.Cast<object?>().ToList();
                if (list.Count == 0) return "1 = 0";
                return $"{Column(item)} IN ({string.Join(", ", list.Select(Param))})";
            }
        }

        throw new NotSupportedException($"Chamada de método não suportada no filtro: {call}");
    }

    private string Param(object? value)
    {
        var name = _nextName();
        _args[name] = value;
        return _dialect.ParameterPrefix + name;
    }

    private string Column(Expression e)
    {
        var m = (MemberExpression)Unwrap(e);
        return _dialect.QuoteIdentifier(_map.GetByProperty(m.Member.Name).ColumnName);
    }

    private bool IsColumn(Expression e) =>
        Unwrap(e) is MemberExpression { Expression: ParameterExpression p } && p == _root;

    private static Expression Unwrap(Expression e)
    {
        while (e is UnaryExpression { NodeType: ExpressionType.Convert or ExpressionType.ConvertChecked } u) e = u.Operand;
        return e;
    }

    private static object? Evaluate(Expression e)
    {
        e = Unwrap(e);
        if (e is ConstantExpression c) return c.Value;
        return Expression.Lambda(Expression.Convert(e, typeof(object))).Compile().DynamicInvoke();
    }

    private bool ContainsRoot(Expression e)
    {
        var finder = new RootFinder(_root);
        finder.Visit(e);
        return finder.Found;
    }

    private static string Flip(string op) => op switch { "<" => ">", ">" => "<", "<=" => ">=", ">=" => "<=", _ => op };

    private sealed class RootFinder : ExpressionVisitor
    {
        private readonly ParameterExpression _root;
        public bool Found { get; private set; }
        public RootFinder(ParameterExpression root) => _root = root;

        protected override Expression VisitParameter(ParameterExpression node)
        {
            if (node == _root) Found = true;
            return node;
        }
    }
}
