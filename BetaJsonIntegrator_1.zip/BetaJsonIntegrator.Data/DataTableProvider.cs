using System.Data;
using BetaJsonIntegrator.Core;

namespace BetaJsonIntegrator.Data;

/// <summary>Contrato comum: converte DataTable em registros do Core.</summary>
public static class DataTableProvider
{
    public static RecordSet ToRecordSet(TableDefinition table, DataTable data)
    {
        var columns = data.Columns.Cast<DataColumn>().Select(c => c.ColumnName).ToList();
        var rows = new List<DataRecord>(data.Rows.Count);
        foreach (DataRow row in data.Rows)
        {
            var rec = new DataRecord();
            foreach (var c in columns) rec[c] = row[c] is DBNull ? null : row[c];
            rows.Add(rec);
        }
        return new RecordSet(table.Alias, columns, rows);
    }
}

/// <summary>Fonte baseada em DataTable já carregadas, por alias ou nome de tabela.</summary>
public sealed class DataTableRecordSource : IRecordSource
{
    private readonly Dictionary<string, DataTable> _tables = new(StringComparer.OrdinalIgnoreCase);
    public string Description => "DataTable";

    public DataTableRecordSource Add(string aliasOrTable, DataTable table) { _tables[aliasOrTable] = table; return this; }

    public Task<RecordSet> LoadAsync(TableDefinition table, IReadOnlyList<SourceFilter> filters, CancellationToken ct = default)
    {
        if (!_tables.TryGetValue(table.Alias, out var dt) && !_tables.TryGetValue(table.Name, out dt))
            throw new SourceException($"DataTable não informada para '{table.Alias}'.");
        var set = DataTableProvider.ToRecordSet(table, dt);
        return Task.FromResult(RecordSetShaper.Shape(table, set.Columns, set.Rows, filters));
    }
}
