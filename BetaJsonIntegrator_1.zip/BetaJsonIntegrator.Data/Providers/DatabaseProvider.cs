using BetaJsonIntegrator.Core;
using BetaJsonIntegrator.Orm;

namespace BetaJsonIntegrator.Data;

/// <summary>
/// Lê tabelas de qualquer banco suportado pelo ORM. Só consulta colunas que existem na tabela
/// (as ausentes são reportadas pelo mapeamento, com contexto). Identificadores são validados e
/// quotados pelo dialeto; valores de filtro sempre vão por parâmetro.
/// </summary>
public class DatabaseProvider : IRecordSource
{
    private readonly DbContext _context;

    public DatabaseProvider(DbContext context) => _context = context;

    public string Description => $"Banco {_context.Profile.Kind} ({_context.Profile.Name})";

    public async Task<RecordSet> LoadAsync(TableDefinition table, IReadOnlyList<SourceFilter> filters, CancellationToken ct = default)
    {
        try
        {
            if (!SqlIdentifier.IsValidTableName(table.Name))
                throw new SourceException($"Nome de tabela inválido para banco de dados: '{table.Name}'.");

            var actual = _context.GetColumnNames(table.Name);
            var byName = actual.ToDictionary(c => c, c => c, StringComparer.OrdinalIgnoreCase);
            var d = _context.Dialect;

            var selected = new List<string>();
            foreach (var c in table.Columns)
            {
                if (byName.TryGetValue(c.Name, out var real) && SqlIdentifier.IsValidPart(real)) selected.Add(real);
            }
            if (selected.Count == 0)
                throw new SourceException($"Nenhuma das colunas declaradas existe na tabela '{table.Name}'.");

            var parts = table.Name.Split('.');
            var quotedTable = parts.Length == 2 ? d.QuoteTable(parts[0], parts[1]) : d.QuoteTable(null, parts[0]);
            var sql = $"SELECT {string.Join(", ", selected.Select(d.QuoteIdentifier))} FROM {quotedTable}";

            var args = new Dictionary<string, object?>();
            var where = new List<string>();
            foreach (var f in filters)
            {
                if (!byName.TryGetValue(f.Column, out var real))
                    throw new SourceException($"Filtro em coluna inexistente: '{f.Column}'.");
                var p = "f" + args.Count;
                args[p] = f.Value;
                var op = f.Operator switch
                {
                    FilterOperator.Equal => "=", FilterOperator.NotEqual => "<>",
                    FilterOperator.LessThan => "<", FilterOperator.LessOrEqual => "<=",
                    FilterOperator.GreaterThan => ">", FilterOperator.GreaterOrEqual => ">=",
                    FilterOperator.Like => "LIKE", _ => throw new SourceException("Operador de filtro inválido.")
                };
                where.Add($"{d.QuoteIdentifier(real)} {op} {d.ParameterPrefix}{p}");
            }
            if (where.Count > 0) sql += " WHERE " + string.Join(" AND ", where);

            var order = table.Columns.Where(c => c.OrderBy && byName.ContainsKey(c.Name)).Select(c => d.QuoteIdentifier(byName[c.Name])).ToList();
            if (order.Count > 0) sql += " ORDER BY " + string.Join(", ", order);

            var data = await _context.QueryTableAsync(sql, args, ct).ConfigureAwait(false);
            return DataTableProvider.ToRecordSet(table, data);
        }
        catch (SourceException) { throw; }
        catch (Exception ex) when (ex is not OperationCanceledException)
        {
            throw new SourceException($"Falha ao ler a tabela '{table.Name}': {ex.Message}", ex);
        }
    }
}

public sealed class MariaDbProvider : DatabaseProvider
{
    public MariaDbProvider(DbContext context) : base(context)
    {
        if (context.Profile.Kind is not (DatabaseKind.MariaDb or DatabaseKind.MySql))
            throw new ArgumentException("MariaDbProvider exige um perfil MariaDb/MySql.");
    }
}

public sealed class SqlServerProvider : DatabaseProvider
{
    public SqlServerProvider(DbContext context) : base(context)
    {
        if (context.Profile.Kind != DatabaseKind.SqlServer)
            throw new ArgumentException("SqlServerProvider exige um perfil SqlServer.");
    }
}
