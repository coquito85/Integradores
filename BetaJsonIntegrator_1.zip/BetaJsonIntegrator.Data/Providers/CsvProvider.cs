using System.Text;
using BetaJsonIntegrator.Core;

namespace BetaJsonIntegrator.Data;

public sealed class CsvOptions
{
    public char Delimiter { get; set; } = ';';
    public string EncodingName { get; set; } = "utf-8";
    public bool HasHeader { get; set; } = true;
    public bool EmptyAsNull { get; set; } = true;

    /// <summary>Arquivo por alias (ou nome de tabela).</summary>
    public Dictionary<string, string> Files { get; } = new(StringComparer.OrdinalIgnoreCase);

    /// <summary>Arquivo usado quando o alias não está em Files.</summary>
    public string? DefaultFile { get; set; }
}

/// <summary>Leitor CSV (RFC 4180: aspas, "" escapado, quebras de linha dentro de campo) com delimitador/encoding configuráveis.</summary>
public sealed class CsvProvider : IRecordSource
{
    private readonly CsvOptions _options;

    static CsvProvider() => Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);

    public CsvProvider(CsvOptions options) => _options = options;

    public string Description => "CSV";

    public Task<RecordSet> LoadAsync(TableDefinition table, IReadOnlyList<SourceFilter> filters, CancellationToken ct = default)
    {
        var path = _options.Files.TryGetValue(table.Alias, out var p) ? p
                   : _options.Files.TryGetValue(table.Name, out p) ? p
                   : _options.DefaultFile;

        if (string.IsNullOrWhiteSpace(path)) throw new SourceException($"Nenhum arquivo CSV informado para '{table.Alias}'.");
        if (!File.Exists(path)) throw new SourceException($"Arquivo CSV não encontrado: {path}");

        Encoding enc;
        try { enc = Encoding.GetEncoding(_options.EncodingName); }
        catch (ArgumentException) { throw new SourceException($"Encoding inválido: '{_options.EncodingName}'."); }

        var text = File.ReadAllText(path, enc);
        var rows = Parse(text, _options.Delimiter);
        if (rows.Count == 0) return Task.FromResult(new RecordSet(table.Alias, Array.Empty<string>(), new List<DataRecord>()));

        List<string> header;
        int first;
        if (_options.HasHeader) { header = rows[0].Select(h => h.Trim()).ToList(); first = 1; }
        else
        {
            // sem cabeçalho: usa a ordem das colunas declaradas na seleção
            header = table.Columns.Select(c => c.Name).ToList();
            first = 0;
        }

        var records = new List<DataRecord>();
        for (var i = first; i < rows.Count; i++)
        {
            var rec = new DataRecord();
            for (var c = 0; c < header.Count; c++)
            {
                var v = c < rows[i].Count ? rows[i][c] : "";
                rec[header[c]] = _options.EmptyAsNull && v.Length == 0 ? null : v;
            }
            records.Add(rec);
        }

        return Task.FromResult(RecordSetShaper.Shape(table, header, records, filters));
    }

    public static List<List<string>> Parse(string text, char delimiter)
    {
        var rows = new List<List<string>>();
        var row = new List<string>();
        var field = new StringBuilder();
        var inQuotes = false;
        var any = false;

        if (text.Length > 0 && text[0] == '\uFEFF') text = text[1..];

        for (var i = 0; i < text.Length; i++)
        {
            var ch = text[i];
            if (inQuotes)
            {
                if (ch == '"')
                {
                    if (i + 1 < text.Length && text[i + 1] == '"') { field.Append('"'); i++; }
                    else inQuotes = false;
                }
                else field.Append(ch);
                continue;
            }

            if (ch == '"') { inQuotes = true; any = true; }
            else if (ch == delimiter) { row.Add(field.ToString()); field.Clear(); any = true; }
            else if (ch is '\r' or '\n')
            {
                if (ch == '\r' && i + 1 < text.Length && text[i + 1] == '\n') i++;
                if (any || field.Length > 0) { row.Add(field.ToString()); rows.Add(row); }
                row = new List<string>(); field.Clear(); any = false;
            }
            else { field.Append(ch); any = true; }
        }

        if (any || field.Length > 0) { row.Add(field.ToString()); rows.Add(row); }
        return rows;
    }
}
