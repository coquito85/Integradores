using System.ComponentModel;
using System.Data.Common;
using BetaJsonIntegrator.Core.Services;
using BetaJsonIntegrator.Data.Providers;

namespace GenerateJS
{
    /// <summary>Providers de banco suportados (nomes dos drivers, como no ProviderName do GeneratorJS).</summary>
    public static class DbProviders
    {
        public const string MySql = "MySqlConnector";
        public const string SqlServer = "Microsoft.Data.SqlClient";

        public static readonly string[] Names = { MySql, SqlServer };
    }

    /// <summary>Transforma ProviderName em combo (somente valores da lista).</summary>
    public sealed class ProviderNameConverter : StringConverter
    {
        public override bool GetStandardValuesSupported(ITypeDescriptorContext? context) => true;

        public override bool GetStandardValuesExclusive(ITypeDescriptorContext? context) => true;

        public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext? context) =>
            new StandardValuesCollection(DbProviders.Names);
    }

    /// <summary>
    /// Parâmetros da origem de banco editados no diálogo (PropertyGrid). A ordem de declaração é a ordem exibida.
    /// Ficam só em memória: a string de conexão nunca é gravada em arquivo nem no layout (spec. seção 14).
    /// </summary>
    public sealed class DatabaseSettings
    {
        [DisplayName("ConnectionString")]
        [Description("String de conexão do banco. Fica apenas em memória e é exibida mascarada.")]
        [PasswordPropertyText(true)]
        public string ConnectionString { get; set; } = "";

        [DisplayName("ProviderName")]
        [Description("Driver do banco: MySqlConnector (MariaDB/MySQL) ou Microsoft.Data.SqlClient (SQL Server).")]
        [TypeConverter(typeof(ProviderNameConverter))]
        public string ProviderName { get; set; } = DbProviders.MySql;

        [DisplayName("LayoutCode")]
        [Description("Identificador do layout (atributo identifier do XML, ex.: NOV2025009). Deve existir em Configurations\\Layouts.")]
        public string LayoutCode { get; set; } = "";

        [DisplayName("TableSource")]
        [Description("Opcional. Substitui o nome da tabela definido no XML (table/@name). Aceita schema.tabela.")]
        public string TableSource { get; set; } = "";

        [DisplayName("FiltersSource")]
        [Description("Opcional. Filtros de igualdade separados por vírgula, ex.: Ano=2026,Cartorio=1. Enviados como parâmetros SQL.")]
        public string FiltersSource { get; set; } = "";

        [DisplayName("CommandTimeout")]
        [Description("Tempo máximo, em segundos, de cada consulta.")]
        public int CommandTimeout { get; set; } = 120;

        [DisplayName("ArquivosDestino")]
        [Description("Opcional. Pasta de destino da exportação. Vazio usa a pasta Output do aplicativo.")]
        public string ArquivosDestino { get; set; } = "";

        [Browsable(false)]
        public bool EstaConfigurado => !string.IsNullOrWhiteSpace(ConnectionString);

        public DatabaseSettings Clone() => (DatabaseSettings)MemberwiseClone();

        /// <summary>Resumo sem credenciais, para a tela principal e para as mensagens.</summary>
        public string Resumo()
        {
            var texto = $"{ProviderName}  •  layout {LayoutCode}";
            if (!string.IsNullOrWhiteSpace(TableSource)) texto += $"  •  tabela {TableSource.Trim()}";
            if (!string.IsNullOrWhiteSpace(FiltersSource)) texto += $"  •  filtros {FiltersSource.Trim()}";
            return texto;
        }

        public DbProviderFactory CreateFactory() => ProviderName.Trim().ToLowerInvariant() switch
        {
            "mysqlconnector" => MySqlConnector.MySqlConnectorFactory.Instance,
            "microsoft.data.sqlclient" => Microsoft.Data.SqlClient.SqlClientFactory.Instance,
            _ => throw new InvalidOperationException($"ProviderName '{ProviderName}' não suportado.")
        };

        public IDataProvider CreateProvider()
        {
            var factory = CreateFactory();
            var cs = ConnectionString.Trim();
            return string.Equals(ProviderName.Trim(), DbProviders.SqlServer, StringComparison.OrdinalIgnoreCase)
                ? new SqlServerProvider(factory, cs) { CommandTimeoutSeconds = CommandTimeout }
                : new MariaDbProvider(factory, cs) { CommandTimeoutSeconds = CommandTimeout };
        }

        /// <summary>FiltersSource "campo=valor,campo2=valor2" → filtros parametrizados. Lança FormatException se inválido.</summary>
        public IReadOnlyList<DataFilter> ParseFilters()
        {
            var result = new List<DataFilter>();
            if (string.IsNullOrWhiteSpace(FiltersSource)) return result;

            foreach (var part in FiltersSource.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
            {
                int i = part.IndexOf('=');
                if (i <= 0)
                    throw new FormatException($"Filtro inválido: '{part}'. Use campo=valor, separados por vírgula.");

                var column = part[..i].Trim();
                var value = part[(i + 1)..].Trim();
                if (value.Length >= 2 && (value[0] == '\'' || value[0] == '"') && value[^1] == value[0])
                    value = value[1..^1];

                if (!SqlIdentifier.IsValid(column))
                    throw new FormatException($"Nome de campo inválido no filtro: '{column}'.");

                result.Add(new DataFilter(column, value));
            }
            return result;
        }

        /// <summary>Valida só o necessário para conectar (usado também pelo botão "Testar conexão").</summary>
        public string? ValidateConnectionOnly()
        {
            if (string.IsNullOrWhiteSpace(ConnectionString))
                return "A string de conexão é obrigatória.";
            if (!DbProviders.Names.Contains(ProviderName?.Trim() ?? "", StringComparer.OrdinalIgnoreCase))
                return $"Informe um ProviderName válido ({DbProviders.MySql} ou {DbProviders.SqlServer}).";
            return null;
        }

        /// <summary>Validações executadas ao gravar (equivalente ao Gravarconfiguracoes do GeneratorJS).</summary>
        public List<string> Validate(LayoutRepository repo)
        {
            var erros = new List<string>();

            var conexao = ValidateConnectionOnly();
            if (conexao != null) erros.Add(conexao);

            if (string.IsNullOrWhiteSpace(LayoutCode))
                erros.Add("Informe o código do layout (LayoutCode).");
            else if (repo.FindByIdentifier(LayoutCode.Trim()) == null)
                erros.Add($"O código do layout '{LayoutCode.Trim()}' não existe. Cadastre o layout ou informe um código válido.");

            if (!string.IsNullOrWhiteSpace(TableSource) && !SqlIdentifier.IsValid(TableSource.Trim()))
                erros.Add("TableSource inválido: use apenas letras, números e '_' (opcionalmente schema.tabela).");

            try { ParseFilters(); }
            catch (FormatException ex) { erros.Add(ex.Message); }

            if (CommandTimeout < 1)
                erros.Add("CommandTimeout deve ser maior que zero (segundos).");

            if (!string.IsNullOrWhiteSpace(ArquivosDestino) && !Path.IsPathRooted(ArquivosDestino.Trim()))
                erros.Add("ArquivosDestino deve ser um caminho completo (ex.: D:\\Saida).");

            return erros;
        }
    }
}
