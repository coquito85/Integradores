using BetaJsonIntegrator.Core.Services;
using ReferenciaFactory;

namespace GenerateJS.Forms
{
    /// <summary>
    /// Configuração do banco de dados em diálogo separado, no mesmo formato do GeneratorJS:
    /// PropertyGrid com os parâmetros, validação ao gravar e retorno por <see cref="Settings"/>.
    /// Trabalha sobre uma cópia: Cancelar não altera a configuração atual.
    /// </summary>
    public partial class frmConfigurationDatabase : Form
    {
        private readonly LayoutRepository _repo;
        private readonly DatabaseSettings _work;

        /// <summary>Configuração gravada (válida quando DialogResult = OK).</summary>
        public DatabaseSettings? Settings { get; private set; }

        public frmConfigurationDatabase(LayoutRepository repo, DatabaseSettings current)
        {
            InitializeComponent();
            _repo = repo;
            _work = current.Clone();

            pg_config.SelectedObject = null;
            pg_config.SelectedObject = _work;
        }

        private void btnGravar_Click(object sender, EventArgs e)
        {
            var erros = _work.Validate(_repo);
            if (erros.Count > 0)
            {
                MessageBox.Show(this, string.Join(Environment.NewLine + Environment.NewLine, erros),
                    "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Settings = _work;
            DialogResult = DialogResult.OK;
            Close();
        }

        private async void btnTestar_Click(object sender, EventArgs e)
        {
            var erro = _work.ValidateConnectionOnly();
            if (erro != null)
            {
                MessageBox.Show(this, erro, Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var factory = _work.CreateFactory();
            var cs = _work.ConnectionString.Trim();

            btnTestar.Enabled = false;
            try
            {
                await Task.Run(() =>
                {
                    using var db = new DatabaseConnection(cs, factory);
                    db.Open();
                    db.ExecuteScalar("SELECT 1");
                });
                MessageBox.Show(this, "Conexão estabelecida com sucesso.", Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                // a mensagem do driver pode conter o servidor, mas nunca a senha informada
                MessageBox.Show(this, "Falha ao conectar: " + ex.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                btnTestar.Enabled = true;
            }
        }
    }
}
